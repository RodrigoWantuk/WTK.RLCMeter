from pathlib import Path
import sys,os,subprocess,time,json
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import pc_serial_ui as u
import serial
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E',flash_bytes=131072)
p=b.plan('probe',out,uid='54ff70068370525760380567');p['argv'][-1]='init; reset init; wtk_operation; reset run; echo WTK_PICTURE_BOOT; shutdown'
with serial.Serial('COM3',115200,timeout=.1) as link:
 link.reset_input_buffer();r=subprocess.run(p['argv'],env=dict(os.environ,**p['environment']),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW);(out/'openocd.txt').write_bytes(r.stdout);assert r.returncode==0
 raw=bytearray();end=time.monotonic()+8
 while time.monotonic()<end:raw.extend(link.read(1024))
 (out/'uart.bin').write_bytes(raw);assert raw.count(b'SAFE_BOOT')==1
 status,_,_=u.exchange(link,u.TELEMETRY,int(time.time()*1000)&0xffffffff,0,out,'telemetry')
 assert status['uid']=='54ff70068370525760380567' and status['git'].startswith('9c14a6c') and status['fault_mask']==0 and status['k1_commanded_state']==1 and status['range_state']==0 and status['session_sequence']==0
 (out/'report.json').write_text(json.dumps(dict(safe_boot_banners=1,telemetry=status,activation_requested=False),indent=2)+'\n',encoding='utf-8');print(json.dumps(status))
