from pathlib import Path
import json,sys
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
root=Path('Firmware/build/waveform-snapshot-20261028')
manifest=root/'sealed-stack-final/image/manifest.json';m=d.inspect(manifest)
telemetry=json.loads((root/'pre-production-telemetry/report.json').read_text(encoding='utf-8'))['exchanges'][0]
assert telemetry['battery_v']>=3.65 and telemetry['fault_mask']==0 and telemetry['k1_commanded_state']==1
assert telemetry['range_state']==0 and telemetry['factory_calibration_sequence']==1 and telemetry['session_sequence']==0
assert telemetry['uid']==d.UNIT128_UID and telemetry['git'].startswith('3f9e1a6')
assert m['source']['git_sha'].startswith('3f9e1a6') and not m['source']['dirty']
a=json.loads(Path('Firmware/build/picture-controls-20261028/program-authorization.json').read_text(encoding='utf-8'))
pack=Path('Firmware/build/waveform-api7.wrp2').read_bytes()
a.update(utc=d.utc(),image_sha256=m['files']['firmware.bin']['sha256'],manifest_seal=m['seal_sha256'],
 approval_origin='Owner explicitly approved plan34 implementation, matching firmware/resource deployment, preservation and Git/PR delivery.',
 scope='Install sealed production waveform page after actual diagnostic stack recovery; no DUT capture or serial OK.',
 preflight_path=str((root/'pre-production-telemetry/report.json').resolve()),
 supply='Fresh genuine UART %.3f V; charger absent; SAFE and no faults. No numeric SWD battery read.'%telemetry['battery_v'],
 preservation='Preserve fresh 40-KiB tail SHA-256 8825cacce71cecbc652228bca75e83b042269dbc58d2918dc765e9e6a736fdff, factory OSL seq1/all33, lead slots, owner settings and unchanged compiled experimental NTC.',
 resource_update_intent=dict(api=7,pack_bytes=len(pack),pack_sha256=d.sha(pack),erase_start=0,
 erase_end_exclusive=110592,mutable_tail_start=4153344))
a['seal_sha256']=d.seal(a);d.save(root/'program-authorization.json',a)
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
 'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E',flash_bytes=131072)
r=d.deployment('program',manifest,b,root/'program-production',a,uid=d.UNIT128_UID)
print(json.dumps({k:r[k] for k in ['outcome','programming','internal_readback','readback','unaffected_internal_pages_preserved']},indent=2))
