from pathlib import Path
import sys,os,subprocess,time,json
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d,pc_serial_ui as u
import serial
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
 'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E',flash_bytes=131072)
plan=b.plan('probe',out,uid=d.UNIT128_UID)
plan['argv'][-1]='init; reset init; wtk_operation; reset run; echo WTK_WAVEFORM_BOOT; shutdown'
with serial.Serial('COM3',115200,timeout=.1) as link:
 link.reset_input_buffer()
 result=subprocess.run(plan['argv'],env=dict(os.environ,**plan['environment']),
  stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
 (out/'openocd.txt').write_bytes(result.stdout);assert result.returncode==0
 data=bytearray();end=time.monotonic()+8
 while time.monotonic()<end:data.extend(link.read(1024))
 (out/'uart.bin').write_bytes(data);assert data.count(b'SAFE_BOOT')==1
 status,_,_=u.exchange(link,u.TELEMETRY,int(time.time()*1000)&0xffffffff,0,out,'telemetry')
 assert status['uid']==d.UNIT128_UID and status['git'].startswith('3f9e1a6')
 assert status['fault_mask']==0 and status['k1_commanded_state']==1 and status['range_state']==0 and status['session_sequence']==0
 (out/'report.json').write_text(json.dumps(dict(safe_boot_banners=1,telemetry=status,activation_requested=False),indent=2)+'\n',encoding='utf-8')
 print(json.dumps(status,indent=2))
