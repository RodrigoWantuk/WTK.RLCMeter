from pathlib import Path
import sys,os,json,subprocess,struct
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
 'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E',flash_bytes=131072)
plan=b.plan('probe',out,uid=d.UNIT128_UID)
destination=(out/'stack.bin').resolve().as_posix()
plan['argv'][-1]='init; dump_image {'+destination+'} 0x20004800 2048; echo WTK_STACK_READ; shutdown'
result=subprocess.run(plan['argv'],env=dict(os.environ,**plan['environment']),stdout=subprocess.PIPE,
 stderr=subprocess.STDOUT,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
(out/'openocd.txt').write_bytes(result.stdout)
assert result.returncode==0 and b'WTK_STACK_READ' in result.stdout
raw=(out/'stack.bin').read_bytes();assert len(raw)==2048
prefix=0
for i in range(0,len(raw),4):
 if struct.unpack_from('<I',raw,i)[0]!=0xA55AA55A:break
 prefix+=4
report=dict(utc=d.utc(),SIMULATED=False,method='non-halting SWD read of reset-painted top 2048 bytes',
 unused_prefix_bytes=prefix,observed_high_water_bytes=2048-prefix,required_margin_bytes=512,
 passed=prefix>=512,scope='Only actual boot/resource-update/idle paths exercised; acquisition and waveform display stack remain REQUIRES_BENCH_VALIDATION',
 reset_requested=False,halt_requested=False,activation_requested=False,programmer=b.provenance())
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='programmer'},indent=2))
assert prefix>=512
