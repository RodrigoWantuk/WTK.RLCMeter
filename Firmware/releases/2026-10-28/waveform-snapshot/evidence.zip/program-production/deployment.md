# Firmware deployment — REAL_BACKEND / NOT PHYSICALLY QUALIFIED

SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.

Outcome: INTERNAL_FLASH_VERIFIED

Programming: CONFIRMED; internal readback: PASS; boot: NOT_TESTED; UART: NOT_TESTED; application: NOT_TESTED.

External W25Q was not accessed. OSL/Resource Pack remain independently accepted prerequisites.

```json
{
  "schema": "WTK_DEPLOYMENT_1",
  "transaction": "5e664c5d-a707-40d4-8d60-56b69462b9e5",
  "operation": "program",
  "started_utc": "2026-10-28T18:35:10.401129+00:00",
  "SIMULATED": false,
  "image": {
    "schema": "WTK_FIRMWARE_2",
    "source": {
      "git_sha": "3f9e1a65ca0a078fe1febd00c3fc3c911a8eae1a",
      "dirty": false,
      "git_status": "",
      "input_sha256": "479259a194b97012a9d061ac1821672f2d2bd7a7a0e61225cad092ba578cc66c"
    },
    "profile": "FACTORY_PRODUCT_UNIT128",
    "factory_provisioned": true,
    "supplementary_curves": false,
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "bringup_k1_test": false,
    "bringup_bench_supply": false,
    "bringup_peripheral_test": false,
    "preset": "stm32-unit-release",
    "build_configuration": "Release",
    "hardware": "Rev1-STM32F103C8T6-BluePill",
    "firmware_version": "0.1.0",
    "expected_boot": {
      "interface": "LIMITED_UART_UI_REQUIRED",
      "firmware_version": "0.1.0",
      "hardware": "Rev1-STM32F103C8T6-BluePill",
      "git_prefix": null,
      "limitation": "PRODUCT banner is only WTK.RLCMeter SAFE_BOOT; UI/bench acceptance separate"
    },
    "toolchain": {
      "compiler_path": "C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin/arm-none-eabi-gcc.exe",
      "compiler_version": "arm-none-eabi-gcc.exe (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119",
      "cmake": "cmake version 4.4.4",
      "cache_sha256": "2e3d1c8afd7ecd7845df6589eb452311e5ec3377247c0bfa55070826057f2967"
    },
    "memory": {
      "flash_base": 134217728,
      "flash_bytes": 131072,
      "ram_base": 536870912,
      "ram_bytes": 20480,
      "internal_page_bytes": 1024
    },
    "linked": {
      "flash_bytes": 79644,
      "bss": 15392,
      "ram_static_bytes": 15448,
      "noinit_bytes": 0,
      "reserved_stack_bytes": 2048,
      "ram_accounted_bytes": 17496
    },
    "binary_size": 79644,
    "files": {
      "firmware.bin": {
        "bytes": 79644,
        "sha256": "2af412eb90cb32f9d977f779c19b042a1e0ccdf82e017a9529ac76065bd375d5"
      },
      "firmware.elf": {
        "bytes": 120100,
        "sha256": "de6133d699567a777c641bddf5758104d4f6be1e6361e5407701f5a0ed30e881"
      },
      "build_config.h": {
        "bytes": 1759,
        "sha256": "14842d7888a87ae9e28e6319525128ea2ba6e9688b433435d6ef4cdb72742556"
      },
      "linker.ld": {
        "bytes": 2372,
        "sha256": "9cfe26a14ab5b55f645d2a2659a7ee64a836fc5af97a292ed97a40fa08490a62"
      }
    },
    "built_utc": "2026-10-28T18:32:36.296689+00:00",
    "features": {
      "modern_production": true,
      "continuous_session": true,
      "three_frequency_survey": true,
      "trimmed_seven": true,
      "ui_row_cache": true,
      "serial_ui": true,
      "lead_compensation": true,
      "factory_load_only": true,
      "supplementary_curves": false
    },
    "seal_sha256": "6243e2f696b6ba268eff9ea6fa01ea4967ef16f554b7592860fe26d9080f03ec",
    "manifest_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\waveform-snapshot-20261028\\sealed-stack-final\\image\\manifest.json",
    "staged_binary": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\waveform-snapshot-20261028\\program-production\\staged-image.bin"
  },
  "authorization": {
    "operator": "Rodrigo",
    "utc": "2026-10-28T18:35:10.237300+00:00",
    "board": "First Rev1 board; six RGS gate-to-GND rework",
    "expected_uid": "54ff70068370525760380567",
    "SIMULATED": false,
    "previous_profile": "FACTORY_PRODUCT_UNIT128",
    "next_profile": "FACTORY_PRODUCT_UNIT128",
    "image_sha256": "2af412eb90cb32f9d977f779c19b042a1e0ccdf82e017a9529ac76065bd375d5",
    "manifest_seal": "6243e2f696b6ba268eff9ea6fa01ea4967ef16f554b7592860fe26d9080f03ec",
    "approval_origin": "Owner explicitly approved plan34 implementation, matching firmware/resource deployment, preservation and Git/PR delivery.",
    "scope": "Install sealed production waveform page after actual diagnostic stack recovery; no DUT capture or serial OK.",
    "preflight_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\waveform-snapshot-20261028\\pre-production-telemetry\\report.json",
    "physical_qualification": false,
    "supply": "Fresh genuine UART 4.031 V; charger absent; SAFE and no faults. No numeric SWD battery read.",
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "osl": {
      "sequence": 1,
      "records": 33,
      "sha256": "af76d19b15a510dff0c880a4ab6e86893e0065ac7e845b9930111680752da78c",
      "preprogram_runtime_active": true
    },
    "preservation": "Preserve fresh 40-KiB tail SHA-256 8825cacce71cecbc652228bca75e83b042269dbc58d2918dc765e9e6a736fdff, factory OSL seq1/all33, lead slots, owner settings and unchanged compiled experimental NTC.",
    "procedural_exception": {
      "owner_requested_proceed_without_scope": true,
      "scope_checks": "NOT_TESTED; previous owner decision preserved, no new physical safety or accuracy qualification inferred"
    },
    "acknowledgements": {
      "safe_outputs": true,
      "debug_halt_watchdog": true,
      "no_app_bootloader": true,
      "internal_flash": true
    },
    "seal_sha256": "3606a511e678c306fa9e18c9a9c8dc2de426f1ee8dce74eb19f1fde443afaf93",
    "resource_update_intent": {
      "api": 7,
      "pack_bytes": 108975,
      "pack_sha256": "e488ff36fa78f962e3aaec7b495e358ae89f37456e30029c6ee41b56d65bdf41",
      "erase_start": 0,
      "erase_end_exclusive": 110592,
      "mutable_tail_start": 4153344
    }
  },
  "programming": "CONFIRMED",
  "internal_readback": "PASS",
  "boot": "NOT_TESTED",
  "uart_identity": "NOT_TESTED",
  "application": "NOT_TESTED",
  "external_w25q_access": false,
  "physically_validated": false,
  "outcome": "INTERNAL_FLASH_VERIFIED",
  "error": null,
  "transcripts": [
    {
      "path": "preflight/openocd.txt",
      "sha256": "ee555b281af6b46660572ac751177b458b46068b37fe60909579f5ddad682d86"
    },
    {
      "path": "openocd.txt",
      "sha256": "d40757691fa35a6a3c36192cd7cc580dd6edb1588c4c96c855edfa10459be98d"
    }
  ],
  "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.",
  "seal_sha256": "3cf1a62c3bed48d0aa7655117f9b8b053045871a9b2a221e95c48b6d4dcd75ca",
  "preflight": {
    "target": {
      "device_id": 537093136,
      "cpuid": 1092600369,
      "flash_kib": 64,
      "obr": 67108860,
      "wrpr": 4294967295,
      "uid": "54ff70068370525760380567",
      "flash_base": 134217728,
      "flash_bytes": 131072,
      "driver": "stm32f1x",
      "state": "halted",
      "target_voltage_v": 3.295594
    },
    "programmer": {
      "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
      "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
      "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "config_hashes": {
        "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
        "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
      },
      "toolkit_script_sha256": "656cf4b1bb7179f81effe977c8a66ed1ea1dd195a710e2f61771d09700302326",
      "deployment_tool_sha256": "12862d244ecc8ad3aef72f68748a26208791af643d13bf2d8eeb2f69197724af",
      "adapter_serial_selection": "530049000C0000513751594E"
    },
    "plan": {
      "argv": [
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
        "-s",
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
        "-c",
        "source $::env(WTK_INTERFACE)",
        "-c",
        "transport select dapdirect_swd",
        "-c",
        "adapter serial $::env(WTK_SERIAL)",
        "-c",
        "set FLASH_SIZE $::env(WTK_FLASH_BYTES)",
        "-c",
        "source $::env(WTK_TARGET)",
        "-c",
        "gdb_port disabled; tcl_port disabled; telnet_port disabled",
        "-c",
        "source $::env(WTK_LIBRARY)",
        "-c",
        "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
      ],
      "environment": {
        "WTK_SERIAL": "530049000C0000513751594E",
        "WTK_ACTION": "probe",
        "WTK_UID": "54ff70068370525760380567",
        "WTK_FLASH_BYTES": "131072",
        "WTK_LENGTH": "0",
        "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
        "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
        "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
        "WTK_IMAGE": "",
        "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\waveform-snapshot-20261028\\program-production\\preflight\\before.bin",
        "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\waveform-snapshot-20261028\\program-production\\preflight\\full-readback.bin"
      },
      "internal_flash_range": [
        134217728,
        134348800
      ],
      "program_range": null,
      "erase_range": null,
      "external_w25q_access": false,
      "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
    }
  },
  "target": {
    "device_id": 537093136,
    "cpuid": 1092600369,
    "flash_kib": 64,
    "obr": 67108860,
    "wrpr": 4294967295,
    "uid": "54ff70068370525760380567",
    "flash_base": 134217728,
    "flash_bytes": 131072,
    "driver": "stm32f1x",
    "state": "halted",
    "target_voltage_v": 3.298798
  },
  "programmer": {
    "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
    "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
    "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
    "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
    "config_hashes": {
      "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
      "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
    },
    "toolkit_script_sha256": "656cf4b1bb7179f81effe977c8a66ed1ea1dd195a710e2f61771d09700302326",
    "deployment_tool_sha256": "12862d244ecc8ad3aef72f68748a26208791af643d13bf2d8eeb2f69197724af",
    "adapter_serial_selection": "530049000C0000513751594E"
  },
  "plan": {
    "argv": [
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "-s",
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "-c",
      "source $::env(WTK_INTERFACE)",
      "-c",
      "transport select dapdirect_swd",
      "-c",
      "adapter serial $::env(WTK_SERIAL)",
      "-c",
      "set FLASH_SIZE $::env(WTK_FLASH_BYTES)",
      "-c",
      "source $::env(WTK_TARGET)",
      "-c",
      "gdb_port disabled; tcl_port disabled; telnet_port disabled",
      "-c",
      "source $::env(WTK_LIBRARY)",
      "-c",
      "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
    ],
    "environment": {
      "WTK_SERIAL": "530049000C0000513751594E",
      "WTK_ACTION": "program",
      "WTK_UID": "54ff70068370525760380567",
      "WTK_FLASH_BYTES": "131072",
      "WTK_LENGTH": "79644",
      "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
      "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
      "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
      "WTK_IMAGE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\waveform-snapshot-20261028\\program-production\\staged-image.bin",
      "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\waveform-snapshot-20261028\\program-production\\before.bin",
      "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\waveform-snapshot-20261028\\program-production\\full-readback.bin"
    },
    "internal_flash_range": [
      134217728,
      134348800
    ],
    "program_range": [
      134217728,
      134297372
    ],
    "erase_range": [
      134217728,
      134297600
    ],
    "external_w25q_access": false,
    "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
  },
  "readback": {
    "start": 134217728,
    "end_exclusive": 134297372,
    "bytes": 79644,
    "expected_sha256": "2af412eb90cb32f9d977f779c19b042a1e0ccdf82e017a9529ac76065bd375d5",
    "actual_sha256": "2af412eb90cb32f9d977f779c19b042a1e0ccdf82e017a9529ac76065bd375d5",
    "full_flash_sha256": "a99917f92465dc59548c6b9713055d363cbf3857cd81721e9c293c071bd47847",
    "full_flash_bytes": 131072
  },
  "unaffected_internal_pages_preserved": true,
  "next_step": "Separately boot PRODUCT; limited SAFE_BOOT UART banner cannot prove SHA/calibration/resources/readiness. Inspect UI and physical checklist.",
  "completed_utc": "2026-10-28T18:35:22.151560+00:00"
}
```
