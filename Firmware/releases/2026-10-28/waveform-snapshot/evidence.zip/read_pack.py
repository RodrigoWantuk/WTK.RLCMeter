from pathlib import Path
import sys,time,json,hashlib,struct
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_serial_ui as u,pc_flash_snapshot as f
out=Path(sys.argv[1]);expected=Path(sys.argv[2]).read_bytes();out.mkdir(parents=True,exist_ok=False)
identity=int(time.time()*1000)&0xffffffff
link=u.open_serial('COM3')
try:
 link.reset_input_buffer();time.sleep(.3)
 status,_,_=u.exchange(link,u.TELEMETRY,identity,0,out,'telemetry');identity+=1
 assert status['uid']=='54ff70068370525760380567' and status['k1_commanded_state']==1 and status['range_state']==0 and status['fault_mask']==0
 data=bytearray()
 with (out/'read-tx.bin').open('wb') as tx,(out/'read-rx.bin').open('wb') as rx:
  while len(data)<len(expected):
   n=min(108,len(expected)-len(data))
   data.extend(f.read_chunk(link,identity,status['session_sequence'],len(data),n,tx,rx));identity+=1
 (out/'pack.wrp2').write_bytes(data)
 assert bytes(data)==expected
 count=struct.unpack_from('<H',data,16)[0];images={}
 for i in range(count):
  rid,_,_,_,offset,size,_,_,_=struct.unpack_from('<IHHIIIIII',data,44+32*i)
  if rid in (0x30002,0x30006):
   images[hex(rid)]=dict(bytes=size,sha256=hashlib.sha256(data[offset:offset+size]).hexdigest())
 report=dict(operation='READ_ONLY_PACK',utc=u.utc_now(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),
  api=struct.unpack_from('<H',data,8)[0],images=images,telemetry=status,equal=True,activation_requested=False)
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:v for k,v in report.items() if k!='telemetry'},indent=2))
finally:link.close()
