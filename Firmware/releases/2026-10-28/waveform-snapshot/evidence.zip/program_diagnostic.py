from pathlib import Path
import sys,os,json,subprocess,math
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
root=Path('Firmware/build/waveform-snapshot-20261028')
uid=d.UNIT128_UID
build=root/'matrix/unit-debug';out=root/'program-diagnostic-stack-fixed'
out.mkdir(exist_ok=False)
config=d.parse_config((build/'generated/wtk_build_config.h').read_bytes())
assert config['WTK_STACK_WATERMARK']=='1' and config['WTK_GIT_COMMIT'].startswith('3f9e1a6')
assert config['WTK_NTC_FACTORY_UID']==uid and config['WTK_INTERNAL_FLASH_BYTES']=='131072u'
binary,metrics=d.elf_info((build/'WTK.RLCMeter.elf').read_bytes(),131072)
assert binary==(build/'WTK.RLCMeter.bin').read_bytes()
assert metrics['ram_accounted_bytes']<=19456 and metrics['reserved_stack_bytes']>=2048
image=dict(binary_size=len(binary),memory=dict(flash_bytes=131072),
 staged_binary=str((build/'WTK.RLCMeter.bin').resolve()),manifest_path=str((out/'diagnostic-image.json').resolve()))
record=dict(utc=d.utc(),SIMULATED=False,diagnostic=True,expected_uid=uid,
 source=config['WTK_GIT_COMMIT'],image_sha256=d.sha(binary),metrics=metrics,
 scope='Owner-authorized plan34 diagnostic stack paint; no DUT acquisition; return to sealed production afterward.',
 qualification='REQUIRES_BENCH_VALIDATION',image=image)
(out/'diagnostic-image.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
 'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E',flash_bytes=131072)
pre=out/'preflight';pre.mkdir()
target,provenance,plan=b.execute('probe',pre,uid=uid)
record['preflight']=dict(target=target,programmer=provenance,plan=plan)
target,provenance,plan=b.execute('program',out,image,uid=uid)
readback=(out/'full-readback.bin').read_bytes();before=(out/'before.bin').read_bytes()
assert len(readback)==131072 and readback[:len(binary)]==binary
end=math.ceil(len(binary)/1024)*1024
assert before[end:]==readback[end:]
record.update(target=target,programmer=provenance,plan=plan,internal_readback='PASS',
 full_readback_sha256=d.sha(readback),outside_pages_preserved=True,activation_requested=False)
(out/'report.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k in ('source','image_sha256','metrics','internal_readback','activation_requested')},indent=2))
