from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess,csv
root=Path('Firmware/build/waveform-snapshot-20261028')
release=Path('Firmware/releases/2026-10-28/waveform-snapshot');release.mkdir(parents=True,exist_ok=False)
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
m=read(root/'sealed-stack-final/image/manifest.json')
deployment=read(root/'program-production/deployment.json')
boot=read(root/'boot-production-final/report.json')
tail=read(root/'post-production-tail/report.json')
pack=read(root/'post-production-api7/report.json')
stack=read(root/'stack-fixed-after-update/report.json')
matrix=read(root/'matrix/current-matrix.json')
assert deployment['internal_readback']=='PASS' and boot['telemetry']['ui_state']==4
assert tail['comparison_equal'] and pack['equal'] and stack['passed']
assert read(root/'matrix/current-source.json')['complete']
assert len(matrix)==10 and sum(row['outcome']=='PASS' for row in matrix)==9
assert pack['images']==read(root/'pre-program-api6/report.json')['images']
# Correct the scope of the first (pre-update) read; raw memory and timestamp are unchanged.
initial=read(root/'stack-fixed-after-boot/report.json')
initial['scope']='Only actual boot/resource-mount/idle paths exercised at this checkpoint; acquisition and waveform display remain REQUIRES_BENCH_VALIDATION'
save(root/'stack-fixed-after-boot/report.json',initial)
equivalence=subprocess.check_output(['git','diff','--name-only','42d5c6a','3f9e1a6','--','Firmware/src'],text=True).splitlines()
assert equivalence==['Firmware/src/app/app_shell.c']
save(root/'host-source-equivalence.json',dict(host_tested_source='42d5c6af34adee74cb626ee7238b2039d12e2a0a',
 production_source=m['source']['git_sha'],runtime_delta=equivalence,
 scope='Pure/session/product/UI code and assets unchanged; final foreground-only stack split validated by ARM matrix and actual diagnostic programming/boot/update/stack reads.'))
rows=[]
for profile in ['unit-release','unit-debug','unit-curves']:
 for p in (root/'matrix'/profile).glob('*.su'):
  for line in p.read_text(encoding='utf-8').splitlines():
   parts=line.split('\t')
   if len(parts)==3 and parts[1].isdigit():rows.append(dict(profile=profile,location=parts[0],frame_bytes=int(parts[1]),kind=parts[2]))
rows.sort(key=lambda x:x['frame_bytes'],reverse=True)
with (root/'stack-frames.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['profile','location','frame_bytes','kind']);w.writeheader();w.writerows(rows)
with zipfile.ZipFile(release/'firmware.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((root/'sealed-stack-final/image').iterdir()):
  if p.is_file():z.write(p,p.name)
with zipfile.ZipFile(release/'diagnostic-firmware.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for relative in ['WTK.RLCMeter.bin','WTK.RLCMeter.elf','WTK.RLCMeter.size.json','generated/wtk_build_config.h','generated/WTK_FLASH.ld']:
  p=root/'matrix/unit-debug'/relative;z.write(p,relative)
shutil.copyfile('Firmware/build/waveform-api7.wrp2',release/'product-api7.wrp2')
shutil.copyfile('Firmware/build/waveform-api7-summary.json',release/'product-api7-summary.json')
shutil.copyfile(root/'previews/pt-BR-resources-waveform.png',release/'waveform-preview.png')
shutil.copyfile(root/'previews/waveform-contact-sheet.png',release/'waveform-previews.png')
report=dict(status='IMPLEMENTED_REQUIRES_BENCH_VALIDATION',source=m['source'],uid=boot['telemetry']['uid'],
 firmware=dict(bytes=m['binary_size'],sha256=m['files']['firmware.bin']['sha256'],readback=deployment['internal_readback']),
 resources=dict(api=7,bytes=pack['bytes'],sha256=pack['sha256'],frames=911,readback='BYTE_IDENTICAL',images=pack['images']),
 memory=m['linked'],memory_baseline_accounted=15288,incremental_accounted_bytes=m['linked']['ram_accounted_bytes']-15288,
 stack=dict(before_fix_unused_bytes=252,after_boot_unused_bytes=940,after_update_unused_bytes=stack['unused_prefix_bytes'],
 reserve_bytes=2048,required_margin_bytes=512,remaining_paths='REQUIRES_BENCH_VALIDATION: acquisition, waveform page, menus and broader fault paths'),
 preserved=dict(tail_sha256=tail['sha256'],tail_byte_identical=True,factory_osl_sequence=1,factory_osl_records=33,
 ntc_profile_sha256=m['ntc_factory_profile']['profile_sha256'],settings_schema=5),
 validation=dict(host_entries=67,host_provisioning_off_entries=4,python_cases=532,python_optional_skips=38,
 strict_waveform_previews=28,embedded_matrix=matrix,source_equivalence='evidence.zip/host-source-equivalence.json'),
 final_telemetry=boot['telemetry'],activation_requested=False,calibration_campaign_repeated=False)
save(release/'report.json',report)
# Keep real raw serial/SWD evidence and failed checkpoints. Do not archive build trees or dependency caches.
selected=[]
for p in root.iterdir():
 if p.is_file():selected.append(p)
 elif p.name in ['previews','pre-program-tail','pre-program-api6','post-diagnostic-api7','post-production-tail',
 'post-production-api7','program-diagnostic','program-diagnostic-stack-fixed','program-production','boot-diagnostic-api6',
 'boot-diagnostic-stack-fixed','boot-production-final','stack-after-update','stack-fixed-after-boot',
 'stack-fixed-after-update','pre-production-telemetry','pre-diagnostic-telemetry']:
  selected.extend(q for q in p.rglob('*') if q.is_file())
for p in (root/'matrix').iterdir():
 if p.is_file():selected.append(p)
 elif p.is_dir():
  for pattern in ['*.map','*.size.json','*.su']:
   selected.extend(p.glob(pattern))
  selected.extend(q for q in (p/'generated').glob('*') if q.is_file())
index=[]
with zipfile.ZipFile(release/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(selected)):
  name=p.relative_to(root).as_posix();data=p.read_bytes()
  z.writestr(name,data);index.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 z.writestr('index.json',json.dumps(index,indent=2)+'\n')
save(release/'checksums.json',{p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in release.iterdir() if p.is_file()})
print(json.dumps(dict(release=str(release),evidence_files=len(index),firmware=report['firmware'],memory=report['memory'],stack=report['stack']),indent=2))
