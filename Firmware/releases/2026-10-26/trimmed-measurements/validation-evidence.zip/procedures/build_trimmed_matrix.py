import concurrent.futures
import json
from pathlib import Path
import subprocess
import hashlib
import sys
import zipfile

root=Path(__file__).resolve().parent/'verified-builds-trimmed'
root.mkdir(exist_ok=False)
repo=Path.cwd()
sys.path.insert(0,str(repo/'Firmware/tools'))
import pc_firmware_deploy as deploy
import ntc_factory_profile as ntc
before=deploy.source_state()
if before['dirty']: raise ValueError('Final matrix requires clean committed source')
cases=[('factory-release','stm32-factory-release',[]),
       ('bringup','stm32-bringup',[]),
       ('product-debug','stm32-debug',[]),
       ('product-release','stm32-release',[]),
       ('factory-debug','stm32-factory-debug',[]),
       ('bringup-cal','stm32-bringup-cal',[]),
       ('bench-supply','stm32-bringup',['-DWTK_BRINGUP_BENCH_SUPPLY=ON']),
       ('k1-test','stm32-bringup',['-DWTK_BRINGUP_K1_TEST=ON']),
       ('peripheral','stm32-bringup',['-DWTK_BRINGUP_PERIPHERAL_TEST=ON'])]
assert len({c[0] for c in cases})==len(cases)==9

def run(case):
    name,preset,flags=case
    folder=root/name
    commands=[['cmake','--preset',preset,'-B',str(folder),'-DWTK_WARNINGS_AS_ERRORS_STM32=ON', '-DWTK_NTC_FACTORY_PROFILE='+str(repo/'Firmware/config/units/54ff70068370525760380567-ntc-engineering.json')]+flags,
              ['cmake','--build',str(folder),'-j','4']]
    result=dict(name=name,preset=preset,commands=commands,status='PASS')
    with (root/(name+'.log')).open('w',encoding='utf-8') as log:
        for cmd in commands:
            proc=subprocess.run(cmd,cwd=repo/'Firmware',stdout=log,stderr=subprocess.STDOUT)
            if proc.returncode:
                result['status']='FAIL';result['returncode']=proc.returncode;break
    print(name,result['status'],flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(run,cases))
(root/'build-matrix.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
if any(item['status']!='PASS' for item in results): raise SystemExit(1)
if deploy.source_state()!=before: raise ValueError('Source changed during final matrix')
report=dict(source=before,calibration_hardware_revision=0x00010002,
    status='SOFTWARE_BUILDS_PASS_REQUIRES_BENCH_VALIDATION',ntc_factory_profile=deploy.load(root/'bringup-cal/generated/wtk_ntc_factory_profile.json'),cases=[])
for name,preset,flags in cases:
    folder=root/name
    config=deploy.parse_config((folder/'generated/wtk_build_config.h').read_bytes())
    expected_feature='1u' if config['WTK_PRODUCT_FACTORY_PROVISIONED']=='1u' else '0u'
    if config['WTK_ENABLE_MEASURE_SESSION_HOLD']!=expected_feature or config['WTK_ENABLE_UI_ROW_CACHE']!=expected_feature or config['WTK_ENABLE_MEASUREMENT_TRIMMED']!=expected_feature: raise ValueError('Session/menu profile boundary mismatch')
    if config['WTK_GIT_COMMIT']!=before['git_sha'][:12]: raise ValueError('Stale source identity')
    if config['WTK_NTC_FACTORY_UID']!='54ff70068370525760380567' or config['WTK_NTC_FACTORY_CALIBRATION']!='1u': raise ValueError('Unit NTC profile missing')
    meta=deploy.load(folder/'generated/wtk_ntc_factory_profile.json')
    ntc.validate_binary(meta,(folder/'WTK.RLCMeter.bin').read_bytes(),config)
    sizes=json.loads((folder/'WTK.RLCMeter.size.json').read_text())
    files={}
    for suffix in ('bin','elf','hex','map'):
        path=folder/('WTK.RLCMeter.'+suffix)
        files[path.name]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    report['cases'].append(dict(name=name,preset=preset,options=flags,profile=config['WTK_FIRMWARE_PROFILE'],
        factory=config['WTK_PRODUCT_FACTORY_PROVISIONED'],session_hold=config['WTK_ENABLE_MEASURE_SESSION_HOLD'],row_cache=config['WTK_ENABLE_UI_ROW_CACHE'],trimmed=config['WTK_ENABLE_MEASUREMENT_TRIMMED'],flash_bytes=sizes['flash_bytes'],
        ram_accounted_bytes=sizes['ram_accounted_bytes'],status='PASS',files=files))
(root/'firmware-builds.json').write_text(json.dumps(report,indent=2),encoding='utf-8')








