from pathlib import Path
import sys,os,json,subprocess,struct,hashlib
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
r=Path('Firmware/build/calibration-20261025');o=r/'pre-trimmed-002';o.mkdir(exist_ok=False)
imagepath=r/'image-session-menu-001/manifest.json';image=d.inspect(imagepath,'FACTORY_PRODUCT');image['manifest_path']=str(imagepath.resolve())
old=d.load(r/'boot-session-menu-001/report.json')
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E');p=b.plan('verify',o,image,'54ff70068370525760380567');e=dict(os.environ,**p['environment']);commands=[]
for i,row in enumerate(old['layout']):
 e['WTK_META_'+str(i)]=str((o/(row['name']+'.bin')).resolve());commands.append('dump_image $::env(WTK_META_'+str(i)+') '+hex(row['address'])+' '+str(row['size']))

addresses={row['name']:row['address'] for row in old['layout']}
guard='if {[lindex [read_memory '+hex(addresses['k1_commanded_state'])+' 8 1] 0] != 1 || [lindex [read_memory '+hex(addresses['excitation_mode'])+' 8 1] 0] != 0 || [lindex [read_memory '+hex(addresses['measurement_hw_state'])+' 8 1] 0] != 0 || [lindex [read_memory '+hex(addresses['product_state'])+' 8 1] 0] == 19} {error "measurement active: no diagnostic halt"}'
p['argv'][-1]='if {[catch {init; '+guard+'; halt; '+guard+'; wtk_operation; '+'; '.join(commands)+'; resume; echo "WTK_POST_POWER_RESUMED"} reason]} {catch {resume}; echo $reason; shutdown error} else {shutdown}'
a=subprocess.run(p['argv'],env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'openocd.txt').write_bytes(a.stdout)
if a.returncode or a.stdout.count(b'WTK_POST_POWER_RESUMED')!=1:raise ValueError('Read-only verification/resume failed')
v=(o/'full-readback.bin').read_bytes();expected=(imagepath.parent/'firmware.bin').read_bytes()
if v[:len(expected)]!=expected:raise ValueError('Unexpected firmware after power interruption; do not use old ABI')
meta={row['name']:int.from_bytes((o/(row['name']+'.bin')).read_bytes(),'little') for row in old['layout']};flags=meta['safety_blocker_flags']
report=dict(utc=d.utc(),operation='TRIMMED_PREFLIGHT_OLD_VERIFIED_IMAGE_NO_MEASUREMENT',firmware_sha256=hashlib.sha256(expected).hexdigest(),exact_running_image_match=True,target=d.parse_target(a.stdout.decode(errors='replace')),metadata=meta,safety_blocker_flags=flags,battery_voltage_read_via_swd=False,capture_started=False,external_flash_written=False)
d.save(o/'report.json',report);print(json.dumps(report,indent=2),flush=True)
if meta['safety_fault_mask'] or meta['k1_commanded_state']!=1 or meta['range_enabled'] or meta['excitation_mode'] or meta['product_state']==19 or meta['quiet_requested'] or meta['calibration_sequence']!=1 or meta['calibration_record_count']!=33 or not meta['calibration_active_valid'] or flags&~12:raise ValueError('Post-power SAFE/calibration/hard-blocker state not confirmed')



if meta["session_connected"] or meta["measurement_hw_state"] or meta["workspace_owner"]:raise ValueError("Session/workspace remains active")

