#include <stddef.h>
#include "app/app_product.h"
#include "app/app_io_workspace.h"
#include "hardware/hw_k1.h"
#include "hardware/hw_range.h"
const unsigned offsets[]={offsetof(app_product_t,view)+offsetof(ui_product_view_t,state),offsetof(app_product_t,session_sequence),offsetof(app_product_t,initialized),offsetof(app_calibration_service_t,runtime)+offsetof(app_calibration_runtime_t,active_set)+offsetof(measurement_cal_set_t,sequence),offsetof(app_calibration_service_t,runtime)+offsetof(app_calibration_runtime_t,active_set)+offsetof(measurement_cal_set_t,record_count),offsetof(app_calibration_service_t,runtime)+offsetof(app_calibration_runtime_t,active_valid),offsetof(app_calibration_service_t,storage_available),offsetof(hw_k1_t,commanded_state),offsetof(hw_range_t,state),offsetof(hw_range_t,enabled),0,0,0,0,offsetof(hw_safety_result_t,blocker_flags),0,0,offsetof(app_settings_service_t,current)+offsetof(app_settings_t,brightness_percent),offsetof(hw_metrology_measure_t,state),offsetof(hw_metrology_measure_t,error),offsetof(hw_metrology_measure_t,session_connected),offsetof(hw_metrology_measure_t,session_capture_count),offsetof(app_io_workspace_t,owner),0};
