# Firmware deployment — REAL_BACKEND / NOT PHYSICALLY QUALIFIED

SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.

Outcome: INTERNAL_FLASH_VERIFIED

Programming: CONFIRMED; internal readback: PASS; boot: NOT_TESTED; UART: NOT_TESTED; application: NOT_TESTED.

External W25Q was not accessed. OSL/Resource Pack remain independently accepted prerequisites.

```json
{
  "schema": "WTK_DEPLOYMENT_1",
  "transaction": "1aed460a-b8c2-4d82-a13f-a64fbc4d8f1e",
  "operation": "program",
  "started_utc": "2026-10-27T01:33:54.087820+00:00",
  "SIMULATED": false,
  "image": {
    "schema": "WTK_FIRMWARE_2",
    "source": {
      "git_sha": "0443d3295bd92043493ae805c2763464109ec3fb",
      "dirty": false,
      "git_status": "",
      "input_sha256": "dfd7d9946f45b1e5792770a8aa7dd675d9c020eaf44b1bda63dc289fbb6ac821"
    },
    "profile": "FACTORY_PRODUCT",
    "factory_provisioned": true,
    "supplementary_curves": false,
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "bringup_k1_test": false,
    "bringup_bench_supply": false,
    "bringup_peripheral_test": false,
    "preset": "stm32-factory-release",
    "build_configuration": "Release",
    "hardware": "Rev1-STM32F103C8T6-BluePill",
    "firmware_version": "0.1.0",
    "expected_boot": {
      "interface": "LIMITED_UART_UI_REQUIRED",
      "firmware_version": "0.1.0",
      "hardware": "Rev1-STM32F103C8T6-BluePill",
      "git_prefix": null,
      "limitation": "PRODUCT banner is only WTK.RLCMeter SAFE_BOOT; UI/bench acceptance separate"
    },
    "toolchain": {
      "compiler_path": "C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin/arm-none-eabi-gcc.exe",
      "compiler_version": "arm-none-eabi-gcc.exe (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119",
      "cmake": "cmake version 4.4.4",
      "cache_sha256": "7155cfed1ff1b049409b492d5f587659ee44858b1317e780ee2bc034786920b3"
    },
    "memory": {
      "flash_base": 134217728,
      "flash_bytes": 65536,
      "ram_base": 536870912,
      "ram_bytes": 20480,
      "internal_page_bytes": 1024
    },
    "linked": {
      "flash_bytes": 60136,
      "bss": 14980,
      "ram_static_bytes": 15028,
      "noinit_bytes": 0,
      "reserved_stack_bytes": 2052,
      "ram_accounted_bytes": 17080
    },
    "binary_size": 60136,
    "files": {
      "firmware.bin": {
        "bytes": 60136,
        "sha256": "26cb50c86e798d0ca0b040ddd5ab3a6a1f8e9791145a504bd2e8c6f46fa8e20f"
      },
      "firmware.elf": {
        "bytes": 95304,
        "sha256": "345f2cce404e32e140f107c9583ba86468c7159a8612cbddc6d95e829ef2f71c"
      },
      "build_config.h": {
        "bytes": 1413,
        "sha256": "7db27b901cf048c37acd2baa0598aa001cbf0535dd85b1c70e662fb57628c983"
      },
      "linker.ld": {
        "bytes": 2244,
        "sha256": "1450e7143121ccf933b06af5d728b2ba60d5d41c4592748ff2a7ab77337c53c0"
      }
    },
    "built_utc": "2026-10-27T01:33:51.762213+00:00",
    "seal_sha256": "6ccf8e0160384e0b7d8fccfc4e19cf235d12a930efcfe7b81e2dce62a7e64d15",
    "manifest_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\image-survey-003\\manifest.json",
    "staged_binary": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-survey-003\\staged-image.bin"
  },
  "authorization": {
    "operator": "Rodrigo; owner explicitly requested all three frequency ranges before component classification and asked to upload the firmware with TTL COM4 reconnected and owner-confirmed 4700uF electrolytic connected; program only, no remote acquisition",
    "utc": "2026-10-27T01:33:53.978137+00:00",
    "board": "First Rev1 board, six RGS gate-to-GND rework",
    "expected_uid": "54ff70068370525760380567",
    "SIMULATED": false,
    "previous_profile": "FACTORY_PRODUCT",
    "next_profile": "FACTORY_PRODUCT",
    "image_sha256": "26cb50c86e798d0ca0b040ddd5ab3a6a1f8e9791145a504bd2e8c6f46fa8e20f",
    "manifest_seal": "6ccf8e0160384e0b7d8fccfc4e19cf235d12a930efcfe7b81e2dce62a7e64d15",
    "approval_origin": "Owner explicitly requested 1kHz/10kHz/10Hz survey for R/C/L and explicitly requested programming for display testing. No automatic DUT acquisition is requested. This image adds seven-sample coordinate-wise trimmed calibrated impedance, rejects incomplete estimates, and retains usable unclipped >=2mV evidence. It enables a twelve-search/eight-extra statistical workflow segmented by fresh real permits, 10Hz SAFE per capture, and unchanged 500ms fast connected and original battery deadlines, and exact row updates in PC-provisioned PRODUCT. Initial fresh permits, live hard aborts, neutral guarded ranges, SAFE final cleanup and calibration are retained. No unattended DUT measurement is triggered; physical relay/UI validation is pending owner interaction.",
    "scope": "Controlled calibrated PRODUCT handoff; internal Flash only; preserve exact active OSL sequence1, W25Q assets/settings and experimental UID-bound NTC; no DUT measurement commanded",
    "physical_qualification": false,
    "procedural_exception": {
      "owner_requested_proceed_without_scope": true,
      "scope_checks": "NOT_TESTED; no new physical qualification inferred",
      "b01_gate": "Independent scope/hardware qualification remains pending"
    },
    "preflight_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\pre-survey-003\\report.json",
    "supply": "Previously owner-confirmed battery/boost; battery voltage is not read via SWD and no old voltage is claimed as current; fresh pre-program metadata rejects any supply/charger/fault blockers; no battery voltage read over SWD",
    "preservation": "No external W25Q erase/program requested",
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "osl": {
      "sequence": 1,
      "sha256": "af76d19b15a510dff0c880a4ab6e86893e0065ac7e845b9930111680752da78c",
      "preserved_physical_readback": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\product-deploy-preflight-readback.bin",
      "preprogram_runtime_sequence": 1
    },
    "acknowledgements": {
      "safe_outputs": true,
      "debug_halt_watchdog": true,
      "no_app_bootloader": true,
      "internal_flash": true
    },
    "seal_sha256": "7e81b7fb9b50b853691c8d59c37e15098c0addf41ed7f07c62a9a6a62ffb9bab"
  },
  "programming": "CONFIRMED",
  "internal_readback": "PASS",
  "boot": "NOT_TESTED",
  "uart_identity": "NOT_TESTED",
  "application": "NOT_TESTED",
  "external_w25q_access": false,
  "physically_validated": false,
  "outcome": "INTERNAL_FLASH_VERIFIED",
  "error": null,
  "transcripts": [
    {
      "path": "preflight/openocd.txt",
      "sha256": "131c5a03bdcc52baf52834082989172fe494c5f83cfdd98c9988f5947d8b5943"
    },
    {
      "path": "openocd.txt",
      "sha256": "930638041d290e7b0ca3906eeb0518adc60547768a89ed8a0e58d111104ad5af"
    }
  ],
  "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.",
  "seal_sha256": "ef213f6fa952f8ae824305b3d44cda43bc3c0a3b89131ca3e060c06459512d57",
  "preflight": {
    "target": {
      "device_id": 537093136,
      "cpuid": 1092600369,
      "flash_kib": 64,
      "obr": 67108860,
      "wrpr": 4294967295,
      "uid": "54ff70068370525760380567",
      "flash_base": 134217728,
      "flash_bytes": 65536,
      "driver": "stm32f1x",
      "state": "halted",
      "target_voltage_v": 3.301002
    },
    "programmer": {
      "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
      "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
      "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "config_hashes": {
        "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
        "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
      },
      "toolkit_script_sha256": "43bcdb67c2ce390bfd6adb0db481e7f046cc004aa0555976a0830e778cd6a968",
      "deployment_tool_sha256": "36e6df40f36b1bc2588561cc9b3cc16543c235425c65acaf7dade80b5abb1e05",
      "adapter_serial_selection": "530049000C0000513751594E"
    },
    "plan": {
      "argv": [
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
        "-s",
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
        "-c",
        "source $::env(WTK_INTERFACE)",
        "-c",
        "transport select dapdirect_swd",
        "-c",
        "adapter serial $::env(WTK_SERIAL)",
        "-c",
        "source $::env(WTK_TARGET)",
        "-c",
        "gdb_port disabled; tcl_port disabled; telnet_port disabled",
        "-c",
        "source $::env(WTK_LIBRARY)",
        "-c",
        "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
      ],
      "environment": {
        "WTK_SERIAL": "530049000C0000513751594E",
        "WTK_ACTION": "probe",
        "WTK_UID": "54ff70068370525760380567",
        "WTK_LENGTH": "0",
        "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
        "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
        "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
        "WTK_IMAGE": "",
        "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-survey-003\\preflight\\before.bin",
        "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-survey-003\\preflight\\full-readback.bin"
      },
      "internal_flash_range": [
        134217728,
        134283264
      ],
      "program_range": null,
      "erase_range": null,
      "external_w25q_access": false,
      "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
    }
  },
  "target": {
    "device_id": 537093136,
    "cpuid": 1092600369,
    "flash_kib": 64,
    "obr": 67108860,
    "wrpr": 4294967295,
    "uid": "54ff70068370525760380567",
    "flash_base": 134217728,
    "flash_bytes": 65536,
    "driver": "stm32f1x",
    "state": "halted",
    "target_voltage_v": 3.299399
  },
  "programmer": {
    "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
    "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
    "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
    "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
    "config_hashes": {
      "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
      "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
    },
    "toolkit_script_sha256": "43bcdb67c2ce390bfd6adb0db481e7f046cc004aa0555976a0830e778cd6a968",
    "deployment_tool_sha256": "36e6df40f36b1bc2588561cc9b3cc16543c235425c65acaf7dade80b5abb1e05",
    "adapter_serial_selection": "530049000C0000513751594E"
  },
  "plan": {
    "argv": [
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "-s",
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "-c",
      "source $::env(WTK_INTERFACE)",
      "-c",
      "transport select dapdirect_swd",
      "-c",
      "adapter serial $::env(WTK_SERIAL)",
      "-c",
      "source $::env(WTK_TARGET)",
      "-c",
      "gdb_port disabled; tcl_port disabled; telnet_port disabled",
      "-c",
      "source $::env(WTK_LIBRARY)",
      "-c",
      "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
    ],
    "environment": {
      "WTK_SERIAL": "530049000C0000513751594E",
      "WTK_ACTION": "program",
      "WTK_UID": "54ff70068370525760380567",
      "WTK_LENGTH": "60136",
      "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
      "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
      "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
      "WTK_IMAGE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-survey-003\\staged-image.bin",
      "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-survey-003\\before.bin",
      "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-survey-003\\full-readback.bin"
    },
    "internal_flash_range": [
      134217728,
      134283264
    ],
    "program_range": [
      134217728,
      134277864
    ],
    "erase_range": [
      134217728,
      134278144
    ],
    "external_w25q_access": false,
    "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
  },
  "readback": {
    "start": 134217728,
    "end_exclusive": 134277864,
    "bytes": 60136,
    "expected_sha256": "26cb50c86e798d0ca0b040ddd5ab3a6a1f8e9791145a504bd2e8c6f46fa8e20f",
    "actual_sha256": "26cb50c86e798d0ca0b040ddd5ab3a6a1f8e9791145a504bd2e8c6f46fa8e20f",
    "full_flash_sha256": "321829befee5f920c6d7246788c0e0497572102e207813715f31344ebf50dd75",
    "full_flash_bytes": 65536
  },
  "unaffected_internal_pages_preserved": true,
  "next_step": "Separately boot PRODUCT; limited SAFE_BOOT UART banner cannot prove SHA/calibration/resources/readiness. Inspect UI and physical checklist.",
  "completed_utc": "2026-10-27T01:34:01.455716+00:00"
}
```
