"""Package and program the existing tested PC-provisioned PRODUCT image.
No acquisition START, calibration write or external-flash mutation.
"""
import json,sys,hashlib,subprocess,time
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import pc_bringup as b
import pc_cal_capture as c
from pc_osl_install import Installer,validate_candidate
root=Path(__file__).resolve().parent
builds=root/'verified-builds-survey'
matrix=d.load(builds/'firmware-builds.json')
ref=matrix['source']['git_sha']
if subprocess.check_output(['git','diff',ref,'HEAD','--','Firmware/src','Firmware/config','Firmware/cmake','Firmware/CMakeLists.txt','Firmware/CMakePresets.json']):raise ValueError('Embedded source changed since verified matrix')
case=next(v for v in matrix['cases'] if v['name']=='factory-release')
if case['status']!='PASS' or case['profile']!='PRODUCT' or case['factory']!='1u':raise ValueError('PC-provisioned production build required')
for n,meta in case['files'].items():
 if hashlib.sha256((builds/'factory-release'/n).read_bytes()).hexdigest()!=meta['sha256']:raise ValueError('Verified build changed')
imagepath=root/'image-survey-001'
if imagepath.exists():raise ValueError('Do not reuse an image output directory')
image=d.manifest(builds/'factory-release',imagepath,'FACTORY_PRODUCT',matrix['source'],'stm32-factory-release')
image=d.inspect(imagepath/'manifest.json','FACTORY_PRODUCT')
subprocess.run([sys.executable,str(root/'preflight_survey.py')],check=True)
pre=d.load(root/'pre-survey-001/report.json')
if not pre['exact_running_image_match'] or pre['metadata']['calibration_sequence']!=1 or not pre['metadata']['calibration_active_valid']:
 raise ValueError('Fresh post-power calibration and SAFE metadata required')
identity=dict(uid=pre['target']['uid'])
frame=(root/'condition-composition-003/candidate.bin').read_bytes();validate_candidate(frame)
if hashlib.sha256(frame).hexdigest()!='af76d19b15a510dff0c880a4ab6e86893e0065ac7e845b9930111680752da78c':raise ValueError('Canonical calibration evidence changed')
auth=dict(operator='Rodrigo; owner explicitly requested all three frequency ranges before component classification and asked to upload the firmware with display connected and terminals empty',utc=d.utc(),board='First Rev1 board, six RGS gate-to-GND rework',expected_uid=identity['uid'],SIMULATED=False,previous_profile='FACTORY_PRODUCT',next_profile='FACTORY_PRODUCT',image_sha256=image['files']['firmware.bin']['sha256'],manifest_seal=image['seal_sha256'],approval_origin='Owner explicitly requested 1kHz/10kHz/10Hz survey for R/C/L and explicitly requested programming for display testing. No automatic DUT acquisition is requested. This image adds seven-sample coordinate-wise trimmed calibrated impedance, rejects incomplete estimates, and retains usable unclipped >=2mV evidence. It enables a twelve-search/eight-extra statistical workflow segmented by fresh real permits, 10Hz SAFE per capture, and unchanged 500ms fast connected and original battery deadlines, and exact row updates in PC-provisioned PRODUCT. Initial fresh permits, live hard aborts, neutral guarded ranges, SAFE final cleanup and calibration are retained. No unattended DUT measurement is triggered; physical relay/UI validation is pending owner interaction.',scope='Controlled calibrated PRODUCT handoff; internal Flash only; preserve exact active OSL sequence1, W25Q assets/settings and experimental UID-bound NTC; no DUT measurement commanded',physical_qualification=False,procedural_exception=dict(owner_requested_proceed_without_scope=True,scope_checks='NOT_TESTED; no new physical qualification inferred',b01_gate='Independent scope/hardware qualification remains pending'),preflight_path=str(root/'pre-survey-001/report.json'),supply='Previously owner-confirmed battery/boost; battery voltage is not read via SWD and no old voltage is claimed as current; fresh pre-program metadata rejects any supply/charger/fault blockers; no battery voltage read over SWD',preservation='No external W25Q erase/program requested',ntc_factory_profile=image['ntc_factory_profile'],osl=dict(sequence=1,sha256=hashlib.sha256(frame).hexdigest(),preserved_physical_readback=str(root/'product-deploy-preflight-readback.bin'),preprogram_runtime_sequence=pre['metadata']['calibration_sequence']),acknowledgements=dict(safe_outputs=True,debug_halt_watchdog=True,no_app_bootloader=True,internal_flash=True))
auth['seal_sha256']=d.seal(auth);d.save(root/'deployment-survey-authorization-001.json',auth)
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
record=d.deployment('program',imagepath/'manifest.json',backend,root/'deployment-survey-001',authorization=auth,uid=identity['uid'])
print(json.dumps({k:record.get(k) for k in ('outcome','readback','error')},indent=2),flush=True)
if record['outcome']!='INTERNAL_FLASH_VERIFIED':raise SystemExit(1)
