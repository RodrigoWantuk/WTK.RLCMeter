import survey_live_support as s
r=s.R;o=r/'survey-live-postflight-003';o.mkdir(exist_ok=False)
report=s.snapshot(o,r/'image-survey-003/manifest.json',s.d.load(r/'boot-survey-003/report.json')['layout'])
print(report['metadata'])
