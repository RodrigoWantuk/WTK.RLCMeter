from pathlib import Path
import json
import survey_live_support as s
r=s.R;o=r/'pre-survey-002';o.mkdir(exist_ok=False)
report=s.snapshot(o,r/'image-survey-001/manifest.json',s.d.load(r/'survey-live-layout.json'))
print(json.dumps(report,indent=2),flush=True)
