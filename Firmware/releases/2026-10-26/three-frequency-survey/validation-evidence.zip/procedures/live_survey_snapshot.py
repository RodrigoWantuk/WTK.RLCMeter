from pathlib import Path
import sys,os,subprocess,json,hashlib
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
r=Path(__file__).resolve().parent;o=r/'survey-live-postflight-001';o.mkdir(exist_ok=False)
layout=d.load(r/'survey-live-layout.json')
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
p=b.plan('probe',o,None,'54ff70068370525760380567');env=dict(os.environ,**p['environment']);commands=[]
for i,row in enumerate(layout):
 env['WTK_LIVE_'+str(i)]=str((o/(row['name']+'.bin')).resolve());commands.append('dump_image $::env(WTK_LIVE_'+str(i)+') '+hex(row['address'])+' '+str(row['size']))
env['WTK_LIVE_UID']=str((o/'uid.bin').resolve())
p['argv'][-1]='if {[catch {init; echo "WTK_LIVE_PRE|[stm32f1x.cpu curstate]"; dump_image $::env(WTK_LIVE_UID) 0x1ffff7e8 12; '+'; '.join(commands)+'; echo "WTK_LIVE_POST|[stm32f1x.cpu curstate]"; echo "WTK_LIVE_NO_HALT_COMPLETE"} reason]} {echo $reason; shutdown error} else {shutdown}'
a=subprocess.run(p['argv'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'openocd.txt').write_bytes(a.stdout)
if a.returncode or a.stdout.count(b'WTK_LIVE_NO_HALT_COMPLETE')!=1:raise ValueError('Live read failed; no reset/halt/resume requested')
uid=(o/'uid.bin').read_bytes().hex()
if uid!='54ff70068370525760380567':raise ValueError('Live UID mismatch')
meta={row['name']:int.from_bytes((o/(row['name']+'.bin')).read_bytes(),'little') for row in layout}
safe=meta['k1_commanded_state']==1 and not any(meta[k] for k in ['range_enabled','excitation_mode','measurement_hw_state','session_connected','quiet_requested','workspace_owner']) and meta['product_state']!=19
report=dict(utc=d.utc(),operation='LIVE_DAP_METADATA_NO_HALT_NO_RESET_NO_RESUME_NO_CAPTURE',uid=uid,metadata=meta,safe=safe,battery_voltage_read=False,halt_requested=False,reset_requested=False,measurement_requested=False,layout=layout)
d.save(o/'report.json',report);print(json.dumps(report,indent=2),flush=True)
if not safe:raise SystemExit(2)
