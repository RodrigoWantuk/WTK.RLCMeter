	.cpu cortex-m3
	.arch armv7-m
	.fpu softvfp
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 6
	.eabi_attribute 34, 1
	.eabi_attribute 18, 4
	.file	"layout.c"
	.text
	.global	sizes
	.section	.rodata
	.align	2
	.type	sizes, %object
	.size	sizes, 36
sizes:
	.word	124
	.word	56
	.word	120
	.word	121
	.word	122
	.word	2619
	.word	2620
	.word	2621
	.word	2622
	.ident	"GCC: (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119"
