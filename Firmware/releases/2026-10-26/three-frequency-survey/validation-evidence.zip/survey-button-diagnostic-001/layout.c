#include <stddef.h>
#include "drivers/buttons.h"
#include "app/app_product.h"
const unsigned sizes[]={sizeof(buttons_t),offsetof(buttons_t,events),offsetof(buttons_t,event_head),offsetof(buttons_t,event_tail),offsetof(buttons_t,event_count),offsetof(app_product_t,runtime_teardown_kind),offsetof(app_product_t,runtime_teardown_target_state),offsetof(app_product_t,ok_armed),offsetof(app_product_t,ok_long_seen)};
