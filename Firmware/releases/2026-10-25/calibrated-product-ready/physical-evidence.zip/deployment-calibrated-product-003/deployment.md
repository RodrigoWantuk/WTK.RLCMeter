# Firmware deployment — REAL_BACKEND / NOT PHYSICALLY QUALIFIED

SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.

Outcome: INTERNAL_FLASH_VERIFIED

Programming: CONFIRMED; internal readback: PASS; boot: NOT_TESTED; UART: NOT_TESTED; application: NOT_TESTED.

External W25Q was not accessed. OSL/Resource Pack remain independently accepted prerequisites.

```json
{
  "schema": "WTK_DEPLOYMENT_1",
  "transaction": "d0386b96-6b0c-49c0-975c-971f02da95cf",
  "operation": "program",
  "started_utc": "2026-10-25T22:37:43.618309+00:00",
  "SIMULATED": false,
  "image": {
    "schema": "WTK_FIRMWARE_2",
    "source": {
      "git_sha": "8849cfa2c29a3a4a174f01692de22673ad385028",
      "dirty": false,
      "git_status": "",
      "input_sha256": "e42fc4d4136ac839fa2c719d9375d679f9abf7560614225cf58693659ab5ac00"
    },
    "profile": "FACTORY_PRODUCT",
    "factory_provisioned": true,
    "supplementary_curves": false,
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "bringup_k1_test": false,
    "bringup_bench_supply": false,
    "bringup_peripheral_test": false,
    "preset": "stm32-factory-release",
    "build_configuration": "Release",
    "hardware": "Rev1-STM32F103C8T6-BluePill",
    "firmware_version": "0.1.0",
    "expected_boot": {
      "interface": "LIMITED_UART_UI_REQUIRED",
      "firmware_version": "0.1.0",
      "hardware": "Rev1-STM32F103C8T6-BluePill",
      "git_prefix": null,
      "limitation": "PRODUCT banner is only WTK.RLCMeter SAFE_BOOT; UI/bench acceptance separate"
    },
    "toolchain": {
      "compiler_path": "C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin/arm-none-eabi-gcc.exe",
      "compiler_version": "arm-none-eabi-gcc.exe (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119",
      "cmake": "cmake version 4.4.4",
      "cache_sha256": "c0f0c981e5fc84f91d94292a4da788c10b584c0f73321087f743f0f24aa22df5"
    },
    "memory": {
      "flash_base": 134217728,
      "flash_bytes": 65536,
      "ram_base": 536870912,
      "ram_bytes": 20480,
      "internal_page_bytes": 1024
    },
    "linked": {
      "flash_bytes": 54224,
      "bss": 13468,
      "ram_static_bytes": 13516,
      "noinit_bytes": 0,
      "reserved_stack_bytes": 2052,
      "ram_accounted_bytes": 15568
    },
    "binary_size": 54224,
    "files": {
      "firmware.bin": {
        "bytes": 54224,
        "sha256": "794c6596ac4b955bbea12e386977d3428c58a186175797a425e40070536b9cef"
      },
      "firmware.elf": {
        "bytes": 89196,
        "sha256": "ee6c6ba080bd37b4e2c090e25af349c7cd673c9446f5cce630902c15d9585b78"
      },
      "build_config.h": {
        "bytes": 1094,
        "sha256": "50c52d4763044ddf216e827a3a4266b0355efdba6768c7ba3c554323659bce3e"
      },
      "linker.ld": {
        "bytes": 2244,
        "sha256": "1450e7143121ccf933b06af5d728b2ba60d5d41c4592748ff2a7ab77337c53c0"
      }
    },
    "built_utc": "2026-10-25T22:37:41.458913+00:00",
    "seal_sha256": "38546adba61412c380892c3a27ace69e3b99efb85a85a52da0cb8fa61f2b7c49",
    "manifest_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\image-calibrated-product-003\\manifest.json",
    "staged_binary": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-003\\staged-image.bin"
  },
  "authorization": {
    "operator": "Rodrigo; owner-directed continuation into calibrated production without another resistor campaign",
    "utc": "2026-10-25T22:37:43.559283+00:00",
    "board": "First Rev1 board, six RGS gate-to-GND rework",
    "expected_uid": "54ff70068370525760380567",
    "SIMULATED": false,
    "previous_profile": "FACTORY_PRODUCT",
    "next_profile": "FACTORY_PRODUCT",
    "image_sha256": "794c6596ac4b955bbea12e386977d3428c58a186175797a425e40070536b9cef",
    "manifest_seal": "38546adba61412c380892c3a27ace69e3b99efb85a85a52da0cb8fa61f2b7c49",
    "approval_origin": "Owner requested next step without resistor tests and explicitly resumed after power interruption; programming and initial pilot are preserved; this image corrects product scheduling only",
    "scope": "Controlled calibrated PRODUCT handoff; internal Flash only; preserve exact active OSL sequence1, W25Q assets/settings and experimental UID-bound NTC; no DUT measurement commanded",
    "physical_qualification": false,
    "procedural_exception": {
      "owner_requested_proceed_without_scope": true,
      "scope_checks": "NOT_TESTED; no new physical qualification inferred",
      "programming_only_supply_expiry": "Old PRODUCT auxiliary starvation may invalidate battery age; allow internal-Flash repair only when measured 3V3 is valid and expiry-only UNKNOWN is proved by age>2000ms; no measurement gate is changed or bypassed",
      "fresh_supply_metadata": {
        "utc": "2026-10-25T22:37:43.521824+00:00",
        "operation": "POST_POWER_READ_ONLY_INTERNAL_FLASH_AND_METADATA",
        "firmware_sha256": "b4ff21efaad1928731b4db07616dbc134d3087ee15e8d48694a0fcbbac758e3d",
        "exact_running_image_match": true,
        "target": {
          "device_id": 537093136,
          "cpuid": 1092600369,
          "flash_kib": 64,
          "obr": 67108860,
          "wrpr": 4294967295,
          "uid": "54ff70068370525760380567",
          "flash_base": 134217728,
          "flash_bytes": 65536,
          "driver": "stm32f1x",
          "state": "halted",
          "target_voltage_v": 3.294997
        },
        "metadata": {
          "product_state": 21,
          "measurement_session_sequence": 0,
          "product_initialized": 1,
          "calibration_sequence": 1,
          "calibration_record_count": 33,
          "calibration_active_valid": 1,
          "calibration_storage_available": 1,
          "k1_commanded_state": 1,
          "range_fsm_state": 0,
          "range_enabled": 0,
          "safety_fault_mask": 0,
          "display_fault": 0,
          "resource_status": 0,
          "excitation_mode": 0,
          "quiet_requested": 0
        },
        "safety_blocker_flags": 12,
        "battery_voltage_read_via_swd": false,
        "capture_started": false,
        "external_flash_written": false,
        "battery_state_only": 0,
        "battery_age_ms": 1154,
        "stale_battery_publication": false
      },
      "b01_gate": "Independent scope/hardware qualification remains pending"
    },
    "preflight_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\post-power-product-preflight-003\\report.json",
    "supply": "Previously owner-confirmed battery/boost; latest battery voltage 3.873 V was read over serial before PRODUCT; fresh post-power metadata rejects actual critical battery/charger/fault; expiry-only UNKNOWN is a documented internal-Flash repair exception; no battery voltage read over SWD",
    "preservation": "No external W25Q erase/program requested",
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "osl": {
      "sequence": 1,
      "sha256": "af76d19b15a510dff0c880a4ab6e86893e0065ac7e845b9930111680752da78c",
      "preserved_physical_readback": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\product-deploy-preflight-readback.bin",
      "post_power_runtime_sequence": 1
    },
    "acknowledgements": {
      "safe_outputs": true,
      "debug_halt_watchdog": true,
      "no_app_bootloader": true,
      "internal_flash": true
    },
    "seal_sha256": "18eeecf1578b2e68a7cebb4a947f095164d781e178d8a2ecdfe7c1a6faf41816"
  },
  "programming": "CONFIRMED",
  "internal_readback": "PASS",
  "boot": "NOT_TESTED",
  "uart_identity": "NOT_TESTED",
  "application": "NOT_TESTED",
  "external_w25q_access": false,
  "physically_validated": false,
  "outcome": "INTERNAL_FLASH_VERIFIED",
  "error": null,
  "transcripts": [
    {
      "path": "preflight/openocd.txt",
      "sha256": "ce49a27b7de6e4551570890dfedc39238b1af14b47a36fcbf10878730fe88550"
    },
    {
      "path": "openocd.txt",
      "sha256": "fc0710f6eba996bb549794c4da4f3a4d6aac35c7aad45edc74e70e7849409ae4"
    }
  ],
  "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.",
  "seal_sha256": "daf8e6ed7e3f74e349347fa7f8888b6b27fc110606fd77d37aee4883163b0df3",
  "preflight": {
    "target": {
      "device_id": 537093136,
      "cpuid": 1092600369,
      "flash_kib": 64,
      "obr": 67108860,
      "wrpr": 4294967295,
      "uid": "54ff70068370525760380567",
      "flash_base": 134217728,
      "flash_bytes": 65536,
      "driver": "stm32f1x",
      "state": "halted",
      "target_voltage_v": 3.294997
    },
    "programmer": {
      "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
      "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
      "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "config_hashes": {
        "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
        "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
      },
      "toolkit_script_sha256": "43bcdb67c2ce390bfd6adb0db481e7f046cc004aa0555976a0830e778cd6a968",
      "deployment_tool_sha256": "36e6df40f36b1bc2588561cc9b3cc16543c235425c65acaf7dade80b5abb1e05",
      "adapter_serial_selection": "530049000C0000513751594E"
    },
    "plan": {
      "argv": [
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
        "-s",
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
        "-c",
        "source $::env(WTK_INTERFACE)",
        "-c",
        "transport select dapdirect_swd",
        "-c",
        "adapter serial $::env(WTK_SERIAL)",
        "-c",
        "source $::env(WTK_TARGET)",
        "-c",
        "gdb_port disabled; tcl_port disabled; telnet_port disabled",
        "-c",
        "source $::env(WTK_LIBRARY)",
        "-c",
        "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
      ],
      "environment": {
        "WTK_SERIAL": "530049000C0000513751594E",
        "WTK_ACTION": "probe",
        "WTK_UID": "54ff70068370525760380567",
        "WTK_LENGTH": "0",
        "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
        "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
        "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
        "WTK_IMAGE": "",
        "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-003\\preflight\\before.bin",
        "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-003\\preflight\\full-readback.bin"
      },
      "internal_flash_range": [
        134217728,
        134283264
      ],
      "program_range": null,
      "erase_range": null,
      "external_w25q_access": false,
      "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
    }
  },
  "target": {
    "device_id": 537093136,
    "cpuid": 1092600369,
    "flash_kib": 64,
    "obr": 67108860,
    "wrpr": 4294967295,
    "uid": "54ff70068370525760380567",
    "flash_base": 134217728,
    "flash_bytes": 65536,
    "driver": "stm32f1x",
    "state": "halted",
    "target_voltage_v": 3.294997
  },
  "programmer": {
    "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
    "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
    "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
    "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
    "config_hashes": {
      "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
      "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
    },
    "toolkit_script_sha256": "43bcdb67c2ce390bfd6adb0db481e7f046cc004aa0555976a0830e778cd6a968",
    "deployment_tool_sha256": "36e6df40f36b1bc2588561cc9b3cc16543c235425c65acaf7dade80b5abb1e05",
    "adapter_serial_selection": "530049000C0000513751594E"
  },
  "plan": {
    "argv": [
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "-s",
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "-c",
      "source $::env(WTK_INTERFACE)",
      "-c",
      "transport select dapdirect_swd",
      "-c",
      "adapter serial $::env(WTK_SERIAL)",
      "-c",
      "source $::env(WTK_TARGET)",
      "-c",
      "gdb_port disabled; tcl_port disabled; telnet_port disabled",
      "-c",
      "source $::env(WTK_LIBRARY)",
      "-c",
      "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
    ],
    "environment": {
      "WTK_SERIAL": "530049000C0000513751594E",
      "WTK_ACTION": "program",
      "WTK_UID": "54ff70068370525760380567",
      "WTK_LENGTH": "54224",
      "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
      "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
      "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
      "WTK_IMAGE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-003\\staged-image.bin",
      "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-003\\before.bin",
      "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-003\\full-readback.bin"
    },
    "internal_flash_range": [
      134217728,
      134283264
    ],
    "program_range": [
      134217728,
      134271952
    ],
    "erase_range": [
      134217728,
      134272000
    ],
    "external_w25q_access": false,
    "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
  },
  "readback": {
    "start": 134217728,
    "end_exclusive": 134271952,
    "bytes": 54224,
    "expected_sha256": "794c6596ac4b955bbea12e386977d3428c58a186175797a425e40070536b9cef",
    "actual_sha256": "794c6596ac4b955bbea12e386977d3428c58a186175797a425e40070536b9cef",
    "full_flash_sha256": "bf9e63d73e30b3b20dd315194caa9afbd3ff0747b169cae6e3c2438d8f4a2175",
    "full_flash_bytes": 65536
  },
  "unaffected_internal_pages_preserved": true,
  "next_step": "Separately boot PRODUCT; limited SAFE_BOOT UART banner cannot prove SHA/calibration/resources/readiness. Inspect UI and physical checklist.",
  "completed_utc": "2026-10-25T22:37:50.869307+00:00"
}
```
