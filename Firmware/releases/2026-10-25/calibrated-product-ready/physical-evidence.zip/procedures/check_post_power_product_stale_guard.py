from pathlib import Path
import sys,os,json,subprocess,struct,hashlib
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
r=Path('Firmware/build/calibration-20261025');o=r/'post-power-product-preflight-003';o.mkdir(exist_ok=False)
imagepath=r/'image-calibrated-product-001/manifest.json';image=d.inspect(imagepath,'FACTORY_PRODUCT');image['manifest_path']=str(imagepath.resolve())
old=d.load(r/'boot-calibrated-product-001/report.json')
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E');p=b.plan('verify',o,image,'54ff70068370525760380567');e=dict(os.environ,**p['environment']);commands=[]
for i,row in enumerate(old['layout']):
 e['WTK_META_'+str(i)]=str((o/(row['name']+'.bin')).resolve());commands.append('dump_image $::env(WTK_META_'+str(i)+') '+hex(row['address'])+' '+str(row['size']))
e['WTK_BAT_STATE']=str((o/'battery-state-only.bin').resolve());e['WTK_BAT_STAMP']=str((o/'battery-timestamp-only.bin').resolve());e['WTK_NOW']=str((o/'time.bin').resolve());e['WTK_SAFETY']=str((o/'raw-safety.bin').resolve());commands.extend(['dump_image $::env(WTK_SAFETY) 0x200004b0 12','dump_image $::env(WTK_BAT_STATE) 0x2000044c 1','dump_image $::env(WTK_BAT_STAMP) 0x20000488 4','dump_image $::env(WTK_NOW) 0x200001a4 4'])
p['argv'][-1]='if {[catch {init; halt; wtk_operation; '+'; '.join(commands)+'; resume; echo "WTK_POST_POWER_RESUMED"} reason]} {catch {resume}; echo $reason; shutdown error} else {shutdown}'
a=subprocess.run(p['argv'],env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'openocd.txt').write_bytes(a.stdout)
if a.returncode or a.stdout.count(b'WTK_POST_POWER_RESUMED')!=1:raise ValueError('Read-only verification/resume failed')
v=(o/'full-readback.bin').read_bytes();expected=(imagepath.parent/'firmware.bin').read_bytes()
if v[:len(expected)]!=expected:raise ValueError('Unexpected firmware after power interruption; do not use old ABI')
meta={row['name']:int.from_bytes((o/(row['name']+'.bin')).read_bytes(),'little') for row in old['layout']};raw=(o/'raw-safety.bin').read_bytes();flags=struct.unpack_from('<I',raw,4)[0]
report=dict(utc=d.utc(),operation='POST_POWER_READ_ONLY_INTERNAL_FLASH_AND_METADATA',firmware_sha256=hashlib.sha256(expected).hexdigest(),exact_running_image_match=True,target=d.parse_target(a.stdout.decode(errors='replace')),metadata=meta,safety_blocker_flags=flags,battery_voltage_read_via_swd=False,capture_started=False,external_flash_written=False)
bat_state=(o/'battery-state-only.bin').read_bytes()[0];bat_age=(int.from_bytes((o/'time.bin').read_bytes(),'little')-int.from_bytes((o/'battery-timestamp-only.bin').read_bytes(),'little'))&0xffffffff;report.update(battery_state_only=bat_state,battery_age_ms=bat_age,stale_battery_publication=(bat_state==3 and bat_age>2000));d.save(o/'report.json',report);print(json.dumps(report,indent=2),flush=True)
if meta['safety_fault_mask'] or meta['k1_commanded_state']!=1 or meta['range_enabled'] or meta['excitation_mode'] or meta['measurement_session_sequence'] or meta['calibration_sequence']!=1 or meta['calibration_record_count']!=33 or not meta['calibration_active_valid'] or (flags&~12 and not (flags&~28==0 and report['stale_battery_publication'])):raise ValueError('Post-power SAFE/calibration/hard-blocker state not confirmed')
