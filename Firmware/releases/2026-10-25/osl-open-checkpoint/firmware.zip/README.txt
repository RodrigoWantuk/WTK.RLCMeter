Firmware source 063c7378319f293640d6d19d5fadcb3fa3ad686f
Nine software builds passed. OPEN-only engineering checkpoint; no calibration installation, production release or accuracy qualification.
