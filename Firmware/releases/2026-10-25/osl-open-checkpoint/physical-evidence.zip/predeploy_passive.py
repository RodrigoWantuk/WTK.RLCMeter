"""No-reset passive power/interlock snapshot of the running standard BRINGUP."""
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_firmware_deploy as d

root = Path('Firmware/build/splash-20261024').resolve()
if len(sys.argv) != 3 or sys.argv[1] not in ('off-dmm-001','charger-on-001','charger-on-002','charger-off-001','assets-preflight-001','assets-final-001','calibration-predeploy-001') or sys.argv[2] not in ('ABSENT','PRESENT'):
    raise ValueError('Requires bounded stage and expected charger state')
label, expected_charger = sys.argv[1:]
boot = d.load(root/'boot-final-after-readback/report.json')
image = d.inspect(root/'final-image/manifest.json','BRINGUP')
if boot['outcome'] != 'PASSIVE_STATUS_COLLECTED' or boot['identity']['git'] != image['expected_boot']['git_prefix']:
    raise ValueError('Missing preceding physical image identity')
out = Path('Firmware/build/calibration-20261025/predeploy-passive').resolve()
out.mkdir(exist_ok=False)
events, received, responses = [], [], []
allowed = ('lab charger status','lab fault status','lab safety status',
    'lab range status','lab sensors status','lab mvp status')
report = dict(recorded_utc=d.utc(),simulated=False,operation='PASSIVE_POWER_NO_RESET',
    port='COM4',stage=label,expected_charger=expected_charger,
    image_sha256=image['files']['firmware.bin']['sha256'],
    preceding_boot_identity=boot['identity'],error=None)
link = b.open_serial('COM4')
reader = b.Reader(link,events)

def query(command):
    if command not in allowed:
        raise ValueError('Passive whitelist violation')
    packet=(command+'\n').encode('ascii')
    time.sleep(0.1)
    reader.event('TX',command=command,hex=packet.hex())
    for byte in packet:
        if link.write(bytes([byte])) != 1:
            raise b.ProtocolError('Partial write; no retry')
        time.sleep(0.005)
    lines=[]
    deadline=time.monotonic()+5
    for _ in range(60):
        value=reader.line(deadline)
        received.append(value)
        if 'WTK.RLCMeter' in value or value.startswith('profile:'):
            raise b.ResetError('Unexpected reset; fresh boot identity required')
        if b.asynchronous(value):
            reader.event('INTERLEAVED',line=value)
            continue
        lines.append(value)
        if b.complete(command,lines):
            parsed=b.parse_response(command,lines)
            responses.append(dict(command=command,lines=lines,values=parsed))
            print(command+': '+json.dumps(parsed),flush=True)
            return parsed
    raise b.ProtocolError('Response bound exceeded')

try:
    charger=query('lab charger status')
    faults=query('lab fault status')
    safety=query('lab safety status')
    ranges=query('lab range status')
    for _ in range(3):
        query('lab sensors status')
        time.sleep(0.5)
    mvp=query('lab mvp status')
    report['checks']=dict(charger_matches=charger['charger']==expected_charger,
        no_faults=faults['fault_mask']==0,k1_safe=mvp['k1.k1']=='SAFE',
        range_disabled=ranges['state']=='DISABLED',
        charger_block=(safety['blocker']=='BLOCKED_CHARGER' and not safety['allowed']) if expected_charger=='PRESENT' else None)
    if not all(value for value in report['checks'].values() if value is not None):
        raise ValueError('Observed status did not satisfy expected stage checks')
    report['outcome']='EXPECTED_PASSIVE_STATE_OBSERVED'
except Exception as exc:
    report.update(outcome='INCOMPLETE',error=type(exc).__name__+': '+str(exc))
    raise
finally:
    link.close()
    report['responses']=responses
    d.save(out/'report.json',report)
    d.save(out/'events.json',events)
    (out/'uart-rx.txt').write_bytes(('\n'.join(received)+'\n').encode('ascii'))
    print(json.dumps({key:report.get(key) for key in ('outcome','checks','error')},indent=2),flush=True)
