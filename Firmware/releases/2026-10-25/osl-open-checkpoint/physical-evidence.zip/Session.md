# First-board engineering OSL session

Owner explicitly requested proceeding directly to calibration using previous DC
checks while the Hantek is unavailable. Oscilloscope-dependent physical checks
remain NOT_TESTED; the desktop B01 gate is unchanged and is not approved. This
is an engineering acquisition campaign, not production qualification. The
supported capture backend retains every embedded safety permit and teardown
check. No physical evidence is relabelled PASS.

The verified BRINGUP_CAL image is from source adfce3c59aac085a95b7fa487fed5f836dca21ec,
hardware 0x00010002/model 5, with capture and installation services available.
Internal programming readback passed. Programming itself requests no W25Q
erase/program. Calibration installation remains a separate later operation.

LOAD anchors are nominal 10 / 100 / 1000 / 10000 / 100000 / 1000000 ohm,
proposed marked tolerance +/-1%. Owner readings are respectively 10.5 / 99.7 /
992 / 9990 / 99800 / 995000 ohm. Three color identifications remain inferred or
uncertain and are preserved in the owner evidence. No certified actual values
or DMM uncertainty intervals are invented. Each LOAD must be measured again
immediately before attachment as requested by the owner.

Fixture: direct DUT terminal attachment; enclosure and final test leads absent.
Future test-lead installation requires calibration in the final geometry.
SHORT construction is not yet confirmed. No acquisition is requested until
the owner confirms the exact passive fixture for the requested capture.

## Current correction and battery checkpoint

The engineering capture source is now 063c7378319f293640d6d19d5fadcb3fa3ad686f.
All nine embedded profiles and 44 host CTest entries pass, including rotated
independent blocks, endpoint stability controls, post-capture refresh, timeout
and cancellation. Historical failed attempts remain preserved. No complete
physical observation has yet been accepted and no calibration is installed.

The owner returned and requested a fresh battery reading. A no-reset halt/read/
resume snapshot from the preceding running 7df98c92 image reported 3.774652 V,
raw 2342, state OK, age 33 ms, auxiliary ADC not paused and zero faults. This
uses nominal ADC scaling; it does not establish state of charge or runtime.
See battery-006/report.json. The 35804-byte corrected image was subsequently
programmed and byte-for-byte verified; W25Q was not erased or programmed.

## OPEN completion checkpoint

All 33 physical OPEN conditions are now accepted. Earlier incomplete-status
paragraphs describe their historical checkpoints. The accepted first frame
was preserved, and the remaining 32 completed with quiet UART windows and
no new protocol errors. SHORT/LOAD and calibration installation remain
pending. Hardware remains SAFE; this is not physical accuracy qualification.
