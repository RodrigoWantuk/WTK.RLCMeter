"""Inspect failed workflow only after independent UART SAFE acknowledgement."""
import json
import os
from pathlib import Path
import re
import subprocess

def snapshot(root, out):
    root, out = Path(root), Path(out)
    reference = root / 'capture-error-state-002'
    plan = json.loads((reference / 'report.json').read_text())['plan']
    plan['environment']['WTK_RAM_FILE'] = str((out / 'ram.bin').resolve())
    run = subprocess.run(plan['argv'], env=dict(os.environ, **plan['environment']),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=15,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    (out / 'openocd.txt').write_bytes(run.stdout)
    if run.returncode or run.stdout.count(b'WTK_NO_RESET_RAM_RESUMED') != 1:
        raise ValueError('Safe RAM read/resume not confirmed')
    nm = subprocess.check_output([
        'C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin/arm-none-eabi-nm.exe',
        '-n', str(root / 'verified-builds/bringup-cal/WTK.RLCMeter.elf')], text=True)
    symbols = {name: int(addr,16) for addr,name in re.findall(r'^([0-9a-f]+) [A-Za-z] (\S+)$', nm, re.M)}
    offsets = [int(n) for n in re.findall(r'^\s*\.word\s+(\d+)', (reference / 'layout.s').read_text(), re.M)]
    raw = (out / 'ram.bin').read_bytes()
    names = ('session_state','session_started','mean_count','tx_count','permit_issue','permit_validate',
        'workflow_state','workflow_result','accepted','rejected','attempts','reject_flags',
        'measure_state','measure_error','measure_sequence','workspace_owner')
    owners = ('capture',)*6 + ('calibration',)*6 + ('measure',)*3 + ('workspace',)
    widths = (1,1,1,1,4,4,1,1,1,1,1,4,1,1,4,1)
    result = {}
    for name, owner, offset, width in zip(names, owners, offsets, widths):
        start = symbols[owner] - 0x20000000 + offset
        result[name] = int.from_bytes(raw[start:start+width], 'little')
    (out / 'workflow.json').write_text(json.dumps(result, indent=2)+'\n')
    return result
