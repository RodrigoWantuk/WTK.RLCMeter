"""Owner-directed engineering OSL preparation; no capture or calibration writes."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d

root = Path(__file__).resolve().parent
release = root / 'verified-builds-phase'
builds = d.load(release / 'firmware-builds.json')
case = next(c for c in builds['cases'] if c['name'] == 'bringup-cal')
if case['status'] != 'PASS' or builds['calibration_hardware_revision'] != 65538:
    raise ValueError('Current passing RGS-to-GND calibration image required')
for filename, meta in case['files'].items():
    data = (release / 'bringup-cal' / filename).read_bytes()
    if len(data) != meta['bytes'] or d.sha(data) != meta['sha256']:
        raise ValueError('Released build artifact differs: ' + filename)
fresh = d.load(root / 'predeploy-phase-status.json')
if fresh['outcome'] != 'SAFE_IDLE': raise ValueError('Fresh safe-idle calibration preflight required')
preflight = d.load(root / 'predeploy-passive/report.json')
if preflight['outcome'] != 'EXPECTED_PASSIVE_STATE_OBSERVED':
    raise ValueError('Fresh passive SAFE preflight required')
if not all(v for v in preflight['checks'].values() if v is not None):
    raise ValueError('Passive preflight rejected')

image = d.manifest(release / 'bringup-cal', root / 'image-phase-001', 'BRINGUP_CAL',
                   builds['source'], 'stm32-bringup-cal')
auth = dict(
    operator='Rodrigo; owner-directed first engineering OSL', utc=d.utc(),
    board='First Rev1 assembled board, six RGS reworked gate-to-GND',
    expected_uid='54ff70068370525760380567', SIMULATED=False,
    previous_profile='BRINGUP_CAL', next_profile='BRINGUP_CAL',
    image_sha256=image['files']['firmware.bin']['sha256'],
    manifest_seal=image['seal_sha256'],
    approval_origin='Owner: ja fizemos essas conferencias, vamos direto pra calibracao',
    scope='Deploy tested phase-invariant repeatability, endpoint scale and UART quiet correction; resume the owner-confirmed unchanged OPEN sweep after re-identification',
    physical_qualification=False,
    procedural_exception=dict(
        owner_requested_proceed_without_scope=True,
        scope_checks='NOT_TESTED; Hantek unavailable',
        existing_dc_checks='Reuse owner-reported DC checks and preserved bench observations',
        b01_gate='Not approved; no missing physical entry relabelled PASS',
        workflow='Supported engineering capture backend; desktop qualification gate unchanged',
        release='No production-release or accuracy qualification granted'),
    preflight_path=str(root / 'predeploy-passive/report.json'),
    supply='Battery/boost; nominal battery 3.79V OK; charger ABSENT',
    preservation='Internal Flash only; no external W25Q erase/program requested',
    calibration='No valid record exists; no calibration installation in this operation',
    acknowledgements=dict(safe_outputs=True, debug_halt_watchdog=True,
                          no_app_bootloader=True, internal_flash=True))
auth['seal_sha256'] = d.seal(auth)
d.save(root / 'deployment-phase-authorization.json', auth)
backend = d.OpenOCD(
    'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
    'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts',
    '530049000C0000513751594E')
record = d.deployment('program', root / 'image-phase-001/manifest.json', backend,
                      root / 'deployment-phase-001', authorization=auth, uid=auth['expected_uid'])
print(json.dumps({key: record.get(key) for key in ('outcome', 'readback', 'error')}, indent=2))
if record['outcome'] != 'INTERNAL_FLASH_VERIFIED':
    raise SystemExit(1)
