"""Owner-confirmed OPEN sweep; supported capture API, no writes or retries."""
import json
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl
import pc_osl_campaign as g
from pc_osl_install import Installer

root = Path(__file__).resolve().parent
expected = d.load(root / 'boot-identify-publish-001/report.json')
if expected['outcome'] != 'PHYSICAL_CAL_SERVICE_IDENTIFIED_SAFE_IDLE':
    raise ValueError('Verified physical calibration service required')
out = root / 'open-007'
out.mkdir(exist_ok=False)
report = dict(started_utc=d.utc(), SIMULATED=False, standard='OPEN',
    operator='Rodrigo', fixture='Direct TEST_HI/TEST_LO terminals; empty',
    owner_confirmation=dict(
        question='Confirm completely empty TEST_HI/TEST_LO for OPEN at all 33 conditions; leave unchanged until completion',
        answer='Pode seguir', scope='One explicit owner confirmation covers this entire unchanged OPEN sweep'),
    prior_attempt='open-001 through open-005 preserved; no complete observation accepted',
    recovery='Controlled resumption after tested phase-invariant/endpoint repeatability and quiet UART corrections, same owner-confirmed OPEN fixture',
    required=32, accepted=[], attempts=[], prior_accepted_file="open-006/captures.json", error=None, installed=False,
    physically_qualified=False, scope_checks='NOT_TESTED; owner-directed engineering OSL')
events = []
current = None
start_sent = False
client = None
link = b.open_serial('COM4')

def persist():
    d.save(out / 'report.json', report)
    d.save(out / 'wire-events.json', events)

def require_safe(state):
    if (state['busy'] or not state['transfer_safe'] or state['safety_faults']
            or state['safety_blocks'] & ~8 or state['calibration_sequence'] != 0
            or state['calibrated']):
        raise ValueError('Unexpected unsafe/busy/calibration state: ' + str(state))

class Transport:
    def write(self, data):
        global start_sent
        kind, sequence, payload = c.decode_frame(data)
        if kind not in (c.IDENTIFY, c.STATUS, c.START, c.RESULT, c.CANCEL, 0x59):
            raise ValueError('OPEN capture command whitelist violation')
        if kind == c.START:
            if current is None or start_sent or payload[8:12] != bytes((*current.ids(), 0)) or payload[12:] != bytes(8):
                raise ValueError('START differs from confirmed OPEN condition or is a retry')
            start_sent = True
        events.append(dict(utc=d.utc(), direction='TX', hex=data.hex()))
        for byte in data:
            if link.write(bytes([byte])) != 1:
                raise OSError('Partial serial write; no automatic retry')
            time.sleep(0.001)
        return len(data)

    def read(self, count=1):
        data = link.read(count)
        if data:
            events.append(dict(utc=d.utc(), direction='RX', hex=data.hex()))
        return data

try:
    class QuietClient(c.Client):
        def begin(self, key, standard, load=0j):
            result = super().begin(key, standard, load)
            duration = self.identity['timeout_ms'] / 1000.0 + 1.0
            print(f'UART QUIET {duration:.0f}s: no STATUS traffic inside bounded acquisition', flush=True)
            time.sleep(duration)
            return result
    client = QuietClient(Transport())
    identity = client.identify()
    report['identity'] = identity
    if identity != expected['identity']:
        raise ValueError('Device/firmware identity differs from verified boot')
    initial = client.status()
    require_safe(initial)
    report['initial_status'] = initial
    storage = Installer(client).status()
    report['initial_installation_status'] = storage
    if storage['active_valid'] or storage['active_sequence'] != 0 or storage['next_sequence'] != 1:
        raise ValueError('Calibration sequence differs from blank session')
    prior = d.load(root / 'open-006/captures.json')
    c.verify_campaign(prior, identity)
    if len(prior['captures']) != 1 or prior['captures'][0]['condition'] != pc_osl.KEYS[0].as_json():
        raise ValueError('Expected exactly the original accepted first OPEN capture')
    c.save_capture(out / 'captures.json', prior['captures'][0])
    report['prior_accepted_sha256'] = prior['captures'][0]['sha256']
    report['protocol_errors_baseline'] = initial['protocol_errors']
    persist()
    for index, key in enumerate(pc_osl.KEYS[1:], 2):
        current, start_sent = key, False
        attempt = dict(started_utc=d.utc(), condition=key.as_json(), standard='OPEN',
                       owner_confirmation='Same explicit unchanged-fixture sweep authorization')
        report['attempts'].append(attempt)
        persist()
        if client.identify() != identity:
            raise ValueError('Device identity changed before capture')
        require_safe(client.status())
        print(f'OPEN {index}/33 START RREF={key.rref_ohms} Hz={key.frequency_hz} mVrms={key.amplitude_mvrms}', flush=True)
        row = client.capture(key, 'OPEN')
        # Keep the received artifact before any additional host quality check.
        name = f'{index:02d}-r{key.rref_ohms}-f{key.frequency_hz}-a{key.amplitude_mvrms}'
        (out / (name + '.cco1')).write_bytes(bytes.fromhex(row['artifact_hex']))
        d.save(out / (name + '.json'), row)
        quality = g.quality(row)
        final = client.status()
        require_safe(final)
        if final['protocol_errors'] != initial['protocol_errors']:
            raise ValueError('New serial protocol error; no retry')
        document = c.save_capture(out / 'captures.json', row)
        c.verify_campaign(document, identity)
        attempt.update(completed_utc=d.utc(), outcome='ACCEPTED', sha256=row['sha256'],
                       quality=quality, final_status=final)
        report['accepted'].append(dict(condition=key.as_json(), sha256=row['sha256'], quality=quality))
        report['last_safe_status'] = final
        persist()
        print(f'OPEN {index}/33 ACCEPTED paths={quality["usable_paths"]} repeats={quality["repeats"]} clipping={quality["clipping_mask"]} SAFE', flush=True)
    report['final_installation_status'] = Installer(client).status()
    if report['final_installation_status'] != storage:
        raise ValueError('Unexpected persistent calibration-state change')
    report['outcome'] = 'ALL_33_OPEN_CAPTURES_ACCEPTED_WITH_PRIOR_FIRST_OBSERVATION'
except BaseException as exc:
    report.update(outcome='STOPPED_NO_AUTOMATIC_RETRY', error=type(exc).__name__ + ': ' + str(exc))
    if report['attempts'] and report['attempts'][-1].get('outcome') is None:
        report['attempts'][-1].update(outcome='STOPPED', error=report['error'])
    if client is not None:
        try:
            state = client.status()
            report['recovery_status'] = state
            if state['busy']:
                report['recovery_cancellation'] = g.cancel_pending(client)
                state = client.status()
                report['recovery_status'] = state
            require_safe(state)
            report['safe_after_stop'] = True
        except BaseException as recovery:
            report['safe_after_stop'] = False
            report['recovery_error'] = type(recovery).__name__ + ': ' + str(recovery)
    raise
finally:
    link.close()
    report['completed_utc'] = d.utc()
    persist()
    print(json.dumps({key: report.get(key) for key in
        ('outcome', 'error', 'safe_after_stop', 'last_safe_status', 'recovery_status')}, indent=2), flush=True)
