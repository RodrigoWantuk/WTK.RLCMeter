"""Publish a verified OPEN-only checkpoint; never installs or captures anything."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_cal_capture as capture
import pc_firmware_deploy as deploy
import pc_osl

root = Path(__file__).resolve().parent
matrix_root = root / 'verified-builds-publish'
matrix = deploy.load(matrix_root / 'firmware-builds.json')
report = deploy.load(root / 'open-007/report.json')
document = deploy.load(root / 'open-007/captures.json')
if report['outcome'] != 'ALL_33_OPEN_CAPTURES_ACCEPTED_WITH_PRIOR_FIRST_OBSERVATION':
    raise ValueError('Complete physical OPEN sweep required')
capture.verify_campaign(document, report['identity'])
if len(document['captures']) != 33 or {pc_osl.Key.from_json(r['condition']) for r in document['captures']} != set(pc_osl.KEYS):
    raise ValueError('Exactly 33 distinct OPEN conditions required')
if any(r['standard'] != 'OPEN' or r['physically_qualified'] for r in document['captures']):
    raise ValueError('OPEN-only, unqualified evidence required')
if len(matrix['cases']) != 9 or any(c['status'] != 'PASS' for c in matrix['cases']):
    raise ValueError('Nine passing source-bound embedded builds required')

session = root / 'Session.md'
session.write_text(session.read_text() + '\n## OPEN completion checkpoint\n\n'
    'All 33 physical OPEN conditions are now accepted. Earlier incomplete-status\n'
    'paragraphs describe their historical checkpoints. The accepted first frame\n'
    'was preserved, and the remaining 32 completed with quiet UART windows and\n'
    'no new protocol errors. SHORT/LOAD and calibration installation remain\n'
    'pending. Hardware remains SAFE; this is not physical accuracy qualification.\n')

release = Path('Firmware/releases/2026-10-25/osl-open-checkpoint')
release.mkdir(exist_ok=False)
docs = Path('docs/review/bringup-2026-10-25')
firmware_zip = release / 'firmware.zip'
with zipfile.ZipFile(firmware_zip, 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(matrix_root / 'firmware-builds.json', 'firmware-builds.json')
    for case in matrix['cases']:
        for name, meta in case['files'].items():
            path = matrix_root / case['name'] / name
            data = path.read_bytes()
            if len(data) != meta['bytes'] or deploy.sha(data) != meta['sha256']:
                raise ValueError('Released build artifact changed: ' + str(path))
            archive.write(path, case['name'] + '/' + name)
        archive.write(matrix_root / case['name'] / 'generated/wtk_build_config.h',
            case['name'] + '/wtk_build_config.h')
    archive.writestr('README.txt', 'Firmware source ' + matrix['source']['git_sha'] +
        '\nNine software builds passed. OPEN-only engineering checkpoint; no calibration installation, production release or accuracy qualification.\n')

physical_zip = release / 'physical-evidence.zip'
with zipfile.ZipFile(physical_zip, 'w', zipfile.ZIP_DEFLATED) as archive:
    for folder in ('open-001','open-002','open-003','open-004','open-005','open-006','open-007',
            'battery-006','boot-identify-publish-001','deployment-publish-001',
            'timeout-state-001','capture-error-state-002','capture-error-state-003',
            'capture-error-state-004','capture-error-state-005'):
        for path in sorted((root / folder).rglob('*')):
            if path.is_file():
                archive.write(path, str(path.relative_to(root)).replace('\\','/'))
    for pattern in ('*.py','*-tests.log','Session.md','references-owner-evidence.json'):
        for path in sorted(root.glob(pattern)):
            archive.write(path, path.name)
    old_client = subprocess.check_output(['git','show',matrix['source']['git_sha'] + ':Firmware/tools/pc_cal_capture.py'])
    archive.writestr('client-module-at-firmware-source.py', old_client)
    archive.write(root / 'image-publish-001/manifest.json', 'deployed-image/manifest.json')
    archive.write(root / 'image-publish-001/firmware.bin', 'deployed-image/firmware.bin')

for path in (firmware_zip, physical_zip):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(set(archive.namelist())):
            raise ValueError('Archive verification failed: ' + str(path))
matrix_bytes = (matrix_root / 'firmware-builds.json').read_bytes()
(release / 'firmware-builds.json').write_bytes(matrix_bytes)
temps = [r['temperature_mC'] for r in document['captures'] if r['temperature_mC'] is not None]
checkpoint = dict(recorded_utc=deploy.utc(), SIMULATED=False, status='OPEN_COMPLETE_SHORT_LOAD_PENDING',
    firmware_source=matrix['source']['git_sha'], identity=report['identity'],
    open_conditions=33, required_full_osl_observations=99, captures_installed=False,
    physically_qualified=False, accuracy_qualified=False,
    battery=deploy.load(root / 'battery-006/report.json'),
    final_status=report['last_safe_status'], installation_status=report['final_installation_status'],
    protocol_errors_baseline=report['protocol_errors_baseline'],
    no_new_protocol_errors=report['last_safe_status']['protocol_errors'] == report['protocol_errors_baseline'],
    temperature_mC_min=min(temps), temperature_mC_max=max(temps),
    host_tests='44/44 CTest; 44/44 GUI/model; 16/16 latest capture client tests',
    embedded_builds='9/9 PASS', scope_checks='NOT_TESTED; owner-directed engineering scope',
    fixture='Empty direct DUT terminals; final enclosure/test leads not fitted',
    captures_sha256=deploy.sha((root / 'open-007/captures.json').read_bytes()),
    artifacts={p.name:dict(bytes=p.stat().st_size,sha256=deploy.sha(p.read_bytes()))
               for p in (firmware_zip,physical_zip)})
deploy.save(docs / 'OSL-Open.json', checkpoint)
text = f'''# First-board OSL OPEN checkpoint — October 25, 2026

Status: OPEN_COMPLETE; SHORT_AND_LOAD_PENDING; NOT_PHYSICALLY_QUALIFIED.

All 33 OPEN conditions were accepted on the real board, with at least six stable
blocks per condition and verified SAFE teardown. The first accepted artifact was
preserved; the remaining 32 used a 21-second UART quiet window. No new protocol
errors occurred in that resumption; the earlier lost-frame count is retained.
The board remains BRINGUP_CAL, no calibration is installed, and the observed
storage successor remains 1. This is acquisition evidence, not an accuracy or
production-release certificate. Hantek-dependent checks remain NOT_TESTED.

Firmware source: `{matrix['source']['git_sha']}`. Its nine embedded builds passed;
the 35804-byte BRINGUP_CAL image was programmed and verified byte-for-byte before
boot identification. Hardware identity is 0x10002, model 5. All 44 CTests, 44
GUI/model tests and the latest 16 capture-client tests passed. See
[structured checkpoint](OSL-Open.json) and [firmware/evidence bundle](../../../Firmware/releases/2026-10-25/osl-open-checkpoint/README.md).

The owner requested proceeding using prior DC observations while the Hantek was
unavailable. No missing physical test was relabelled PASS; the desktop B01 gate
remains unchanged. Embedded residual, charger, battery, range, clock, fault and
teardown gates remained active. Source fixes cover sample freshness, drained
aborts, arbitrary common phase, near-zero endpoint statistics, deferred fresh
safety publication and host quiet time. Rejected attempts remain in the archive.

The fresh battery checkpoint before this sweep was 3.774652 V nominal ADC scale,
state OK, age 33 ms, zero faults. No state-of-charge/runtime claim is made.
Board NTC estimates during OPEN ranged from {min(temps)/1000:.3f} to {max(temps)/1000:.3f} C;
these are provisional sensor estimates, not DUT temperature qualification.

Fixture is direct terminal attachment. The six proposed LOAD anchors remain
nominal 10 / 100 / 1k / 10k / 100k / 1M ohm with 1% marked/inferred tolerance;
uncertain band identifications and DMM readings are preserved as owner evidence.
Ask for a fresh resistor reading immediately before each LOAD attachment.
The SHORT link has not yet been attached or characterized. Final test leads
require calibration in their final geometry. No calibration candidate has been
generated, committed or installed, and W25Q calibration writes were not requested.
'''
(docs / 'OSL-Open.md').write_text(text, encoding='utf-8')
(release / 'README.md').write_text('''# OSL OPEN checkpoint

The nine-image `firmware.zip` is built from source ''' + matrix['source']['git_sha'] + '''.
`firmware-builds.json` binds every image/hash/profile. `physical-evidence.zip`
preserves accepted OPEN frames, historical rejected attempts, wire logs, the
verified deployment, battery read, tests and local capture helpers.

This is an engineering OPEN-only checkpoint. SHORT/LOAD, candidate generation,
installation, independent validation and electrical qualification remain pending.
The board is running BRINGUP_CAL; do not treat PRODUCT builds as a calibrated
device release. The existing W25Q resource pack is unchanged.

See [bench report](../../../../docs/review/bringup-2026-10-25/OSL-Open.md).
''', encoding='utf-8')
print(json.dumps(dict(outcome=checkpoint['status'], open_conditions=33, artifacts=checkpoint['artifacts']),indent=2))
