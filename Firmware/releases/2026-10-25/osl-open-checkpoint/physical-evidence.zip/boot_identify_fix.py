"""Boot the verified calibration image; IDENTIFY and STATUS requests only."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_cal_capture as c
import pc_firmware_deploy as d
from pc_osl_install import Installer

root = Path(__file__).resolve().parent
image = d.inspect(root / 'image-fix-001/manifest.json', 'BRINGUP_CAL')
deployment = d.checked(d.load(root / 'deployment-fix-001/deployment.json'))
if deployment['outcome'] != 'INTERNAL_FLASH_VERIFIED':
    raise ValueError('Verified deployment required before boot')
out = root / 'boot-identify-fix-001'
out.mkdir(exist_ok=False)
report = dict(recorded_utc=d.utc(), SIMULATED=False, operation='BOOT_IDENTIFY_STATUS_ONLY',
              image_sha256=image['files']['firmware.bin']['sha256'], error=None,
              capture_started=False, calibration_written=False)
events = []
link = b.open_serial('COM4')

class Transport:
    def write(self, data):
        events.append(dict(utc=d.utc(), direction='TX', hex=data.hex()))
        for byte in data:
            if link.write(bytes([byte])) != 1:
                raise OSError('Partial write; no automatic retry')
            time.sleep(0.001)
        return len(data)

    def read(self, count=1):
        data = link.read(count)
        if data:
            events.append(dict(utc=d.utc(), direction='RX', hex=data.hex()))
        return data

try:
    backend = d.OpenOCD(
        'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
        'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts',
        '530049000C0000513751594E')
    plan = backend.plan('probe', out, None, deployment['target']['uid'])
    plan['argv'][-1] = ('if {[catch {init; reset init; wtk_operation; reset run; '
        'echo "WTK_CAL_BOOT_RUN"} reason]} {echo "WTK_B011_FAILURE"; echo $reason; '
        'shutdown error} else {shutdown}')
    report['plan'] = plan
    run = subprocess.run(plan['argv'], env=dict(os.environ, **plan['environment']),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=15,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    (out / 'openocd.txt').write_bytes(run.stdout)
    transcript = run.stdout.decode('utf-8', errors='replace')
    if run.returncode or transcript.count('WTK_CAL_BOOT_RUN') != 1 or 'WTK_B011_FAILURE' in transcript:
        raise ValueError('Controlled boot not confirmed')
    report['target'] = d.parse_target(transcript)
    d.validate_target(report['target'], deployment['target']['uid'])
    # Allow the complete bounded shared splash before sending any binary frame.
    startup = bytearray()
    deadline = time.monotonic() + 35
    while time.monotonic() < deadline:
        startup.extend(link.read(144))
        if len(startup) > 32768:
            raise ValueError('Unexpected startup output volume')
    (out / 'startup-uart.bin').write_bytes(startup)
    client = c.Client(Transport(), timeout=5)
    identity = client.identify()
    report['identity'] = identity
    if (identity['profile'] != 1 or identity['synthetic'] or identity['uid'] != deployment['target']['uid']
            or identity['git'] != image['expected_boot']['git_prefix'] or identity['capabilities'] & 31 != 31):
        raise ValueError('Calibration image identity/capability mismatch')
    state = client.status()
    report['status'] = state
    if state['busy'] or not state['transfer_safe'] or state['safety_faults'] or state['safety_blocks'] & ~8:
        raise ValueError('Service is not safe and idle')
    storage = Installer(client).status()
    report['installation_status'] = storage
    if not storage['storage_available'] or not storage['next_sequence']:
        raise ValueError('Calibration storage unavailable')
    report['outcome'] = 'PHYSICAL_CAL_SERVICE_IDENTIFIED_SAFE_IDLE'
except Exception as exc:
    report.update(outcome='INCOMPLETE', error=type(exc).__name__ + ': ' + str(exc))
    raise
finally:
    link.close()
    d.save(out / 'report.json', report)
    d.save(out / 'wire-events.json', events)
    print(json.dumps({key: report.get(key) for key in
        ('outcome', 'identity', 'status', 'installation_status', 'error')}, indent=2), flush=True)
