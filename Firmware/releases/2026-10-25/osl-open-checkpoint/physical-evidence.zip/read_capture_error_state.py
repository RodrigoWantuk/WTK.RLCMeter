"""No-reset SWD RAM snapshot after safe timeout; never starts a capture."""
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d

root = Path(__file__).resolve().parent
out = root / 'capture-error-state-002'
out.mkdir(exist_ok=False)
arm = Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin')
build = root / 'verified-builds/bringup-cal'
fields = {
    'capture.session.state': ('capture', 'offsetof(app_cal_capture_service_t,session)+offsetof(app_calibration_session_t,state)', 1),
    'capture.session.started': ('capture', 'offsetof(app_cal_capture_service_t,session)+offsetof(app_calibration_session_t,started_capture)', 1),
    'capture.mean_count': ('capture', 'offsetof(app_cal_capture_service_t,mean_count)', 1),
    'capture.tx_count': ('capture', 'offsetof(app_cal_capture_service_t,tx_count)', 1),
    'capture.permit_issue': ('capture', 'offsetof(app_cal_capture_service_t,permit_issue_ms)', 4),
    'capture.permit_validate': ('capture', 'offsetof(app_cal_capture_service_t,permit_validate_ms)', 4),
    'workflow.state': ('calibration', 'offsetof(app_calibration_service_t,workflow)+offsetof(app_calibration_workflow_t,state)', 1),
    'workflow.result': ('calibration', 'offsetof(app_calibration_service_t,workflow)+offsetof(app_calibration_workflow_t,result)', 1),
    'workflow.accepted': ('calibration', 'offsetof(app_calibration_service_t,workflow)+offsetof(app_calibration_workflow_t,evidence)+offsetof(app_cal_evidence_t,accepted)', 1),
    'workflow.rejected': ('calibration', 'offsetof(app_calibration_service_t,workflow)+offsetof(app_calibration_workflow_t,evidence)+offsetof(app_cal_evidence_t,rejected)', 1),
    'workflow.attempts': ('calibration', 'offsetof(app_calibration_service_t,workflow)+offsetof(app_calibration_workflow_t,evidence)+offsetof(app_cal_evidence_t,attempts)', 1),
    'workflow.reject_flags': ('calibration', 'offsetof(app_calibration_service_t,workflow)+offsetof(app_calibration_workflow_t,evidence)+offsetof(app_cal_evidence_t,reject_flags)', 4),
    'measure.state': ('measure', 'offsetof(hw_metrology_measure_t,state)', 1),
    'measure.error': ('measure', 'offsetof(hw_metrology_measure_t,error)', 1),
    'measure.sequence': ('measure', 'offsetof(hw_metrology_measure_t,sequence)', 4),
    'workspace.owner': ('workspace', 'offsetof(app_io_workspace_t,owner)', 1),
}
source = '#include <stddef.h>\n#include "app/app_cal_capture_service.h"\n'
source += 'const unsigned int offsets[] = {' + ','.join(v[1] for v in fields.values()) + '};\n'
(out / 'layout.c').write_text(source, encoding='ascii')
subprocess.run([str(arm / 'arm-none-eabi-gcc.exe'), '-std=c17', '-mcpu=cortex-m3', '-mthumb', '-S',
    str(out / 'layout.c'), '-I', 'Firmware/src', '-I', str(build / 'generated'), '-o', str(out / 'layout.s')], check=True)
offsets = [int(n) for n in re.findall(r'^\s*\.word\s+(\d+)', (out / 'layout.s').read_text(), re.M)]
if len(offsets) != len(fields):
    raise ValueError('Compiler layout incomplete')
nm = subprocess.check_output([str(arm / 'arm-none-eabi-nm.exe'), '-n', str(build / 'WTK.RLCMeter.elf')], text=True)
symbols = {name: int(addr,16) for addr,name in re.findall(r'^([0-9a-f]+) [A-Za-z] (\S+)$', nm, re.M)}
backend = d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
    'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts', '530049000C0000513751594E')
plan = backend.plan('probe', out, None, '54ff70068370525760380567')
plan['environment']['WTK_RAM_FILE'] = str(out / 'ram.bin')
plan['argv'][-1] = ('if {[catch {init; halt; wtk_preflight; dump_image $::env(WTK_RAM_FILE) '
    '0x20000000 20480; resume; echo "WTK_NO_RESET_RAM_RESUMED"} reason]} '
    '{catch {resume}; echo "WTK_B011_FAILURE"; echo $reason; shutdown error} else {shutdown}')
run = subprocess.run(plan['argv'], env=dict(os.environ, **plan['environment']), stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT, timeout=15, creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
(out / 'openocd.txt').write_bytes(run.stdout)
if run.returncode or run.stdout.count(b'WTK_NO_RESET_RAM_RESUMED') != 1:
    raise ValueError('RAM snapshot/resume not confirmed')
raw = (out / 'ram.bin').read_bytes()
values = {}
for (name,(symbol,expression,width)), offset in zip(fields.items(), offsets):
    address = symbols[symbol] + offset
    values[name] = int.from_bytes(raw[address-0x20000000:address-0x20000000+width], 'little')
report = dict(recorded_utc=d.utc(), operation='NO_RESET_READ_RAM_HALT_RESUME',
    values=values, plan=plan, ram_sha256=d.sha(raw), no_capture_started=True)
d.save(out / 'report.json', report)
print(json.dumps(values, indent=2))
