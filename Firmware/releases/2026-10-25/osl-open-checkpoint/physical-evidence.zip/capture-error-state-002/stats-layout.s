	.cpu cortex-m3
	.arch armv7-m
	.fpu softvfp
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 6
	.eabi_attribute 34, 1
	.eabi_attribute 18, 4
	.file	"stats-layout.c"
	.text
	.global	offsets
	.section	.rodata
	.align	2
	.type	offsets, %object
	.size	offsets, 40
offsets:
	.word	5500
	.word	5520
	.word	5540
	.word	5560
	.word	5580
	.word	5600
	.word	5640
	.word	5660
	.word	5700
	.word	5720
	.ident	"GCC: (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119"
