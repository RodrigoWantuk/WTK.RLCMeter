	.cpu cortex-m3
	.arch armv7-m
	.fpu softvfp
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 6
	.eabi_attribute 34, 1
	.eabi_attribute 18, 4
	.file	"layout.c"
	.text
	.global	offsets
	.section	.rodata
	.align	2
	.type	offsets, %object
	.size	offsets, 64
offsets:
	.word	13
	.word	216
	.word	936
	.word	935
	.word	964
	.word	968
	.word	5376
	.word	5377
	.word	5444
	.word	5445
	.word	5446
	.word	5448
	.word	128
	.word	129
	.word	296
	.word	3072
	.ident	"GCC: (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119"
