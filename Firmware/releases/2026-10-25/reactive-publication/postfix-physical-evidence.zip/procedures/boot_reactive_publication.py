"""Controlled PRODUCT boot, passive UART, metadata/output snapshot only.
Never reads battery voltage over SWD and never issues a measurement command.
"""
import os,sys,json,subprocess,time,re,struct
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_bringup as b,pc_firmware_deploy as d
r=Path(__file__).resolve().parent;o=r/'boot-reactive-publication-001';o.mkdir(exist_ok=False)
image=d.inspect(r/'image-reactive-publication-001/manifest.json','FACTORY_PRODUCT');deployment=d.checked(d.load(r/'deployment-reactive-publication-001/deployment.json'))
if deployment['outcome']!='INTERNAL_FLASH_VERIFIED':raise ValueError('Verified PRODUCT programming required')
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
plan=backend.plan('probe',o,None,deployment['target']['uid']);plan['argv'][-1]='if {[catch {init; reset init; wtk_operation; reset run; echo "WTK_PRODUCT_BOOT_RUN"} reason]} {echo "WTK_B011_FAILURE"; echo $reason; shutdown error} else {shutdown}'
report=dict(utc=d.utc(),operation='CONTROLLED_PRODUCT_BOOT_PASSIVE_UART_AND_METADATA',SIMULATED=False,capture_started=False,measurement_commanded=False,battery_read_over_swd=False,image_sha256=image['files']['firmware.bin']['sha256'],error=None,visual_check='PENDING_OWNER_DISPLAY_CONNECTION')
link=b.open_serial('COM4')
run=subprocess.run(plan['argv'],env=dict(os.environ,**plan['environment']),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'boot-openocd.txt').write_bytes(run.stdout)
if run.returncode or run.stdout.count(b'WTK_PRODUCT_BOOT_RUN')!=1:raise ValueError('Controlled boot not confirmed')
report['target']=d.parse_target(run.stdout.decode(errors='replace'));d.validate_target(report['target'],deployment['target']['uid'])
startup=bytearray();until=time.monotonic()+10
while time.monotonic()<until:startup.extend(link.read(144))
link.close();(o/'startup-uart.bin').write_bytes(startup);report['uart_text']=startup.decode(errors='replace')
if startup.count(b'WTK.RLCMeter SAFE_BOOT')!=1:raise ValueError('PRODUCT passive boot banner not confirmed')
arm=Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin');build=r/'verified-builds-reactive-publication/factory-release'
fields={
 'product_state':('g_product.lto_priv.0','offsetof(app_product_t,view)+offsetof(ui_product_view_t,state)','B'),
 'measurement_session_sequence':('g_product.lto_priv.0','offsetof(app_product_t,session_sequence)','I'),
 'product_initialized':('g_product.lto_priv.0','offsetof(app_product_t,initialized)','B'),
 'calibration_sequence':('g_calibration_service.lto_priv.0','offsetof(app_calibration_service_t,runtime)+offsetof(app_calibration_runtime_t,active_set)+offsetof(measurement_cal_set_t,sequence)','I'),
 'calibration_record_count':('g_calibration_service.lto_priv.0','offsetof(app_calibration_service_t,runtime)+offsetof(app_calibration_runtime_t,active_set)+offsetof(measurement_cal_set_t,record_count)','B'),
 'calibration_active_valid':('g_calibration_service.lto_priv.0','offsetof(app_calibration_service_t,runtime)+offsetof(app_calibration_runtime_t,active_valid)','B'),
 'calibration_storage_available':('g_calibration_service.lto_priv.0','offsetof(app_calibration_service_t,storage_available)','B'),
 'k1_commanded_state':('g_k1.lto_priv.0','offsetof(hw_k1_t,commanded_state)','B'),
 'range_fsm_state':('g_range.lto_priv.0','offsetof(hw_range_t,state)','B'),
 'range_enabled':('g_range.lto_priv.0','offsetof(hw_range_t,enabled)','B'),
 'safety_fault_mask':('g_safety_faults.lto_priv.0','0','I'),
 'display_fault':('g_product_display_fault','0','B'),
 'resource_status':('g_resource_status.lto_priv.0','0','B'),
 'excitation_mode':('g_mode.lto_priv.0','0','B'),
 'safety_blocker_flags':('g_safety_result','offsetof(hw_safety_result_t,blocker_flags)','I'),
 'display_slow_mode':('g_display_slow','0','B'),
 'backlight_percent':('g_product_output_backlight_percent','0','B'),
 'saved_brightness_percent':('g_settings_service','offsetof(app_settings_service_t,current)+offsetof(app_settings_t,brightness_percent)','B'),
 'quiet_requested':('g_quiet_requested.lto_priv.0','0','B'),
}
(o/'layout.c').write_text('#include <stddef.h>\n#include "app/app_product.h"\n#include "hardware/hw_k1.h"\n#include "hardware/hw_range.h"\nconst unsigned offsets[]={'+','.join(v[1] for v in fields.values())+'};\n')
subprocess.run([str(arm/'arm-none-eabi-gcc.exe'),'-std=c17','-mcpu=cortex-m3','-mthumb','-S',str(o/'layout.c'),'-I','Firmware/src','-I',str(build/'generated'),'-o',str(o/'layout.s')],check=True)
offsets=[int(v) for v in re.findall(r'^\s*\.word\s+(\d+)',(o/'layout.s').read_text(),re.M)]
if len(offsets)!=len(fields):raise ValueError('Complete compiler ABI layout required')
nm=subprocess.check_output([str(arm/'arm-none-eabi-nm.exe'),'-n',str(build/'WTK.RLCMeter.elf')],text=True);symbols={n:int(a,16) for a,n in re.findall(r'^([0-9a-f]+) [A-Za-z] (\S+)$',nm,re.M)}
plan=backend.plan('probe',o,None,deployment['target']['uid']);env=dict(os.environ,**plan['environment']);commands=[];layout=[]
for i,((name,(symbol,expr,fmt)),offset) in enumerate(zip(fields.items(),offsets)):
 matches=[k for k in symbols if k.split('.lto_priv.')[0]==symbol];resolved=symbol if symbol in symbols else matches[0] if len(matches)==1 else symbol;address=symbols[resolved]+offset;size=struct.calcsize('<'+fmt);path=o/(name+'.bin');env['WTK_META_'+str(i)]=str(path.resolve());commands.append('dump_image $::env(WTK_META_'+str(i)+') '+hex(address)+' '+str(size));layout.append(dict(name=name,symbol=symbol,offset=offset,address=address,size=size))
plan['argv'][-1]='if {[catch {init; halt; wtk_preflight; '+'; '.join(commands)+'; resume; echo "WTK_PRODUCT_METADATA_RESUMED"} reason]} {catch {resume}; echo $reason; shutdown error} else {shutdown}'
run=subprocess.run(plan['argv'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'metadata-openocd.txt').write_bytes(run.stdout)
if run.returncode or run.stdout.count(b'WTK_PRODUCT_METADATA_RESUMED')!=1:raise ValueError('Metadata read/resume not confirmed')
values={name:struct.unpack('<'+fmt,(o/(name+'.bin')).read_bytes())[0] for name,(_,_,fmt) in fields.items()};report.update(metadata=values,layout=layout)
if not (values['calibration_active_valid']==1 and values['calibration_sequence']==1 and values['calibration_record_count']==33 and values['calibration_storage_available']==1):raise ValueError('PRODUCT did not load complete installed calibration')
if not (values['k1_commanded_state']==1 and values['range_fsm_state']==0 and values['range_enabled']==0 and values['excitation_mode']==0 and values['quiet_requested']==0 and values['measurement_session_sequence']==0 and values['safety_fault_mask']==0):raise ValueError('Idle safe outputs/no acquisition not confirmed')
if values['product_state']!=4 or values['display_fault'] or values['resource_status']!=0:raise ValueError('PRODUCT READY/resources/display-driver state not confirmed')
if values['display_slow_mode']!=0 or values['backlight_percent']!=values['saved_brightness_percent']:raise ValueError('Normal display clock/brightness application not confirmed')
report['outcome']='DISPLAY_NORMAL_CLOCK_PRODUCT_READY_SAFE_OWNER_VISUAL_PENDING'
d.save(o/'report.json',report);print(json.dumps(report,indent=2),flush=True)
