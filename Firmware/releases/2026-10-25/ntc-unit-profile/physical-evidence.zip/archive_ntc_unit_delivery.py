"""Archive verified unit firmware and measurements; no hardware access."""
import json
from pathlib import Path
import struct
import sys
import zipfile
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import ntc_factory_profile as n

root=Path(__file__).resolve().parent
builds=root/'verified-builds-ntc-unit'
matrix=d.load(builds/'firmware-builds.json')
image=d.inspect(root/'image-ntc-unit-001/manifest.json','BRINGUP_CAL')
deployment=d.checked(d.load(root/'deployment-ntc-unit-001/deployment.json'))
boot=d.load(root/'boot-identify-ntc-unit-001/report.json')
post=d.load(root/'ntc-postdeploy-001/report.json')
meta=matrix['ntc_factory_profile']
if (deployment['outcome']!='INTERNAL_FLASH_VERIFIED' or boot['outcome']!='PHYSICAL_CAL_SERVICE_IDENTIFIED_SAFE_IDLE'
        or image['source']!=matrix['source'] or image['ntc_factory_profile']!=meta
        or post['firmware_identity']!=boot['identity'] or not post['correction_applied']):
    raise ValueError('Verified source-bound unit deployment required')
blob=bytes.fromhex(meta['lut_le_hex'])
table=[struct.unpack_from('<2f',blob,i*8) for i in range(21)]
r=post['values']['ntc_resistance_ohm']
expected=None
for (tc,rc),(th,rh) in zip(table,table[1:]):
    if rc>=r>=rh: expected=tc+(rc-r)/(rc-rh)*(th-tc);break
if expected is None or abs(expected-post['values']['ntc_temperature_c'])>0.001:
    raise ValueError('Post-boot conversion differs from embedded factory table')
release=Path('Firmware/releases/2026-10-25/ntc-unit-profile')
release.mkdir(exist_ok=False)
with zipfile.ZipFile(release/'firmware.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write(builds/'firmware-builds.json','firmware-builds.json')
    for case in matrix['cases']:
        folder=builds/case['name']
        if case['status']!='PASS': raise ValueError('Nine passing builds required')
        flags=d.parse_config((folder/'generated/wtk_build_config.h').read_bytes())
        n.validate_binary(meta,(folder/'WTK.RLCMeter.bin').read_bytes(),flags)
        for name,info in case['files'].items():
            p=folder/name
            if d.sha(p.read_bytes())!=info['sha256'] or p.stat().st_size!=info['bytes']: raise ValueError('Build artifact differs')
            z.write(p,case['name']+'/'+name)
        for name in ('wtk_build_config.h','wtk_ntc_factory_lut.h','wtk_ntc_factory_profile.json'):
            z.write(folder/'generated'/name,case['name']+'/generated/'+name)
    z.write('Firmware/config/units/54ff70068370525760380567-ntc-engineering.json','unit-ntc-profile.json')
with zipfile.ZipFile(release/'physical-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for folder in ('ntc-reference-001','ntc-reference-002','ntc-reference-003','ntc-reference-004',
                   'ntc-stability-001','ntc-predeploy-001','deployment-ntc-unit-001',
                   'boot-identify-ntc-unit-001','ntc-postdeploy-001','image-ntc-unit-001'):
        for p in sorted((root/folder).rglob('*')):
            if p.is_file(): z.write(p,str(p.relative_to(root)).replace('\\','/'))
    for name in ('read_ntc_reference_003.py','read_ntc_reference_004.py','monitor_ntc_stability.py',
                 'build_ntc_unit_matrix.py','deploy_ntc_unit.py','boot_identify_ntc_unit.py',
                 'read_ntc_applied.py','archive_ntc_unit_delivery.py','deployment-ntc-unit-authorization.json',
                 'ntc-host-tests.log','ntc-host-build.log','ntc-deploy-tests.log'):
        z.write(root/name,name)
for p in release.glob('*.zip'):
    with zipfile.ZipFile(p) as z:
        if z.testzip() is not None or len(z.namelist())!=len(set(z.namelist())): raise ValueError('Archive verification failed')
(release/'firmware-builds.json').write_bytes((builds/'firmware-builds.json').read_bytes())
record=dict(recorded_utc=d.utc(),SIMULATED=False,status='EXPERIMENTAL_UNIT_NTC_PROFILE_DEPLOYED_NOT_QUALIFIED',
    source=matrix['source'],profile=meta,identity=boot['identity'],deployment_outcome=deployment['outcome'],
    readback=deployment['readback'],post_deployment=post,expected_host_interpolation_c=expected,
    embedded_builds='9/9 PASS; each BIN contains the bound LUT',host_tests='46/46 CTest PASS',
    deployment_tests='59 tests: 54 passed, 5 optional integration tests skipped',
    reference_authority='Owner explicitly requested use of 30.1C despite possible probe/finger contact interference',
    thermal_contact_uncertain=True,reference_uncertainty_c=None,intrinsic_beta_known=False,
    correction_applied=True,physically_qualified=False,independent_temperature_validation='NOT_TESTED',
    osl_installed=False,osl_status='99 captures retained, 30 fits valid, three high-Z/10kHz fits blocked',
    external_w25q_written=False,artifacts={p.name:dict(bytes=p.stat().st_size,sha256=d.sha(p.read_bytes())) for p in release.glob('*.zip')})
d.save('docs/review/bringup-2026-10-25/NTC-Factory-Profile.json',record)
Path('docs/review/bringup-2026-10-25/NTC-Factory-Profile.md').write_text(f'''# Experimental NTC profile applied — October 25, 2026

Status: EXPERIMENTAL_ADJUSTMENT_DEPLOYED; NOT_PHYSICALLY_QUALIFIED.

At the owner's explicit direction, use the supplied 30.1-degC reference despite
possible hand/probe contact interference. The fit anchors are 23.5 degC/ADC1952
and sustained warm 30.1 degC/ADC1856. The earlier ADC1877 sample remains transient
diagnostic evidence. The monitoring log contains both stable windows and later
movement; no stabilization or contact uncertainty is relabelled qualification.
The thermometer model is not requested or stored. Its uncertainty is unknown.

The versioned profile is bound to UID `{meta['uid']}`. Effective Beta is
{meta['effective_beta_k']:.6f} K and effective R25/Rtop is
{meta['effective_r25_over_rtop']:.9f}. These describe the supplied observations,
not verified intrinsic thermistor parameters. Wider-range extrapolation and
independent held-out temperatures remain unqualified. Original nominal builds
are unchanged; this unit's updates must select its factory profile explicitly.

All nine unit profiles compiled with strict warnings and existing C8 memory
gates. BRINGUP remains 65,512 bytes; BRINGUP_CAL remains 35,864 bytes. All 46
host CTests pass, including the actual C conversion at both anchors; deployment
tests report 54 passes and five optional integration skips. Manifests use schema2
to reject old tools, verify the LUT in the linked BIN, and bind programming to UID.

Source `{matrix['source']['git_sha']}` was programmed as BRINGUP_CAL and read
back byte-for-byte. The post-boot identity matches, SAFE/idle is confirmed,
safety faults zero and protocol counter zero. A fresh raw1975 snapshot reports
21.99884 degC; host interpolation of the embedded table agrees within 0.001 degC.
There was no simultaneous external reference for that post-boot reading, so this
verifies the installed conversion, not physical temperature accuracy.

Battery was 3.55546 V before programming and 3.54740 V afterward, still OK but
close to the 3.50-V LOW threshold; the owner was asked to recharge before the next
bench stage. No external W25Q settings/resources/calibration were programmed.
OSL remains absent: all 99 original captures and diagnostic repeats are preserved,
but three high-Z/10-kHz fits still lack observed gain overlap. The temperature
profile does not complete or physically qualify RLC calibration.

See [structured delivery/readback evidence](NTC-Factory-Profile.json),
[unit firmware and raw measurements](../../../Firmware/releases/2026-10-25/ntc-unit-profile/README.md),
[rebuild instructions](../../../Firmware/tools/NTC_FACTORY_PROFILE.md) and
[OSL status](OSL-All-99.md).
''',encoding='utf-8')
(release/'README.md').write_text('''# UID-bound experimental NTC unit delivery

`firmware.zip` contains nine source-bound BIN/ELF/HEX/MAP images and generated
factory-table metadata. These are only for UID 54ff70068370525760380567.
Use the schema2 deployment manifest; manual flashing bypasses the UID binding.
`physical-evidence.zip` preserves all temperature references, uncertainty,
monitoring, verified programming/readback and post-boot conversion evidence.

NTC adjustment is experimental and unqualified; OSL calibration is not installed.
Rebuilds must explicitly select the unit profile. See
[bench report](../../../../docs/review/bringup-2026-10-25/NTC-Factory-Profile.md).
''',encoding='utf-8')
print(json.dumps(dict(status=record['status'],artifacts=record['artifacts']),indent=2))
