"""Owner-directed engineering OSL preparation; no capture or calibration writes."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d

root = Path(__file__).resolve().parent
release = root / 'verified-builds-ntc-unit'
builds = d.load(release / 'firmware-builds.json')
case = next(c for c in builds['cases'] if c['name'] == 'bringup-cal')
if case['status'] != 'PASS' or builds['calibration_hardware_revision'] != 65538:
    raise ValueError('Current passing RGS-to-GND calibration image required')
for filename, meta in case['files'].items():
    data = (release / 'bringup-cal' / filename).read_bytes()
    if len(data) != meta['bytes'] or d.sha(data) != meta['sha256']:
        raise ValueError('Released build artifact differs: ' + filename)
fresh = d.load(root / 'ntc-predeploy-status.json')
if fresh['outcome'] != 'SAFE_IDLE': raise ValueError('Fresh safe-idle calibration preflight required')
state = fresh['status']
if state['busy'] or not state['transfer_safe'] or state['safety_faults'] or state['safety_blocks'] & ~8:
    raise ValueError('Fresh safe state required')

image = d.manifest(release / 'bringup-cal', root / 'image-ntc-unit-001', 'BRINGUP_CAL',
                   builds['source'], 'stm32-bringup-cal')
auth = dict(
    operator='Rodrigo; owner-directed first engineering OSL', utc=d.utc(),
    board='First Rev1 assembled board, six RGS reworked gate-to-GND',
    expected_uid='54ff70068370525760380567', SIMULATED=False,
    previous_profile='BRINGUP_CAL', next_profile='BRINGUP_CAL',
    image_sha256=image['files']['firmware.bin']['sha256'],
    manifest_seal=image['seal_sha256'],
    approval_origin='Owner explicitly requested using the 30.1C reference and calibrating despite possible probe/finger contact interference',
    scope='Deploy verified UID-bound experimental NTC factory LUT only; calibration capture and safety logic unchanged; no OSL installation',
    physical_qualification=False,
    procedural_exception=dict(
        owner_requested_proceed_without_scope=True,
        scope_checks='NOT_TESTED; Hantek unavailable',
        existing_dc_checks='Reuse owner-reported DC checks and preserved bench observations',
        b01_gate='Not approved; no missing physical entry relabelled PASS',
        workflow='Supported engineering capture backend; desktop qualification gate unchanged',
        release='No production-release or accuracy qualification granted'),
    preflight_path=str(root / 'ntc-predeploy-status.json'),
    supply='Battery/boost; fresh SAFE-idle status, charger ABSENT; nominal battery 3.55546V, state OK; no debugger power',
    preservation='Internal Flash only; no external W25Q erase/program requested',
    calibration='Experimental NTC data embedded in MCU image; unqualified and contact-uncertain. OSL remains absent and external W25Q is preserved.',
    acknowledgements=dict(safe_outputs=True, debug_halt_watchdog=True,
                          no_app_bootloader=True, internal_flash=True))
auth['ntc_factory_profile'] = image['ntc_factory_profile']
auth['seal_sha256'] = d.seal(auth)
d.save(root / 'deployment-ntc-unit-authorization.json', auth)
backend = d.OpenOCD(
    'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
    'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts',
    '530049000C0000513751594E')
record = d.deployment('program', root / 'image-ntc-unit-001/manifest.json', backend,
                      root / 'deployment-ntc-unit-001', authorization=auth, uid=auth['expected_uid'])
print(json.dumps({key: record.get(key) for key in ('outcome', 'readback', 'error')}, indent=2))
if record['outcome'] != 'INTERNAL_FLASH_VERIFIED':
    raise SystemExit(1)
