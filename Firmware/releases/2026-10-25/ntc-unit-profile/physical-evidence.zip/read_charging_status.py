import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_cal_capture as c
import pc_firmware_deploy as d
root=Path(__file__).resolve().parent
expected=d.load(root/'boot-identify-ntc-unit-001/report.json')['identity']
link=b.open_serial('COM4')
class ReadOnly:
    def write(self,data):
        kind,sequence,payload=c.decode_frame(data)
        if kind not in (c.IDENTIFY,c.STATUS): raise ValueError('Read-only whitelist')
        for byte in data:
            if link.write(bytes([byte]))!=1: raise OSError('Partial write')
            time.sleep(0.001)
        return len(data)
    def read(self,count=1): return link.read(count)
try:
    client=c.Client(ReadOnly())
    identity=client.identify()
    if identity!=expected: raise ValueError('Identity differs')
    state=client.status()
    if state['busy'] or not state['transfer_safe'] or state['safety_faults']: raise ValueError('SAFE idle required')
    report=dict(recorded_utc=d.utc(),operation='READ_ONLY_UART_CHARGING_STATUS',identity=identity,status=state,charger_present=bool(state['safety_blocks']&1),voltage_unavailable_without_swd=True,STLink_disconnected_by_owner=True,capture_started=False)
    d.save(root/'charging-ntc-unit-001.json',report)
    print(json.dumps(report,indent=2))
finally: link.close()
