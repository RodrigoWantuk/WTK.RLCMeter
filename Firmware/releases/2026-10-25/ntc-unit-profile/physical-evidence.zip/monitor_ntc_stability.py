"""Bounded read-only SAFE/idle NTC monitor; never starts acquisition."""
import json
from pathlib import Path
import struct
import sys
import time
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_cal_capture as c
import pc_firmware_deploy as d
root=Path(__file__).resolve().parent
out=root/'ntc-stability-001'
out.mkdir(exist_ok=False)
stop=root/'ntc-stability.stop'
if stop.exists(): raise ValueError('Unexpected existing stop request')
expected=d.load(root/'boot-identify-zero-short-001/report.json')['identity']
link=b.open_serial('COM4')
class ReadOnly:
    def write(self,data):
        kind,seq,payload=c.decode_frame(data)
        if kind not in (c.IDENTIFY,c.STATUS): raise ValueError('Read-only command whitelist')
        for byte in data:
            if link.write(bytes([byte]))!=1: raise OSError('Partial write')
            time.sleep(0.001)
        return len(data)
    def read(self,count=1): return link.read(count)
samples=[]
report=dict(started_utc=d.utc(),operation='READ_ONLY_NTC_STABILITY',correction_applied=False,stop_reason=None,samples=samples)
try:
    client=c.Client(ReadOnly())
    if client.identify()!=expected: raise ValueError('Identity changed')
    baseline=None
    deadline=time.monotonic()+90
    while time.monotonic()<deadline and not stop.exists():
        _,data=client.command(c.STATUS)
        if len(data)!=32: raise ValueError('Status length')
        faults,blocks,errors=struct.unpack_from('<III',data,8)
        if data[25] or not data[28] or faults or blocks & ~8: raise ValueError('SAFE idle required')
        if baseline is None: baseline=errors
        if errors!=baseline: raise ValueError('New communication error')
        sample=dict(utc=d.utc(),temperature_c=struct.unpack_from('<i',data,20)[0]/1000,temperature_valid=bool(data[29]),protocol_errors=errors)
        samples.append(sample)
        window=samples[-10:]
        span=max(v['temperature_c'] for v in window)-min(v['temperature_c'] for v in window)
        sample['ten_sample_span_c']=span
        sample['stable_10s']=len(window)==10 and all(v['temperature_valid'] for v in window) and span<=0.15
        d.save(out/'report.json',report)
        if len(samples)%5==0: print(json.dumps(sample),flush=True)
        time.sleep(1)
    report['stop_reason']='HOST_REFERENCE_READY' if stop.exists() else '90_SECOND_LIMIT'
finally:
    link.close()
    report['completed_utc']=d.utc()
    d.save(out/'report.json',report)
    print(json.dumps(dict(stop_reason=report['stop_reason'],samples=len(samples),last=samples[-1] if samples else None)),flush=True)
