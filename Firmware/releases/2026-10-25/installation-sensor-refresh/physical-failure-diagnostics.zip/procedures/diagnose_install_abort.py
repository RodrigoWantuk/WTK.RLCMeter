import os,sys,subprocess,time,json
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
root=Path(__file__).resolve().parent
out=root/'install-abort-diagnostic-001';out.mkdir(exist_ok=False)
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
p=b.plan('probe',out,None,'54ff70068370525760380567')
e=dict(os.environ,**p['environment']);e['WTK_DIAG_FLAGS']=str((out/'snapshot-flags.bin').resolve());e['WTK_DIAG_REFRESH']=str((out/'refresh-pending.bin').resolve())
p['argv'][-1]='if {[catch {init; halt; wtk_preflight; bp 0x080070d8 2 hw; resume; echo "WTK_DIAG_ARMED"; wait_halt 20000; reg r0; reg r1; reg r2; reg r3; reg lr; set sr [get_reg sp]; set sv [dict get $sr sp]; dump_image $::env(WTK_DIAG_FLAGS) [expr {$sv+456}] 15; dump_image $::env(WTK_DIAG_REFRESH) [expr {$sv+474}] 1; echo "WTK_DIAG_TIME"; mdw 0x200001a8 1; rbp 0x080070d8; resume; echo "WTK_DIAG_RESUMED"} reason]} {echo $reason; catch {rbp 0x080070d8}; catch {resume}; shutdown error} else {shutdown}'
f=(out/'openocd.txt').open('wb')
proc=subprocess.Popen(p['argv'],env=e,stdout=f,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
try:
 deadline=time.monotonic()+8
 while time.monotonic()<deadline:
  if 'WTK_DIAG_ARMED' in (out/'openocd.txt').read_text(errors='replace'):break
  if proc.poll() is not None:raise RuntimeError('Debugger exited before armed')
  time.sleep(.05)
 else:raise RuntimeError('Debugger not armed')
 run=subprocess.run([sys.executable,str(root/'install_condition_composition_diagnostic.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 (out/'installer.txt').write_bytes(run.stdout)
 proc.wait(timeout=25)
 print((out/'openocd.txt').read_text(errors='replace'))
 print(run.stdout.decode(errors='replace'))
finally:
 f.close()
 if proc.poll() is None:proc.wait(timeout=25)
