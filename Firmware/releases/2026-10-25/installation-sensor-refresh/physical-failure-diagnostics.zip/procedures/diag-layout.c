#include <stddef.h>
#include "hardware/hw_aux_sensors.h"
const unsigned offsets[]={offsetof(hw_aux_sensors_t,snapshot),offsetof(hw_aux_sensors_t,residual_policy),offsetof(hw_aux_sensors_t,residual_timestamp_ms),offsetof(hw_aux_sensors_t,residual_published),offsetof(hw_aux_sensors_snapshot_t,residual_state),offsetof(hw_aux_sensors_snapshot_t,residual_safe_count),offsetof(hw_aux_sensors_snapshot_t,battery_raw)};
