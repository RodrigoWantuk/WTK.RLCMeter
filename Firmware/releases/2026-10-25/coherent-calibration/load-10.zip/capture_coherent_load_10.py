"""Owner-confirmed LOAD sweep; supported capture API, no writes or retries."""
import json
from pathlib import Path
import sys
import time
import struct
from datetime import datetime, timezone

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl
import pc_osl_campaign as g
from pc_osl_install import Installer

root = Path(__file__).resolve().parent
expected = d.load(root / 'boot-identify-coherent-calibration-001/report.json')
if expected['outcome'] != 'PHYSICAL_CAL_SERVICE_IDENTIFIED_SAFE_IDLE':
    raise ValueError('Verified physical calibration service required')
out = root / 'coherent-load-10-001'
out.mkdir(exist_ok=False)
report = dict(started_utc=d.utc(), SIMULATED=False, standard='LOAD',
    operator='Rodrigo', fixture='Only owner-confirmed nominal 10-ohm +/-1% resistor directly across TEST_HI/TEST_LO',
    owner_confirmation=dict(
        question='Confirm only the freshly measured nominal 10-ohm resistor directly attached across TEST_HI/TEST_LO',
        answer='pronto, 10.4R, conectado', scope='One explicit owner confirmation covers this entire unchanged LOAD sweep'),
    required=3, accepted=[], attempts=[], error=None, installed=False,
    physically_qualified=False, scope_checks='NOT_TESTED; owner-directed engineering OSL')
reference = dict(id='R10', impedance_ohms=[10.0, 0.0], tolerance_pct=1.0)
battery = d.load(root / 'coherent-battery-before-load-10-001.json')
if battery['identity'] != expected['identity'] or battery['status'].get('battery_voltage_v') is None or battery['status']['battery_voltage_v'] <= 3.5 or battery['status']['safety_blocks'] & ~8:
    raise ValueError('Normal battery reading required; ask owner to recharge if low')
if (datetime.now(timezone.utc)-datetime.fromisoformat(battery['recorded_utc'])).total_seconds() > 300:
    raise ValueError('Repeat battery check before new resistor; old snapshot rejected')
report.update(reference=reference, owner_dmm_reading_ohms=10.4, dmm='Minipa ET-1100A, 200-ohm range', owner_short_leads_ohms=0.5, reference_policy='Printed nominal +/-1% fit anchor; DMM consistency only, no fixed lead subtraction or certified actual value', battery_check=battery, battery_before_each_new_resistor_required=True)
endpoints = d.load(root / 'coherent-short-full-001/captures.json')
c.verify_campaign(endpoints, expected['identity'])
report['endpoint_capture_sha256'] = d.sha((root / 'coherent-short-full-001/captures.json').read_bytes())
events = []
current = None
start_sent = False
client = None
link = b.open_serial('COM4')

def persist():
    d.save(out / 'report.json', report)
    d.save(out / 'wire-events.json', events)

def require_safe(state):
    if (state['busy'] or not state['transfer_safe'] or state['safety_faults']
            or state['safety_blocks'] & ~8 or state['calibration_sequence'] != 0
            or state['calibrated'] or state.get('battery_voltage_v') is None or state['battery_voltage_v'] <= 3.5):
        raise ValueError('Unexpected unsafe/busy/calibration state: ' + str(state))

class Transport:
    def write(self, data):
        global start_sent
        kind, sequence, payload = c.decode_frame(data)
        if kind not in (c.IDENTIFY, c.STATUS, c.START, c.RESULT, c.CANCEL, 0x59):
            raise ValueError('LOAD capture command whitelist violation')
        if kind == c.START:
            if current is None or start_sent or payload[8:12] != bytes((*current.ids(), 2)) or payload[12:] != struct.pack('<2f', 10.0, 0.0):
                raise ValueError('START differs from confirmed LOAD condition or is a retry')
            start_sent = True
        events.append(dict(utc=d.utc(), direction='TX', hex=data.hex()))
        for byte in data:
            if link.write(bytes([byte])) != 1:
                raise OSError('Partial serial write; no automatic retry')
            time.sleep(0.001)
        return len(data)

    def read(self, count=1):
        data = link.read(count)
        if data:
            events.append(dict(utc=d.utc(), direction='RX', hex=data.hex()))
        return data

try:
    class LoggedClient(c.Client):
        def wait_capture_quiet(self, seconds):
            print(f'UART QUIET {seconds:.0f}s', flush=True)
            return super().wait_capture_quiet(seconds)
    client = LoggedClient(Transport())
    identity = client.identify()
    report['identity'] = identity
    if identity != expected['identity']:
        raise ValueError('Device/firmware identity differs from verified boot')
    initial = client.status()
    require_safe(initial)
    report['initial_status'] = initial
    storage = Installer(client).status()
    report['initial_installation_status'] = storage
    if storage['active_valid'] or storage['active_sequence'] != 0 or storage['next_sequence'] != 1:
        raise ValueError('Calibration sequence differs from blank session')
    report['protocol_errors_baseline'] = initial['protocol_errors']
    persist()
    keys = tuple(k for k in pc_osl.KEYS if k.rref_ohms == 10)
    if len(keys) != 3 or any(k.amplitude_mvrms != 100 for k in keys):
        raise ValueError('Exactly three allowed 10-ohm keys required')
    report['condition_order'] = [k.as_json() for k in keys]
    report['new_cohort'] = 'Same source-a52dba35 CCO2 LOAD with exactly 66 current OPEN/SHORT artifacts; older cohorts remain separate'
    for index, key in enumerate(keys, 1):
        current, start_sent = key, False
        attempt = dict(started_utc=d.utc(), condition=key.as_json(), standard='LOAD',
                       owner_confirmation='Same explicit unchanged-fixture sweep authorization')
        report['attempts'].append(attempt)
        persist()
        if client.identify() != identity:
            raise ValueError('Device identity changed before capture')
        require_safe(client.status())
        print(f'LOAD {index}/{len(keys)} START RREF={key.rref_ohms} Hz={key.frequency_hz} mVrms={key.amplitude_mvrms}', flush=True)
        row = client.capture(key, 'LOAD', reference)
        # Keep the received artifact before any additional host quality check.
        name = f'{index:02d}-r{key.rref_ohms}-f{key.frequency_hz}-a{key.amplitude_mvrms}'
        (out / (name + '.cco2')).write_bytes(bytes.fromhex(row['artifact_hex']))
        d.save(out / (name + '.json'), row)
        quality = g.quality(row)
        if not quality['usable_paths']:
            raise ValueError('No usable LOAD return path; stop for diagnosis')
        final = client.status()
        require_safe(final)
        if final['protocol_errors'] != initial['protocol_errors']:
            raise ValueError('New protocol error; stop without retry')
        document = c.save_capture(out / 'captures.json', row)
        c.verify_campaign(document, identity)
        triplet = [pc_osl.standard_from_capture(r) for r in endpoints['captures'] if r['condition'] == key.as_json()] + [pc_osl.standard_from_capture(row)]
        solution = pc_osl.solve(triplet)
        d.save(out / (name + '-fit.json'), dict(condition=key.as_json(), fit_channel=solution.fit_channel, hg_observed=solution.hg_observed, min_separation=solution.min_separation, values=solution.values(), physically_qualified=False))
        attempt.update(fit_channel=solution.fit_channel, completed_utc=d.utc(), outcome='ACCEPTED', sha256=row['sha256'],
                       quality=quality, final_status=final)
        report['accepted'].append(dict(condition=key.as_json(), sha256=row['sha256'], quality=quality))
        report['last_safe_status'] = final
        persist()
        print(f'LOAD {index}/{len(keys)} ACCEPTED paths={quality["usable_paths"]} repeats={quality["repeats"]} clipping={quality["clipping_mask"]} SAFE', flush=True)
    report['final_installation_status'] = Installer(client).status()
    if report['final_installation_status'] != storage:
        raise ValueError('Unexpected persistent calibration-state change')
    report['outcome'] = 'ALL_3_LOAD_CAPTURES_ACCEPTED'
except BaseException as exc:
    report.update(outcome='STOPPED_NO_AUTOMATIC_RETRY', error=type(exc).__name__ + ': ' + str(exc))
    if report['attempts'] and report['attempts'][-1].get('outcome') is None:
        report['attempts'][-1].update(outcome='STOPPED', error=report['error'])
    if client is not None:
        try:
            state = client.status()
            report['recovery_status'] = state
            if state['busy']:
                report['recovery_cancellation'] = g.cancel_pending(client)
                state = client.status()
                report['recovery_status'] = state
            require_safe(state)
            report['safe_after_stop'] = True
        except BaseException as recovery:
            report['safe_after_stop'] = False
            report['recovery_error'] = type(recovery).__name__ + ': ' + str(recovery)
    raise
finally:
    link.close()
    report['completed_utc'] = d.utc()
    persist()
    print(json.dumps({key: report.get(key) for key in
        ('outcome', 'error', 'safe_after_stop', 'last_safe_status', 'recovery_status')}, indent=2), flush=True)

