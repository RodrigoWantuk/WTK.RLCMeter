"""Read-only audit; preserves complete original triplets and never relabels frames."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_cal_capture as capture
import pc_firmware_deploy as deploy
import pc_osl

root=Path(__file__).resolve().parent
old_ref='7017e5e0bc6e7188de3c6b270d49267f322c096d'
target_ref='a52dba35c74e0643a8b15d916eb29c427d917f77'
def git(*args): return subprocess.check_output(['git',*args])
def tree(ref):
    output=git('ls-tree','-r',ref,'Firmware/src/bsp','Firmware/src/hardware','Firmware/src/measurement').decode()
    return {line.split('\t')[1]:line.split()[2] for line in output.splitlines()}
old_tree,new_tree=tree(old_ref),tree(target_ref)
excluded={'Firmware/src/hardware/hw_power.c','Firmware/src/hardware/hw_power.h'}
critical=[]
for path in sorted((set(old_tree)|set(new_tree))-excluded):
    if old_tree.get(path)!=new_tree.get(path): raise ValueError('Acquisition/runtime source changed: '+path)
    critical.append(dict(path=path,unchanged_git_blob=old_tree[path]))
def function(ref,path,name):
    text=git('show',ref+':'+path).decode()
    match=re.search(r'\b'+re.escape(name)+r'\s*\(',text)
    start=text.index('{',match.end()); depth=1; end=start+1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[start:end]
function_audit=[]
for path,names in [('Firmware/src/app/app_calibration_workflow.c',
    ('stats_stable_scaled','sample_reject_flags','evaluate_completion','make_sample_from_phasors','app_calibration_workflow_sample_from_block')),
    ('Firmware/src/hardware/hw_power.c',('hw_battery_vbat_from_adc_voltage','hw_battery_state_from_voltage'))]:
    for name in names:
        before,after=function(old_ref,path,name),function(target_ref,path,name)
        if before!=after: raise ValueError('Critical function changed: '+name)
        function_audit.append(dict(path=path,function=name,unchanged_body_sha256=hashlib.sha256(before.encode()).hexdigest()))
old_flags=deploy.parse_config((root/'verified-builds-zero-short/bringup-cal/generated/wtk_build_config.h').read_bytes())
new_flags=deploy.parse_config((root/'verified-builds-coherent-calibration/bringup-cal/generated/wtk_build_config.h').read_bytes())
allowed={'WTK_GIT_COMMIT','WTK_ENABLE_CAL_INTEGRATION','WTK_NTC_FACTORY_CALIBRATION','WTK_NTC_FACTORY_UID','WTK_NTC_PROFILE_SHA256'}
for key in set(old_flags)|set(new_flags):
    if key not in allowed and old_flags.get(key)!=new_flags.get(key): raise ValueError('Unexpected build change: '+key)
old_path=root/'same-image-all-99.json'; new_path=root/'coherent-through-load-10-001.json'
old=json.loads(old_path.read_text());new=json.loads(new_path.read_text())
old_identity=old['captures'][0]['device'];new_identity=new['captures'][0]['device']
capture.verify_campaign(old,old_identity);capture.verify_campaign(new,new_identity)
for field in ('uid','hardware_revision','model','adc_provenance','synthetic'):
    if old_identity[field]!=new_identity[field]: raise ValueError('Device/model mismatch')
if old_identity['synthetic'] or old['adc']!=new['adc']: raise ValueError('Real identical ADC provenance required')
selected=[];pending=[]; current_fits=[]
for key in pc_osl.KEYS:
    reuse=key.rref_ohms in (100,1000,10000)
    document=old if reuse else new
    rows=[row for row in document['captures'] if row['condition']==key.as_json()]
    if len(rows)!=3:
        pending.append(key.as_json());continue
    if {row['standard'] for row in rows}!={'OPEN','SHORT','LOAD'} or len({row['device']['git'] for row in rows})!=1:
        raise ValueError('Each fit must retain one complete original firmware cohort')
    solution=pc_osl.solve([pc_osl.standard_from_capture(row) for row in rows])
    item=dict(condition=key.as_json(),source_git=rows[0]['device']['git'],
        triplet_sha256={row['standard']:row['sha256'] for row in rows},
        fit_channel=solution.fit_channel,hg_observed=solution.hg_observed,
        serialized_float32_values=solution.values())
    if reuse:
        endpoints=[row for row in new['captures'] if row['condition']==key.as_json() and row['standard']!='LOAD']
        if len(endpoints)!=2 or any(row['acquisition'].get('blocks_per_group')!=1 for row in endpoints):
            raise ValueError('Target condition is not the unchanged one-block path')
        item['target_endpoint_check_sha256']={row['standard']:row['sha256'] for row in endpoints}
        selected.append(item)
    else: current_fits.append(item)
if len(selected)!=18 or len(current_fits)!=3 or len(pending)!=12:
    raise ValueError('Unexpected bounded reuse scope')
report=dict(status='SOURCE_AND_CONDITION_COMPATIBILITY_AUDIT_PASS_PENDING_12_HIGH_Z_LOADS',
    old_ref=old_ref,target_ref=target_ref,uid=new_identity['uid'],hardware_revision=new_identity['hardware_revision'],
    model=new_identity['model'],adc=new['adc'],critical_unchanged_files=critical,
    critical_unchanged_functions=function_audit,explicit_build_changes=sorted(allowed),
    reused_complete_triplets=selected,current_complete_triplets=current_fits,pending_current_conditions=pending,
    remaining_fixture_nominal_ohms=[100000,1000000],
    cohort_policy='Compose complete per-condition OSL fits; each triplet stays within its original verified firmware cohort. Never relabel or rewrite captured identity/flags.',
    temperature_policy='Original per-condition reported temperatures retained with original nominal/experimental NTC source provenance. Scales are not directly comparable; no thermal qualification or compensation claimed. Base model5 runtime is unchanged; supplementary curves disabled.',
    candidate_generated=False,installed=False,physically_qualified=False,
    source_files=dict(old=dict(path=str(old_path),sha256=hashlib.sha256(old_path.read_bytes()).hexdigest()),
                      current=dict(path=str(new_path),sha256=hashlib.sha256(new_path.read_bytes()).hexdigest())))
deploy.save(root/'condition-reuse-audit-001.json',report)
print(json.dumps(dict(status=report['status'],reused_conditions=len(selected),current_complete=len(current_fits),
    pending_conditions=len(pending),remaining_resistors=report['remaining_fixture_nominal_ohms'],
    unchanged_critical_files=len(critical)),indent=2))
