"""Offline first-unit composition: complete original triplets, explicit origins.

No serial, SWD or storage access. Default campaign identity checks are unchanged.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_cal_capture as capture
import pc_osl
from pc_osl_install import validate_candidate

parser=argparse.ArgumentParser()
parser.add_argument('--current',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--sequence',type=int,default=1)
args=parser.parse_args()
root=Path(__file__).resolve().parent
audit_path=root/'condition-reuse-audit-001.json'
audit=json.loads(audit_path.read_text())
if audit['status']!='SOURCE_AND_CONDITION_COMPATIBILITY_AUDIT_PASS_PENDING_12_HIGH_Z_LOADS':
    raise ValueError('Explicit bounded compatibility audit required')
old_path=root/'same-image-all-99.json'
seed_path=root/'coherent-through-load-10-001.json'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
if digest(old_path)!=audit['source_files']['old']['sha256'] or digest(seed_path)!=audit['source_files']['current']['sha256']:
    raise ValueError('Audited source evidence changed')
def tree(ref):
    text=subprocess.check_output(['git','ls-tree','-r',ref,'Firmware/src/bsp','Firmware/src/hardware','Firmware/src/measurement']).decode()
    return {line.split('\t')[1]:line.split()[2] for line in text.splitlines()}
before,after=tree(audit['old_ref']),tree(audit['target_ref'])
excluded={'Firmware/src/hardware/hw_power.c','Firmware/src/hardware/hw_power.h'}
proof={row['path']:row['unchanged_git_blob'] for row in audit['critical_unchanged_files']}
if set(proof)!=(set(before)|set(after))-excluded or any(before.get(path)!=blob or after.get(path)!=blob for path,blob in proof.items()):
    raise ValueError('Source compatibility proof differs from Git objects')
old=json.loads(old_path.read_text());current=json.loads(args.current.read_text())
old_identity=old['captures'][0]['device'];current_identity=current['captures'][0]['device']
capture.verify_campaign(old,old_identity);capture.verify_campaign(current,current_identity)
if old_identity['git']!=audit['old_ref'][:8] or current_identity['git']!=audit['target_ref'][:8]:
    raise ValueError('Unreviewed source cohort')
for identity in (old_identity,current_identity):
    if identity['uid']!=audit['uid'] or identity['hardware_revision']!=audit['hardware_revision'] or identity['model']!=audit['model'] or identity['synthetic']:
        raise ValueError('Real audited unit/model required')
if old['adc']!=current['adc'] or current['adc']!=audit['adc']:
    raise ValueError('ADC provenance/scales changed')
seed=json.loads(seed_path.read_text())
current_rows={(pc_osl.Key.from_json(row['condition']),row['standard']):row for row in current['captures']}
for row in seed['captures']:
    key=(pc_osl.Key.from_json(row['condition']),row['standard'])
    if current_rows.get(key)!=row: raise ValueError('Current source seed changed')
reuse_proof={pc_osl.Key.from_json(row['condition']):row for row in audit['reused_complete_triplets']}
if set(reuse_proof)!={key for key in pc_osl.KEYS if key.rref_ohms in (100,1000,10000)}:
    raise ValueError('Reuse scope must stay at the 18 explicitly audited conditions')
groups=[];solutions=[];manifest=[];missing=[]
for key in pc_osl.KEYS:
    reuse=key in reuse_proof
    document=old if reuse else current
    rows=[row for row in document['captures'] if row['condition']==key.as_json()]
    by_type={row['standard']:row for row in rows}
    if set(by_type)!={'OPEN','SHORT','LOAD'}:
        missing.append(key.as_json());continue
    rows=[by_type[kind] for kind in ('OPEN','SHORT','LOAD')]
    if len({json.dumps(row['device'],sort_keys=True) for row in rows})!=1:
        raise ValueError('Each complete triplet must retain one original source identity')
    hashes={row['standard']:row['sha256'] for row in rows}
    if reuse and hashes!=reuse_proof[key]['triplet_sha256']:
        raise ValueError('Reused triplet differs from its audited original')
    standards=[pc_osl.standard_from_capture(row) for row in rows]
    solution=pc_osl.solve(standards)
    groups.append(standards);solutions.append(solution)
    manifest.append(dict(condition=key.as_json(),origin='REUSED_COMPLETE_ORIGINAL_TRIPLET' if reuse else 'CURRENT_COMPLETE_TRIPLET',
        original_device=rows[0]['device'],artifact_sha256=hashes,reference=by_type['LOAD']['reference'],
        temperature_source='Original nominal NTC metadata' if reuse else 'UID-bound experimental NTC metadata',
        fit_channel=solution.fit_channel,hg_observed=solution.hg_observed,
        serialized_float32_values=solution.values()))
if missing:
    raise ValueError('No candidate: '+str(len(missing))+' complete current triplets still missing: '+json.dumps(missing))
if len(groups)!=33 or len(manifest)!=33: raise ValueError('Exactly 33 complete conditions required')
args.out.mkdir(exist_ok=False)
python_frame=pc_osl.serialize(solutions,args.sequence,current['adc']['values'])
validate_candidate(python_frame)
(args.out/'python-candidate.bin').write_bytes(python_frame)
# PCOS is the existing test-bridge input, never a device-installable frame.
oracle=bytearray(b'PCOS'+struct.pack('<I12f',args.sequence,*current['adc']['values']))
for standards in groups:
    oracle+=struct.pack('<3Bx2f',*standards[0].key.ids(),*pc_osl.pair(standards[2].load))
    for standard in standards:
        flags=int(standard.ret_1x_valid)|(int(standard.ret_hg_valid)<<1)|(int(standard.hg_observed)<<2)
        if standard.temperature_mC is not None: flags|=8
        oracle+=struct.pack('<4fiI',*pc_osl.pair(standard.t_1x),*pc_osl.pair(standard.t_hg_raw),standard.temperature_mC or 0,flags)
(args.out/'c-solver-input.bin').write_bytes(oracle)
bridge=root/'ntc-host-tests/tests/Debug/wtk_pc_osl_bridge.exe'
run=subprocess.run([str(bridge),'solve',str(args.out/'c-solver-input.bin'),str(args.out/'c-candidate.bin')],
    stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
(args.out/'c-solver.log').write_bytes(run.stdout)
if run.returncode: raise ValueError('Actual C full-set solver rejected the composition: '+run.stdout.decode(errors='replace'))
c_frame=(args.out/'c-candidate.bin').read_bytes();validate_candidate(c_frame)
for index,standards in enumerate(groups):
    offset=120+index*80
    values=struct.unpack_from('<12f',c_frame,offset+22)
    hg,load,short,opened,k,reserved=[complex(*values[j:j+2]) for j in range(0,12,2)]
    actual_load=standards[2]
    transfer=actual_load.t_1x if solutions[index].fit_channel=='1X' else actual_load.t_hg_raw/hg
    corrected=k*(transfer-short)/(transfer-opened)
    if abs(corrected-load)>max(1e-5,abs(load)*5e-5):
        raise ValueError('Serialized C fit fails the existing LOAD-center consistency criterion')
# Publish the candidate only after both solvers and canonical validation pass.
(args.out/'candidate.bin').write_bytes(c_frame)
report=dict(format='WTK_PC_OSL_CONDITION_COMPOSITION_V1',status='ALL_33_COMPLETE_CONDITIONS_C_AND_PYTHON_VALIDATED',
    intended_uid=audit['uid'],hardware_revision=audit['hardware_revision'],model=audit['model'],sequence=args.sequence,
    conditions=manifest,reused_conditions=18,current_conditions=15,
    audit_sha256=digest(audit_path),old_capture_sha256=digest(old_path),current_capture_sha256=digest(args.current),
    candidate_sha256=digest(args.out/'candidate.bin'),c_bridge_sha256=digest(bridge),
    python_and_c_frames_byte_equal=python_frame==c_frame,adc=current['adc'],
    temperature_policy=audit['temperature_policy'],physically_qualified=False,installed=False)
(args.out/'composition.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('status','reused_conditions','current_conditions','candidate_sha256','python_and_c_frames_byte_equal')},indent=2))
