# Firmware deployment — REAL_BACKEND / NOT PHYSICALLY QUALIFIED

SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.

Outcome: INTERNAL_FLASH_VERIFIED

Programming: CONFIRMED; internal readback: PASS; boot: NOT_TESTED; UART: NOT_TESTED; application: NOT_TESTED.

External W25Q was not accessed. OSL/Resource Pack remain independently accepted prerequisites.

```json
{
  "schema": "WTK_DEPLOYMENT_1",
  "transaction": "779118dc-71b3-47db-9b1b-efed6a6c0338",
  "operation": "program",
  "started_utc": "2026-10-25T22:02:49.073837+00:00",
  "SIMULATED": false,
  "image": {
    "schema": "WTK_FIRMWARE_2",
    "source": {
      "git_sha": "46df1fbb557a803da7df9683ddfbc2ff124cb1dc",
      "dirty": false,
      "git_status": "",
      "input_sha256": "d3aa16a65ef52e3755bdce8121c25af74776a0e56afc64a99b193470ea8f4338"
    },
    "profile": "FACTORY_PRODUCT",
    "factory_provisioned": true,
    "supplementary_curves": false,
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "bringup_k1_test": false,
    "bringup_bench_supply": false,
    "bringup_peripheral_test": false,
    "preset": "stm32-factory-release",
    "build_configuration": "Release",
    "hardware": "Rev1-STM32F103C8T6-BluePill",
    "firmware_version": "0.1.0",
    "expected_boot": {
      "interface": "LIMITED_UART_UI_REQUIRED",
      "firmware_version": "0.1.0",
      "hardware": "Rev1-STM32F103C8T6-BluePill",
      "git_prefix": null,
      "limitation": "PRODUCT banner is only WTK.RLCMeter SAFE_BOOT; UI/bench acceptance separate"
    },
    "toolchain": {
      "compiler_path": "C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin/arm-none-eabi-gcc.exe",
      "compiler_version": "arm-none-eabi-gcc.exe (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119",
      "cmake": "cmake version 4.4.4",
      "cache_sha256": "68d4a9614cf170c48b93285dbc72486442c5af2e98e4de971ea9682fad5dcc8b"
    },
    "memory": {
      "flash_base": 134217728,
      "flash_bytes": 65536,
      "ram_base": 536870912,
      "ram_bytes": 20480,
      "internal_page_bytes": 1024
    },
    "linked": {
      "flash_bytes": 53968,
      "bss": 13468,
      "ram_static_bytes": 13516,
      "noinit_bytes": 0,
      "reserved_stack_bytes": 2052,
      "ram_accounted_bytes": 15568
    },
    "binary_size": 53968,
    "files": {
      "firmware.bin": {
        "bytes": 53968,
        "sha256": "b4ff21efaad1928731b4db07616dbc134d3087ee15e8d48694a0fcbbac758e3d"
      },
      "firmware.elf": {
        "bytes": 89124,
        "sha256": "4a486291e9828a662e6b9a37b67bbe4b79cf0cc8e909c734e94d38f6db6f7134"
      },
      "build_config.h": {
        "bytes": 1094,
        "sha256": "23830c3f0974ead124809c64db0eb60630513a356ad611fafd7d56c6d89ce773"
      },
      "linker.ld": {
        "bytes": 2244,
        "sha256": "1450e7143121ccf933b06af5d728b2ba60d5d41c4592748ff2a7ab77337c53c0"
      }
    },
    "built_utc": "2026-10-25T22:02:45.524095+00:00",
    "seal_sha256": "5c04c60e3296659471445385f0cb24366853d77632e15a88f59f0cdb782b8b19",
    "manifest_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\image-calibrated-product-001\\manifest.json",
    "staged_binary": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-001\\staged-image.bin"
  },
  "authorization": {
    "operator": "Rodrigo; owner-directed continuation into calibrated production without another resistor campaign",
    "utc": "2026-10-25T22:02:48.975539+00:00",
    "board": "First Rev1 board, six RGS gate-to-GND rework",
    "expected_uid": "54ff70068370525760380567",
    "SIMULATED": false,
    "previous_profile": "BRINGUP_CAL",
    "next_profile": "FACTORY_PRODUCT",
    "image_sha256": "b4ff21efaad1928731b4db07616dbc134d3087ee15e8d48694a0fcbbac758e3d",
    "manifest_seal": "5c04c60e3296659471445385f0cb24366853d77632e15a88f59f0cdb782b8b19",
    "approval_origin": "Owner requested next step after persistent calibration, firmware production status and capacitor/inductor/autorange review; earlier authorization includes firmware programming",
    "scope": "Controlled calibrated PRODUCT handoff; internal Flash only; preserve exact active OSL sequence1, W25Q assets/settings and experimental UID-bound NTC; no DUT measurement commanded",
    "physical_qualification": false,
    "procedural_exception": {
      "owner_requested_proceed_without_scope": true,
      "scope_checks": "NOT_TESTED; no new physical qualification inferred",
      "b01_gate": "Independent scope/hardware qualification remains pending"
    },
    "preflight_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\product-deploy-preflight-001.json",
    "supply": "Previously owner-confirmed battery/boost; fresh serial battery adequate and charger absent",
    "preservation": "No external W25Q erase/program requested",
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "osl": {
      "sequence": 1,
      "sha256": "af76d19b15a510dff0c880a4ab6e86893e0065ac7e845b9930111680752da78c",
      "fresh_readback": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\product-deploy-preflight-readback.bin"
    },
    "acknowledgements": {
      "safe_outputs": true,
      "debug_halt_watchdog": true,
      "no_app_bootloader": true,
      "internal_flash": true
    },
    "seal_sha256": "12d04691365eb2e6b883cdca119bfb77ba8f894978c0aa17820f60937964cff9"
  },
  "programming": "CONFIRMED",
  "internal_readback": "PASS",
  "boot": "NOT_TESTED",
  "uart_identity": "NOT_TESTED",
  "application": "NOT_TESTED",
  "external_w25q_access": false,
  "physically_validated": false,
  "outcome": "INTERNAL_FLASH_VERIFIED",
  "error": null,
  "transcripts": [
    {
      "path": "preflight/openocd.txt",
      "sha256": "b69cbb8f689cbceb72ec5ec4e8ec0ede2ae1144dff6005c99edcfb7d55329371"
    },
    {
      "path": "openocd.txt",
      "sha256": "8449dc52f2b71e6a64d4d61db994b636e78afb5ee66805c3602e948e77b2377b"
    }
  ],
  "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.",
  "seal_sha256": "60f69e7537b487f19ceaf96d03608aa309474a6a46aad32274036790dcdc5fe5",
  "preflight": {
    "target": {
      "device_id": 537093136,
      "cpuid": 1092600369,
      "flash_kib": 64,
      "obr": 67108860,
      "wrpr": 4294967295,
      "uid": "54ff70068370525760380567",
      "flash_base": 134217728,
      "flash_bytes": 65536,
      "driver": "stm32f1x",
      "state": "halted",
      "target_voltage_v": 3.297196
    },
    "programmer": {
      "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
      "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
      "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "config_hashes": {
        "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
        "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
      },
      "toolkit_script_sha256": "43bcdb67c2ce390bfd6adb0db481e7f046cc004aa0555976a0830e778cd6a968",
      "deployment_tool_sha256": "36e6df40f36b1bc2588561cc9b3cc16543c235425c65acaf7dade80b5abb1e05",
      "adapter_serial_selection": "530049000C0000513751594E"
    },
    "plan": {
      "argv": [
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
        "-s",
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
        "-c",
        "source $::env(WTK_INTERFACE)",
        "-c",
        "transport select dapdirect_swd",
        "-c",
        "adapter serial $::env(WTK_SERIAL)",
        "-c",
        "source $::env(WTK_TARGET)",
        "-c",
        "gdb_port disabled; tcl_port disabled; telnet_port disabled",
        "-c",
        "source $::env(WTK_LIBRARY)",
        "-c",
        "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
      ],
      "environment": {
        "WTK_SERIAL": "530049000C0000513751594E",
        "WTK_ACTION": "probe",
        "WTK_UID": "54ff70068370525760380567",
        "WTK_LENGTH": "0",
        "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
        "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
        "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
        "WTK_IMAGE": "",
        "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-001\\preflight\\before.bin",
        "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-001\\preflight\\full-readback.bin"
      },
      "internal_flash_range": [
        134217728,
        134283264
      ],
      "program_range": null,
      "erase_range": null,
      "external_w25q_access": false,
      "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
    }
  },
  "target": {
    "device_id": 537093136,
    "cpuid": 1092600369,
    "flash_kib": 64,
    "obr": 67108860,
    "wrpr": 4294967295,
    "uid": "54ff70068370525760380567",
    "flash_base": 134217728,
    "flash_bytes": 65536,
    "driver": "stm32f1x",
    "state": "halted",
    "target_voltage_v": 3.297196
  },
  "programmer": {
    "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
    "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
    "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
    "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
    "config_hashes": {
      "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
      "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
    },
    "toolkit_script_sha256": "43bcdb67c2ce390bfd6adb0db481e7f046cc004aa0555976a0830e778cd6a968",
    "deployment_tool_sha256": "36e6df40f36b1bc2588561cc9b3cc16543c235425c65acaf7dade80b5abb1e05",
    "adapter_serial_selection": "530049000C0000513751594E"
  },
  "plan": {
    "argv": [
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "-s",
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "-c",
      "source $::env(WTK_INTERFACE)",
      "-c",
      "transport select dapdirect_swd",
      "-c",
      "adapter serial $::env(WTK_SERIAL)",
      "-c",
      "source $::env(WTK_TARGET)",
      "-c",
      "gdb_port disabled; tcl_port disabled; telnet_port disabled",
      "-c",
      "source $::env(WTK_LIBRARY)",
      "-c",
      "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
    ],
    "environment": {
      "WTK_SERIAL": "530049000C0000513751594E",
      "WTK_ACTION": "program",
      "WTK_UID": "54ff70068370525760380567",
      "WTK_LENGTH": "53968",
      "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
      "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
      "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
      "WTK_IMAGE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-001\\staged-image.bin",
      "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-001\\before.bin",
      "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-calibrated-product-001\\full-readback.bin"
    },
    "internal_flash_range": [
      134217728,
      134283264
    ],
    "program_range": [
      134217728,
      134271696
    ],
    "erase_range": [
      134217728,
      134272000
    ],
    "external_w25q_access": false,
    "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
  },
  "readback": {
    "start": 134217728,
    "end_exclusive": 134271696,
    "bytes": 53968,
    "expected_sha256": "b4ff21efaad1928731b4db07616dbc134d3087ee15e8d48694a0fcbbac758e3d",
    "actual_sha256": "b4ff21efaad1928731b4db07616dbc134d3087ee15e8d48694a0fcbbac758e3d",
    "full_flash_sha256": "f4e3ae0f1a88a5907f54a61cbe7ad77995835d1e1cb870609bdb2c1d9e5ffbd0",
    "full_flash_bytes": 65536
  },
  "unaffected_internal_pages_preserved": true,
  "next_step": "Separately boot PRODUCT; limited SAFE_BOOT UART banner cannot prove SHA/calibration/resources/readiness. Inspect UI and physical checklist.",
  "completed_utc": "2026-10-25T22:02:56.116127+00:00"
}
```
