from pathlib import Path
import sys,os,subprocess,struct,json
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
r=Path('Firmware/build/calibration-20261025');o=r/'product-idle-blocker-001';o.mkdir(exist_ok=False)
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E');p=b.plan('probe',o,None,'54ff70068370525760380567');e=dict(os.environ,**p['environment']);e['WTK_FLAGS']=str((o/'raw-safety.bin').resolve());p['argv'][-1]='if {[catch {init; halt; wtk_preflight; dump_image $::env(WTK_FLAGS) 0x200004b0 12; resume; echo "WTK_SAFE_SNAPSHOT_RESUMED"} reason]} {catch {resume}; echo $reason; shutdown error} else {shutdown}'
a=subprocess.run(p['argv'],env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'openocd.txt').write_bytes(a.stdout)
if a.returncode or b'WTK_SAFE_SNAPSHOT_RESUMED' not in a.stdout:raise ValueError('Read/resume failed')
v=(o/'raw-safety.bin').read_bytes();out=dict(source='46df1fbb',product_state=21,measure_allowed=v[0],battery_low=v[1],blocker_flags=struct.unpack_from('<I',v,4)[0],primary_blocker=v[8],operation='READ_ONLY_DIAGNOSTIC_NO_VOLTAGE_NO_MEASUREMENT');d.save(o/'report.json',out);print(json.dumps(out,indent=2))
