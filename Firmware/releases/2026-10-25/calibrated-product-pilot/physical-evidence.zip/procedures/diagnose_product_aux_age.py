from pathlib import Path
import sys,os,subprocess,struct,json
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
r=Path('Firmware/build/calibration-20261025');o=r/'product-aux-age-diagnostic-001';o.mkdir(exist_ok=False)
b=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E');p=b.plan('probe',o,None,'54ff70068370525760380567');e=dict(os.environ,**p['environment']);e['WTK_FLAGS']=str((o/'residual-snapshot.bin').resolve());e['WTK_TIME']=str((o/'time.bin').resolve());e['WTK_STAMP']=str((o/'residual-timestamp.bin').resolve());p['argv'][-1]='if {[catch {init; halt; wtk_preflight; dump_image $::env(WTK_FLAGS) 0x2000041c 40; dump_image $::env(WTK_TIME) 0x200001a4 4; dump_image $::env(WTK_STAMP) 0x20000484 4; resume; echo "WTK_SAFE_SNAPSHOT_RESUMED"} reason]} {catch {resume}; echo $reason; shutdown error} else {shutdown}'
a=subprocess.run(p['argv'],env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'openocd.txt').write_bytes(a.stdout)
if a.returncode or b'WTK_SAFE_SNAPSHOT_RESUMED' not in a.stdout:raise ValueError('Read/resume failed')
v=(o/'residual-snapshot.bin').read_bytes();now=struct.unpack('<I',(o/'time.bin').read_bytes())[0];stamp=struct.unpack('<I',(o/'residual-timestamp.bin').read_bytes())[0];out=dict(source='46df1fbb',vmid_valid=v[12],residual_state=v[32],consecutive_safe=v[33],age_ms=(now-stamp)&0xffffffff,operation='READ_ONLY_RESIDUAL_AGE_NO_BATTERY');d.save(o/'report.json',out);print(json.dumps(out,indent=2))
