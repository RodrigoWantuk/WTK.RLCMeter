"""Package and program the existing tested PC-provisioned PRODUCT image.
No acquisition START, calibration write or external-flash mutation.
"""
import json,sys,hashlib,subprocess,time
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import pc_bringup as b
import pc_cal_capture as c
from pc_osl_install import Installer,validate_candidate
root=Path(__file__).resolve().parent
builds=root/'verified-builds-install-requal'
matrix=d.load(builds/'firmware-builds.json')
ref=matrix['source']['git_sha']
if subprocess.check_output(['git','diff',ref,'HEAD','--','Firmware/src','Firmware/config','Firmware/cmake','Firmware/CMakeLists.txt','Firmware/CMakePresets.json']):raise ValueError('Embedded source changed since verified matrix')
case=next(v for v in matrix['cases'] if v['name']=='factory-release')
if case['status']!='PASS' or case['profile']!='PRODUCT' or case['factory']!='1u':raise ValueError('PC-provisioned production build required')
for n,meta in case['files'].items():
 if hashlib.sha256((builds/'factory-release'/n).read_bytes()).hexdigest()!=meta['sha256']:raise ValueError('Verified build changed')
imagepath=root/'image-calibrated-product-001'
if imagepath.exists():raise ValueError('Do not reuse an image output directory')
image=d.manifest(builds/'factory-release',imagepath,'FACTORY_PRODUCT',matrix['source'],'stm32-factory-release')
image=d.inspect(imagepath/'manifest.json','FACTORY_PRODUCT')
link=b.open_serial('COM4');events=[]
class ReadOnly:
 def write(self,data):
  kind,_,_=c.decode_frame(data)
  if kind not in (c.IDENTIFY,c.STATUS,0x59,0x5a):raise ValueError('Read-only UART preflight whitelist')
  events.append(dict(utc=d.utc(),direction='TX',hex=data.hex()))
  for byte in data:
   if link.write(bytes([byte]))!=1:raise OSError('Partial write')
   time.sleep(.001)
  return len(data)
 def read(self,n=1):
  v=link.read(n)
  if v:events.append(dict(utc=d.utc(),direction='RX',hex=v.hex()))
  return v
try:
 client=c.Client(ReadOnly(),timeout=10);identity=client.identify();state=client.status();installer=Installer(client);store=installer.status()
 if identity!=d.load(root/'boot-identify-install-requal-001/report.json')['identity']:raise ValueError('Running calibration firmware identity mismatch')
 if state['busy'] or not state['transfer_safe'] or state['safety_faults'] or state['safety_blocks']&~8 or not state['calibrated'] or state['calibration_sequence']!=1 or state.get('battery_voltage_v') is None or state['battery_voltage_v']<=3.5:raise ValueError('Fresh SAFE/charger-absent/valid-calibration/battery required')
 if not store['active_valid'] or store['active_sequence']!=1:raise ValueError('Active sequence mismatch')
 frame=installer.readback(1);validate_candidate(frame)
 expected=(root/'condition-composition-003/candidate.bin').read_bytes()
 if frame!=expected:raise ValueError('Fresh physical calibration readback mismatch')
 pre=dict(utc=d.utc(),operation='READ_ONLY_PRE_PRODUCT_PROGRAM',identity=identity,status=state,storage=store,physical_readback_sha256=hashlib.sha256(frame).hexdigest(),events=events)
 d.save(root/'product-deploy-preflight-001.json',pre)
 (root/'product-deploy-preflight-readback.bin').write_bytes(frame)
finally:link.close()
auth=dict(operator='Rodrigo; owner-directed continuation into calibrated production without another resistor campaign',utc=d.utc(),board='First Rev1 board, six RGS gate-to-GND rework',expected_uid=identity['uid'],SIMULATED=False,previous_profile='BRINGUP_CAL',next_profile='FACTORY_PRODUCT',image_sha256=image['files']['firmware.bin']['sha256'],manifest_seal=image['seal_sha256'],approval_origin='Owner requested next step after persistent calibration, firmware production status and capacitor/inductor/autorange review; earlier authorization includes firmware programming',scope='Controlled calibrated PRODUCT handoff; internal Flash only; preserve exact active OSL sequence1, W25Q assets/settings and experimental UID-bound NTC; no DUT measurement commanded',physical_qualification=False,procedural_exception=dict(owner_requested_proceed_without_scope=True,scope_checks='NOT_TESTED; no new physical qualification inferred',b01_gate='Independent scope/hardware qualification remains pending'),preflight_path=str(root/'product-deploy-preflight-001.json'),supply='Previously owner-confirmed battery/boost; fresh serial battery adequate and charger absent',preservation='No external W25Q erase/program requested',ntc_factory_profile=image['ntc_factory_profile'],osl=dict(sequence=1,sha256=hashlib.sha256(frame).hexdigest(),fresh_readback=str(root/'product-deploy-preflight-readback.bin')),acknowledgements=dict(safe_outputs=True,debug_halt_watchdog=True,no_app_bootloader=True,internal_flash=True))
auth['seal_sha256']=d.seal(auth);d.save(root/'deployment-calibrated-product-authorization.json',auth)
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
record=d.deployment('program',imagepath/'manifest.json',backend,root/'deployment-calibrated-product-001',authorization=auth,uid=identity['uid'])
print(json.dumps({k:record.get(k) for k in ('outcome','readback','error')},indent=2),flush=True)
if record['outcome']!='INTERNAL_FLASH_VERIFIED':raise SystemExit(1)
