	.cpu cortex-m3
	.arch armv7-m
	.fpu softvfp
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 6
	.eabi_attribute 34, 1
	.eabi_attribute 18, 4
	.file	"layout.c"
	.text
	.global	offsets
	.section	.rodata
	.align	2
	.type	offsets, %object
	.size	offsets, 60
offsets:
	.word	1464
	.word	1564
	.word	1598
	.word	0
	.word	64
	.word	2683
	.word	5769
	.word	8
	.word	12
	.word	21
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.ident	"GCC: (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119"
