import json,time,sys,hashlib
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_bringup as b,pc_cal_capture as c,pc_firmware_deploy as d
from pc_osl_install import Installer
r=Path(__file__).resolve().parent;o=r/'installation-status-recovery-001';o.mkdir(exist_ok=False)
l=b.open_serial('COM4');events=[]
class T:
 def write(self,data):
  events.append(dict(utc=d.utc(),direction='TX',hex=data.hex()))
  for v in data:l.write(bytes([v]));time.sleep(.001)
  return len(data)
 def read(self,n=1):
  v=l.read(n)
  if v:events.append(dict(utc=d.utc(),direction='RX',hex=v.hex()))
  return v
report=dict(operation='READ_ONLY_RESOLVE_AMBIGUOUS_INSTALL',utc=d.utc(),capture_started=False,calibration_written=False)
try:
 client=c.Client(T(),timeout=10);report['identity']=client.identify()
 if report['identity']!=d.load(r/'boot-identify-install-requal-001/report.json')['identity']:raise ValueError('Unexpected identity')
 report['status']=client.status();inst=Installer(client);report['storage']=inst.status()
 if report['storage']['active_valid']:
  v=inst.readback(report['storage']['active_sequence']);(o/'physical-readback.bin').write_bytes(v)
  report['readback_sha256']=hashlib.sha256(v).hexdigest();report['exact_candidate_match']=v==(r/'condition-composition-003/candidate.bin').read_bytes()
 print(json.dumps(report,indent=2),flush=True)
finally:
 l.close();d.save(o/'report.json',report);d.save(o/'wire-events.json',events)
