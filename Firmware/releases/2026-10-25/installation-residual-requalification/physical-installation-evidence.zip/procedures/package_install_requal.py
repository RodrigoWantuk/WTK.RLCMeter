import hashlib
import json
from pathlib import Path
import sys
import zipfile

repo = Path.cwd()
sys.path.insert(0, str(repo / 'Firmware/tools'))
import pc_firmware_deploy as deploy

root = Path(__file__).resolve().parent
builds = root / 'verified-builds-install-requal'
report = deploy.load(builds / 'firmware-builds.json')
if any(case['status'] != 'PASS' for case in report['cases']):
    raise ValueError('All nine builds must pass')
if deploy.source_state() != report['source']:
    raise ValueError('Source changed before packaging')
image = root / 'image-install-requal-001'
manifest = deploy.manifest(builds / 'bringup-cal', image, 'BRINGUP_CAL',
                           report['source'], 'stm32-bringup-cal')
release = repo / 'Firmware/releases/2026-10-25/installation-residual-requalification'
release.mkdir(exist_ok=False)
(release / 'firmware-builds.json').write_text(json.dumps(report, indent=2) + '\n')
with zipfile.ZipFile(release / 'bringup-cal.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in image.iterdir():
        if path.is_file(): archive.write(path, path.name)
    for name in ('WTK.RLCMeter.hex', 'WTK.RLCMeter.map', 'WTK.RLCMeter.size.json'):
        archive.write(builds / 'bringup-cal' / name, name)
    archive.write(builds / 'bringup-cal/generated/wtk_ntc_factory_profile.json',
                  'wtk_ntc_factory_profile.json')
    for name in ('install-requal-host-build.log', 'install-requal-host-tests.log'):
        archive.write(root / name, 'checks/' + name)
    for path in builds.glob('*.log'):
        archive.write(path, 'checks/' + path.name)
summary = dict(source=report['source']['git_sha'],
    deployment_status='PREPARED_REQUIRES_PHYSICAL_PILOT',
    uart_battery_validation='REQUIRES_BENCH_VALIDATION_AFTER_PROGRAMMING',
    previous_running_source='ba948235',
    intended_uid=manifest['ntc_factory_profile']['uid'],
    firmware_sha256=manifest['files']['firmware.bin']['sha256'],
    binary_size=manifest['binary_size'], linked=manifest['linked'],
    host_tests='46/46 PASS', embedded_profiles='9/9 PASS_STRICT_WARNINGS_AND_MEMORY',
    package_sha256=hashlib.sha256((release / 'bringup-cal.zip').read_bytes()).hexdigest(),
    external_flash_written=False, osl_installed=False)
deploy.save(release / 'checkpoint.json', summary)
print(json.dumps(summary, indent=2))


