"""Install only the fully checked first-unit composition; no measurement START."""
import hashlib
import json
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_bringup as bringup
import pc_cal_capture as capture
import pc_firmware_deploy as deploy
from pc_osl_install import Installer,validate_candidate

root=Path(__file__).resolve().parent
source=root/'condition-composition-003'
composition=deploy.load(source/'composition.json')
frame=(source/'candidate.bin').read_bytes()
validate_candidate(frame)
if (composition['status']!='ALL_33_COMPLETE_CONDITIONS_C_AND_PYTHON_VALIDATED' or
    composition['candidate_sha256']!=hashlib.sha256(frame).hexdigest() or
    composition['reused_conditions']!=18 or composition['current_conditions']!=15):
    raise ValueError('Validated complete condition composition required')
expected=deploy.load(root/'boot-identify-install-requal-001/report.json')['identity']
out=root/'condition-installation-005';out.mkdir(exist_ok=False)
events=[]
report=dict(started_utc=deploy.utc(),operation='OWNER_DIRECTED_ENGINEERING_OSL_INSTALLATION',
    candidate_sha256=composition['candidate_sha256'],composition_sha256=hashlib.sha256((source/'composition.json').read_bytes()).hexdigest(),
    approval_origin='Owner requested completing calibration and provided the final two fresh reference fixtures after the explicitly documented reuse audit',
    physically_qualified=False,capture_started=False,error=None)
link=bringup.open_serial('COM4')
class Paced:
    def write(self,data):
        kind,_,_=capture.decode_frame(data)
        if kind not in (capture.IDENTIFY,capture.STATUS,*range(0x55,0x5c)):
            raise ValueError('Installation/read-only whitelist; no measurement command')
        events.append(dict(utc=deploy.utc(),direction='TX',hex=data.hex()))
        for byte in data:
            if link.write(bytes([byte]))!=1: raise OSError('Partial write; no automatic replay')
            time.sleep(0.001)
        return len(data)
    def read(self,count=1):
        data=link.read(count)
        if data: events.append(dict(utc=deploy.utc(),direction='RX',hex=data.hex()))
        return data
try:
    client=capture.Client(Paced(),timeout=10)
    identity=client.identify()
    if identity!=expected or identity['uid']!=composition['intended_uid']: raise ValueError('Running unit/image mismatch')
    state=client.status();report['before_status']=state
    if (state['busy'] or not state['transfer_safe'] or state['safety_faults'] or state['safety_blocks'] & ~8 or
        state.get('battery_voltage_v') is None or state['battery_voltage_v']<=3.5 or
        state['calibrated'] or state['calibration_sequence']!=0):
        raise ValueError('Fresh safe, charger-absent, adequate battery and blank active calibration required')
    installer=Installer(client)
    before=installer.status();report['before_storage_status']=before
    if before['active_valid'] or before['next_sequence']!=composition['sequence']:
        raise ValueError('Unexpected active/successor calibration; do not overwrite or replay')
    installed=installer.install(frame,out/'installation.json',out/'physical-readback.bin')
    report['installation']=installed
    after=client.status();report['after_status']=after
    if (not after['calibrated'] or after['calibration_sequence']!=composition['sequence'] or
        after['busy'] or not after['transfer_safe'] or after['safety_faults'] or
        after['protocol_errors']!=state['protocol_errors']):
        raise ValueError('Post-install active/SAFE state not confirmed')
    report['outcome']='ACTIVE_ENGINEERING_OSL_INSTALLED_PHYSICAL_FLASH_READBACK_EXACT'
except BaseException as exc:
    report.update(outcome='INCOMPLETE_DO_NOT_REPLAY_COMMIT',error=type(exc).__name__+': '+str(exc))
    raise
finally:
    link.close();report['completed_utc']=deploy.utc()
    deploy.save(out/'report.json',report);deploy.save(out/'wire-events.json',events)
    print(json.dumps({key:report.get(key) for key in ('outcome','error','after_status')},indent=2),flush=True)

