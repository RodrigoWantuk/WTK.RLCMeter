"""Owner-directed installer sensor refresh scheduling fix, preserving external Flash."""
import json
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_cal_capture as c
import pc_firmware_deploy as d

root = Path(__file__).resolve().parent
image_path = root / 'image-install-requal-001/manifest.json'
image = d.inspect(image_path, 'BRINGUP_CAL')
link = b.open_serial('COM4')
events = []
class ReadOnly:
    def write(self, data):
        kind, _, _ = c.decode_frame(data)
        if kind not in (c.IDENTIFY, c.STATUS): raise ValueError('Read-only preflight')
        events.append(dict(direction='TX', hex=data.hex()))
        for byte in data:
            if link.write(bytes([byte])) != 1: raise OSError('Partial write')
            time.sleep(0.001)
        return len(data)
    def read(self, count=1):
        data = link.read(count)
        if data: events.append(dict(direction='RX', hex=data.hex()))
        return data
try:
    client = c.Client(ReadOnly(), timeout=5)
    identity = client.identify()
    state = client.status()
    if (identity['uid'] != '54ff70068370525760380567' or
        identity['git'] != 'ba948235' or identity['synthetic'] or
        identity['profile'] != 1 or identity['hardware_revision'] != 65538):
        raise ValueError('Unexpected currently running firmware')
    if state['busy'] or not state['transfer_safe'] or state['safety_faults'] or state['safety_blocks'] & ~8 or state.get('battery_voltage_v') is None or state['battery_voltage_v'] <= 3.5:
        raise ValueError('Fresh SAFE idle and charger absent required')
    preflight = dict(utc=d.utc(), identity=identity, status=state, events=events,
                     voltage_read=False, operation='READ_ONLY_UART_PREDEPLOY')
    d.save(root / 'install-requal-predeploy-001.json', preflight)
finally:
    link.close()

auth = dict(operator='Rodrigo; owner-directed engineering calibration continuation', utc=d.utc(),
    board='First Rev1 assembled board, six RGS reworked gate-to-GND',
    expected_uid=identity['uid'], SIMULATED=False,
    previous_profile='BRINGUP_CAL', next_profile='BRINGUP_CAL',
    image_sha256=image['files']['firmware.bin']['sha256'], manifest_seal=image['seal_sha256'],
    approval_origin='Owner requested completing calibration and supplied final references; all33 fits are validated; first installation failed and is preserved',
    scope='Internal-Flash installer-only complete residual requalification scheduling; acquisition/DSP/model/candidate unchanged; preserve UID-bound NTC, all captures and external W25Q',
    physical_qualification=False,
    procedural_exception=dict(owner_requested_proceed_without_scope=True,
        scope_checks='NOT_TESTED; Hantek unavailable', b01_gate='Not approved; no physical qualification inferred'),
    preflight_path=str(root / 'install-requal-predeploy-001.json'),
    supply='Owner-confirmed battery/boost powered, charger disconnected; fresh nominal battery over UART and SAFE idle required',
    preservation='Internal Flash only; no external W25Q erase/program',
    ntc_factory_profile=image['ntc_factory_profile'],
    acknowledgements=dict(safe_outputs=True, debug_halt_watchdog=True,
                          no_app_bootloader=True, internal_flash=True))
auth['seal_sha256'] = d.seal(auth)
d.save(root / 'deployment-install-requal-authorization.json', auth)
backend = d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
                   'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts',
                   '530049000C0000513751594E')
record = d.deployment('program', image_path, backend,
    root / 'deployment-install-requal-001', authorization=auth, uid=identity['uid'])
print(json.dumps({key: record.get(key) for key in ('outcome', 'readback', 'error')}, indent=2))
if record['outcome'] != 'INTERNAL_FLASH_VERIFIED': raise SystemExit(1)


