"""Archive verified 10-kohm LOAD evidence; never opens a device."""
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl

root=Path(__file__).resolve().parent
report=d.load(root/'load-10000-001/report.json')
if report['outcome'] != 'ALL_6_LOAD_CAPTURES_ACCEPTED':
    raise ValueError('Complete six-key LOAD group required')
identity=report['identity']
previous=d.load(root/'same-image-through-load-1000.json')
current=d.load(root/'load-10000-001/captures.json')
for document in (previous,current): c.verify_campaign(document,identity)
keys={k for k in pc_osl.KEYS if k.rref_ohms==10000}
if len(current['captures']) != 6 or {pc_osl.Key.from_json(r['condition']) for r in current['captures']} != keys:
    raise ValueError('Exactly six distinct 10-kohm keys required')
if any(r['standard'] != 'LOAD' or r.get('reference') != report['reference'] for r in current['captures']):
    raise ValueError('Wrong standard/reference binding')
merged=root/'same-image-through-load-10000.json'
if merged.exists(): raise ValueError('Refusing to overwrite checkpoint')
for row in previous['captures']+current['captures']: document=c.save_capture(merged,row)
if len(document['captures']) != 87: raise ValueError('87 original observations required')
fits=[]
for key in pc_osl.KEYS:
    group=[pc_osl.standard_from_capture(r) for r in document['captures'] if r['condition']==key.as_json()]
    if len(group)==3:
        s=pc_osl.solve(group)
        fits.append(dict(condition=key.as_json(),fit_channel=s.fit_channel,hg_observed=s.hg_observed,
                         min_separation=s.min_separation,serialized_float32_values=s.values()))
if len(fits)!=21: raise ValueError('Exactly twenty-one complete fit checks required')
next_battery=d.load(root/'battery-before-load-100000-001/report.json')
release=Path('Firmware/releases/2026-10-25/osl-load-10000-checkpoint')
release.mkdir(exist_ok=False)
archive=release/'physical-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ('load-10000-001','battery-before-load-10000-002','battery-before-load-100000-001'):
        for p in sorted((root/folder).rglob('*')):
            if p.is_file(): z.write(p,str(p.relative_to(root)).replace('\\','/'))
    for name in ('capture_load_10000.py','read_battery_before_load_10000_fresh.py',
                 'read_battery_before_load_100000.py','archive_load_10000_checkpoint.py',
                 'same-image-through-load-10000.json'):
        z.write(root/name,name)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or len(z.namelist())!=len(set(z.namelist())):
        raise ValueError('Archive verification failed')
checkpoint=dict(recorded_utc=d.utc(),SIMULATED=False,status='LOAD_10000_COMPLETE_TWO_REFERENCE_GROUPS_PENDING',
    identity=identity,observations=87,required_observations=99,complete_conditions=21,
    reference=report['reference'],fresh_owner_dmm_ohms=9990.0,
    owner_confirmation='9.99k, conectado',reference_policy=report['reference_policy'],
    reference_identification=report['reference_identification'],accepted_conditions=report['accepted'],fits=fits,
    battery_before_10000=report['battery_check'],battery_before_100000=next_battery,
    battery_policy='Fresh SAFE/idle check before every new resistor; request charging at LOW (<=3.50V nominal); no capture during charging',
    protocol_errors_baseline=report['protocol_errors_baseline'],final_status=report['last_safe_status'],
    installation_status=report['final_installation_status'],candidate_generated=False,
    calibration_installed=False,physically_qualified=False,
    capture_sha256=d.sha(merged.read_bytes()),artifact=dict(bytes=archive.stat().st_size,sha256=d.sha(archive.read_bytes())))
d.save('docs/review/bringup-2026-10-25/OSL-Load-10000.json',checkpoint)
before=report['battery_check']['values']['battery_v']
after=next_battery['values']['battery_v']
fit_by_key={pc_osl.Key.from_json(s['condition']):s for s in fits}
table=['| Hz | mVrms | Usable paths | Clipping mask | Fit |','| ---: | ---: | --- | ---: | --- |']
for row in report['accepted']:
    key=pc_osl.Key.from_json(row['condition'])
    q=row['quality']
    table.append(f"| {key.frequency_hz} | {key.amplitude_mvrms} | {', '.join(q['usable_paths'])} | {q['clipping_mask']} | {fit_by_key[key]['fit_channel']} |")
quality_table='\n'.join(table)
Path('docs/review/bringup-2026-10-25/OSL-Load-10000.md').write_text(f'''# 10-kohm LOAD checkpoint — October 25, 2026

Status: LOAD_10000_COMPLETE; TWO_REFERENCE_GROUPS_PENDING; NOT_QUALIFIED.

The owner repeated 9.99 kohm on the requested Minipa ET-1100A 20-kohm range
and confirmed direct attachment alone across TEST_HI/TEST_LO. The owner-reported
brown/black/black/red/brown bands identify nominal 10 kohm +/-1%, retained as an
uncertain fit anchor. DMM digits are consistency evidence, without a certified
actual value, fixed lead subtraction or invented uncertainty interval.

All six 10-kohm LOAD conditions passed six stable repeats, SAFE teardown and
strict same-image OSL/float32 fit checks. Accepted and rejected paths remain
explicit; no clipped channel was promoted to usable:

{quality_table}

The cumulative 87/99 original observations contain 21/33 complete triplets,
all rechecked by the strict solver. This verifies fit consistency, not independent
accuracy. Exact source-7017e5e0 identity and nominal ADC provenance match.

Battery before this group: {before:.5f} V; before requesting the next 100-kohm
reference: {after:.5f} V, both OK. Fresh SAFE/idle readings use nominal ADC scale
and do not establish charge percentage or runtime. Protocol counter stayed at
{report['protocol_errors_baseline']}; no new errors or faults occurred. Calibration
storage remains blank. No complete candidate was generated or installed.
Two LOAD groups, independent holdouts and scope-dependent qualification remain
pending. Final test leads require calibration in their final geometry.

See [structured checkpoint](OSL-Load-10000.json),
[physical evidence](../../../Firmware/releases/2026-10-25/osl-load-10000-checkpoint/README.md)
and [previous checkpoint](OSL-Load-1000.md).
''',encoding='utf-8')
(release/'README.md').write_text('''# 10-kohm LOAD evidence

The ZIP preserves six LOAD artifacts, fit checks, wire logs, battery snapshots
and the cumulative 87-observation canonical document. CCO1 CRC/SHA, identity
and archive CRC/uniqueness checks passed. Two LOAD groups, independent validation
and installation remain pending.

See [bench report](../../../../docs/review/bringup-2026-10-25/OSL-Load-10000.md).
''',encoding='utf-8')
print(json.dumps(dict(status=checkpoint['status'],observations=87,complete_conditions=21,artifact=checkpoint['artifact']),indent=2))
