"""Bounded diagnostic: six independent LOAD artifacts, no candidate or writes."""
import struct
import json
import math
from pathlib import Path
import statistics
import sys
import time

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl

root = Path(__file__).resolve().parent
out = root / 'load-integration-pilot-002'
out.mkdir(exist_ok=False)
expected = d.load(root / 'boot-identify-battery-telemetry-001/report.json')['identity']
key = pc_osl.Key(1000000, 10000, 500)
events = []
report = dict(started_utc=d.utc(), operation='SIX_INDEPENDENT_LOAD_CCO1_MEANS_DIAGNOSTIC',
    fixture='Owner freshly measured 996 kohm; approximately 1-Mohm resistor alone directly attached; nominal 1 Mohm +/-1% remains the uncertain reference',
    condition=key.as_json(), identity=expected, observations=[], statuses=[], error=None,
    calibration_installed=False, original_campaign_modified=False, physically_qualified=False,
    estimator_scope='Exploratory repeatability across six exported six-block phasor means; not an integrated firmware observation or replacement for existing validity flags')
link = b.open_serial('COM4')
class Paced:
    def write(self, data):
        kind, _, payload = c.decode_frame(data)
        if kind not in (c.IDENTIFY,c.STATUS,c.START,c.RESULT,c.CANCEL):
            raise ValueError('Capture-only whitelist')
        if kind == c.START and (payload[8:] != struct.pack('<4B2f', *key.ids(), 2, 1000000.0, 0.0)):
            raise ValueError('Only fixed-key LOAD permitted')
        events.append(dict(utc=d.utc(), direction='TX', hex=data.hex()))
        for byte in data:
            if link.write(bytes([byte])) != 1: raise OSError('Partial write')
            time.sleep(0.001)
        return len(data)
    def read(self, count=1):
        data = link.read(count)
        if data: events.append(dict(utc=d.utc(), direction='RX', hex=data.hex()))
        return data
def safe(state):
    if (state['busy'] or not state['transfer_safe'] or state['safety_faults'] or
        state['safety_blocks'] & ~8 or state['calibrated'] or
        state.get('battery_voltage_v') is None or state['battery_voltage_v'] <= 3.5):
        raise ValueError('Fresh SAFE/idle/charger-absent/adequate battery required: '+str(state))
def persist():
    d.save(out / 'report.json', report)
    d.save(out / 'wire-events.json', events)
try:
    client = c.Client(Paced())
    if client.identify() != expected: raise ValueError('Firmware changed')
    initial = client.status(); safe(initial)
    report['initial_status'] = initial
    persist()
    for index in range(1,7):
        state = client.status(); safe(state)
        if state['protocol_errors'] != initial['protocol_errors']: raise ValueError('Protocol error')
        print(f'LOAD diagnostic {index}/6, battery={state["battery_voltage_v"]:.3f}V', flush=True)
        row = client.capture(key, 'LOAD', dict(id='R1M_1PCT_OWNER996K_20261025', impedance_ohms=[1000000,0], tolerance_pct=1.0))
        (out / f'{index:02d}.cco1').write_bytes(bytes.fromhex(row['artifact_hex']))
        d.save(out / f'{index:02d}.json', row)
        report['observations'].append(dict(file=f'{index:02d}.json', sha256=row['sha256'], quality=row['quality']))
        state = client.status(); safe(state)
        if state['protocol_errors'] != initial['protocol_errors']: raise ValueError('Protocol error')
        report['statuses'].append(state)
        persist()
    gains = []
    ratios = []
    for index in range(1,7):
        row = d.load(out / f'{index:02d}.json')
        p = {name:complex(*value) for name,value in row['phasors'].items()}
        mid = (p['vmid_adc1']+p['vmid_adc2'])/2
        t1 = (p['ret_1x']-mid)/(p['vexc_1']-mid)
        th = (p['ret_hg']-mid)/(p['vexc_2']-mid)
        ratios.append(t1)
        gains.append(th/t1)
    def stats(values):
        mean = sum(values)/len(values)
        std = math.sqrt(sum(abs(v-mean)**2 for v in values)/(len(values)-1))
        return dict(mean=[mean.real,mean.imag], complex_std=std,
                    relative_std_pct=100*std/abs(mean))
    report['diagnostic_statistics'] = dict(normalized_1x_transfer=stats(ratios),
                                          effective_hg_transfer=stats(gains))
    report['outcome'] = 'SIX_DIAGNOSTIC_ARTIFACTS_SAVED_NO_VALIDITY_PROMOTION'
except BaseException as exc:
    report.update(outcome='STOPPED_NO_RETRY', error=type(exc).__name__+': '+str(exc))
    raise
finally:
    link.close()
    report['completed_utc'] = d.utc()
    persist()
    print(json.dumps({k:report.get(k) for k in ('outcome','error','diagnostic_statistics')},indent=2),flush=True)


