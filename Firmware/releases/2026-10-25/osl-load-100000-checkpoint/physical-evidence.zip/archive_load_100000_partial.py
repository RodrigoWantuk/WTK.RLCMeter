"""Preserve all six captures and the unresolved fit; no device operations."""
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl as o
import pc_osl_campaign as g

root=Path(__file__).resolve().parent
first=d.load(root/'load-100000-001/report.json')
last=d.load(root/'load-100000-002/report.json')
if first['outcome']!='STOPPED_NO_AUTOMATIC_RETRY' or not first['safe_after_stop'] or last['outcome']!='FINAL_UNATTEMPTED_LOAD_CAPTURE_ACCEPTED':
    raise ValueError('Expected preserved solver rejection and safe final continuation')
identity=first['identity']
if last['identity']!=identity: raise ValueError('Identity changed')
previous=d.load(root/'same-image-through-load-10000.json')
groups=[d.load(root/folder/'captures.json') for folder in ('load-100000-001','load-100000-002')]
for doc in [previous]+groups: c.verify_campaign(doc,identity)
current=[r for doc in groups for r in doc['captures']]
if len(current)!=6 or {o.Key.from_json(r['condition']) for r in current}!={k for k in o.KEYS if k.rref_ohms==100000}:
    raise ValueError('Exactly six distinct 100-kohm raw captures required')
merged=root/'same-image-through-load-100000.json'
if merged.exists(): raise ValueError('Refusing to overwrite evidence')
for row in previous['captures']+current: document=c.save_capture(merged,row)
if len(document['captures'])!=93: raise ValueError('93 original observations required')
fits=[]
blocked=[]
for key in o.KEYS:
    group=[o.standard_from_capture(r) for r in document['captures'] if r['condition']==key.as_json()]
    if len(group)!=3: continue
    try:
        s=o.solve(group)
        fits.append(dict(condition=key.as_json(),fit_channel=s.fit_channel,hg_observed=s.hg_observed,
                         min_separation=s.min_separation,serialized_float32_values=s.values()))
    except ValueError as exc:
        blocked.append(dict(condition=key.as_json(),error=str(exc),standards=[
            dict(standard=s.standard,ret_1x_valid=s.ret_1x_valid,ret_hg_valid=s.ret_hg_valid,hg_observed=s.hg_observed)
            for s in group]))
if len(fits)!=26 or len(blocked)!=1 or blocked[0]['condition']!=o.Key(100000,10000,100).as_json():
    raise ValueError('Unexpected fit coverage; investigate instead of publishing success')
battery=d.load(root/'battery-before-load-1000000-001/report.json')
release=Path('Firmware/releases/2026-10-25/osl-load-100000-checkpoint')
release.mkdir(exist_ok=False)
archive=release/'physical-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ('load-100000-001','load-100000-002','battery-before-load-100000-002','battery-before-load-1000000-001'):
        for p in sorted((root/folder).rglob('*')):
            if p.is_file(): z.write(p,str(p.relative_to(root)).replace('\\','/'))
    for name in ('capture_load_100000.py','capture_load_100000_last.py',
                 'read_battery_before_load_100000_fresh.py','read_battery_before_load_1000000.py',
                 'archive_load_100000_partial.py','same-image-through-load-100000.json'):
        z.write(root/name,name)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or len(z.namelist())!=len(set(z.namelist())): raise ValueError('Archive verification failed')
checkpoint=dict(recorded_utc=d.utc(),SIMULATED=False,status='ALL_100K_CAPTURES_SAVED_ONE_FIT_BLOCKED_1M_LOAD_PENDING',
    identity=identity,observations=93,required_observations=99,solvable_conditions=26,
    complete_triplets=27,blocked=blocked,fits=fits,reference=first['reference'],
    owner_confirmation='99.8K, conectado',fresh_owner_dmm_ohms=99800.0,
    reference_policy=first['reference_policy'],qualities=[dict(condition=r['condition'],quality=g.quality(r)) for r in current],
    battery_before_100000=first['battery_check'],battery_before_1000000=battery,
    protocol_errors_baseline=first['protocol_errors_baseline'],final_status=last['last_safe_status'],
    installation_status=last['final_installation_status'],candidate_generated=False,calibration_installed=False,
    physically_qualified=False,artifact=dict(bytes=archive.stat().st_size,sha256=d.sha(archive.read_bytes())),
    capture_sha256=d.sha(merged.read_bytes()))
d.save('docs/review/bringup-2026-10-25/OSL-Load-100000.json',checkpoint)
Path('docs/review/bringup-2026-10-25/OSL-Load-100000.md').write_text('''# 100-kohm LOAD capture and unresolved fit — October 25, 2026

Status: SIX_CAPTURES_SAVED; FIVE_FITS_ACCEPTED; ONE_FIT_BLOCKED; NOT_QUALIFIED.

The owner reported 99.8 kohm on the requested Minipa ET-1100A 200-kohm range
and confirmed attachment alone. Nominal 100 kohm +/-1% remains the uncertain
fit anchor, with DMM digits retained as consistency evidence.

All six LOAD observations are preserved with six stable repeats, matching
source-7017e5e0 identity, nominal ADC provenance, CRC/SHA and SAFE teardown.
Five triplets passed strict OSL/float32 fit checks. The sixth, 100 kohm / 10 kHz /
100 mVrms, is blocked: OPEN and LOAD have only HG valid, SHORT has both paths,
and none has actual observed HG overlap. The strict Python and C solvers require
observed gain to select HG. A finite ratio inferred from invalid 1X data is not
a substitute; no flag, threshold, gain or solver rule was changed.

The first sweep stopped after saving the fifth raw frame and the solver rejection.
The previously unattempted 10-kHz/500-mVrms condition was then captured separately
under the unchanged owner-confirmed fixture and passed using HG with actual
same-key overlap. The rejected condition was not retried. Both reports and wire
logs remain intact. Protocol counter stayed at 1; safety fault mask stayed zero.

There are 93/99 original captures, 27 complete triplets, 26 solvable fits and one
blocked fit. Six 1-Mohm LOAD observations remain absent. These numbers do not
constitute a full usable candidate or an independent accuracy claim.

Fresh battery before this group was 3.70696 V; before requesting the 1-Mohm
reference it was 3.70374 V, both OK. Snapshots were taken only SAFE/idle without
reset. The owner requires a fresh battery check at every new resistor value.
Calibration storage remains blank. No candidate was generated or installed.
Independent holdouts, scope-dependent qualification and the blocked key remain
pending; do not mark the missing calibration condition qualified or complete.

See [structured path/fit audit](OSL-Load-100000.json),
[physical evidence](../../../Firmware/releases/2026-10-25/osl-load-100000-checkpoint/README.md)
and [previous checkpoint](OSL-Load-10000.md).
''',encoding='utf-8')
(release/'README.md').write_text('''# 100-kohm capture evidence — one fit blocked

The ZIP preserves six LOAD artifacts, the original solver rejection, the separate
final-condition continuation, wire logs, battery snapshots and the cumulative
93-observation canonical document. Identity, CCO1 CRC/SHA and archive checks pass.
Five new fits are accepted; 100-kohm/10-kHz/100-mVrms lacks observed HG overlap
and remains blocked. No full candidate, installation or qualification is implied.

See [bench report](../../../../docs/review/bringup-2026-10-25/OSL-Load-100000.md).
''',encoding='utf-8')
print(json.dumps(dict(status=checkpoint['status'],observations=93,solvable=26,blocked=blocked,artifact=checkpoint['artifact']),indent=2))
