from pathlib import Path
import json, hashlib, zipfile, math
r=Path('Firmware/build/calibration-20261025')
o=Path('Firmware/releases/2026-10-25/inductor-047-limit-check')
o.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
report=load(r/'inductor-047-diagnostic-001/report.json');v=report['values']
post=load(r/'inductor-047-postflight-001/report.json');m=post['metadata']
assert v['session_sequence']==5 and v['runtime.measurement.policy.attempt_count']==1
assert v['ui.interpretation']==0 and not v['ui.inductance_valid'] and not v['ui.capacitance_valid']
assert m['k1_commanded_state']==1 and m['safety_fault_mask']==0 and m['range_enabled']==0 and m['excitation_mode']==0 and m['quiet_requested']==0
assert m['calibration_sequence']==1 and m['calibration_record_count']==33 and m['calibration_active_valid']==1
with zipfile.ZipFile(o/'physical-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ('inductor-047-preflight-001','inductor-047-diagnostic-001','inductor-047-postflight-001'):
  for p in (r/folder).rglob('*'):
   if p.is_file():z.write(p,str(p.relative_to(r)))
 for name in ('check_inductor_047_preflight.py','read_inductor_047.py','check_inductor_047_postflight.py','package_inductor_047.py'):
  z.write(r/name,'procedures/'+name)
checkpoint=dict(status='NOMINAL_047UH_NOT_RESOLVED_BY_CURRENT_AUTO_MODE',unit='54ff70068370525760380567',firmware_source='3052bdde0b69c7d957cb70f4d150ec58843789f3',firmware_sha256=post['firmware_sha256'],fixture='Owner-confirmed isolated nominal 0.47uH inductor; independent impedance/tolerance unknown',session=5,attempt_count=1,classification='RESISTIVE',resistance_ohms=v['ui.resistance_ohms'],reactance_ohms=v['ui.reactance_ohms'],frequency_hz=1000,reference_ohms=10,return_channel='HG',published_inductance_valid=False,published_capacitance_valid=False,frequency_refinement_count=0,post_metadata=m,firmware_written=False,calibration_written=False,battery_voltage_read_via_swd=False,hardware_limit_established=False,qualification='REQUIRES_BENCH_VALIDATION',evidence_sha256=hashlib.sha256((o/'physical-evidence.zip').read_bytes()).hexdigest())
(o/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
(o/'README.md').write_text('''# Nominal 0.47-uH sensitivity check

After two successful nominal 470-uH checks, the owner substituted an isolated
nominal 0.47-uH inductor and triggered one short-OK PRODUCT measurement. SAFE
preflight, exact running-image verification and compiler-derived context layout
were preserved without reset or firmware/calibration writes.

Session 5 completed with one attempt at 1 kHz, RREF 10 ohm, HG return:

- R = 0.235328 ohm; X = -0.0100988 ohm.
- Classification: RESISTIVE. Published L and C are both invalid.
- No frequency refinement, clipping, safety abort or DSP error occurred.
- Active calibration remains sequence 1, all 33 records.

The completed measurement does not resolve the nominal inductance. In the
current engine, resistive classification skips the second-frequency refinement
(`measurement_engine.c`, `decide_next` policy). The observed result therefore
also exposes an automatic-search limitation: this session never tried 10 kHz.
This does not establish the hardware's minimum measurable inductance.

For scale only, ideal 0.47 uH has reactance 0.00295 ohm at 1 kHz and 0.0295 ohm
at 10 kHz, calculated from X = 2*pi*f*L. These are theoretical values, not
measured DUT results. Actual reactance was small and negative; assigning a
positive inductance to it or treating the internal candidate C field as a valid
capacitor reading would be unsupported. Published C remains correctly invalid.
Resolving this region needs frequency-dependent phase/fixture evidence and a
reviewed search policy. Lowering thresholds alone is not qualification.

Final metadata confirms K1 commanded SAFE, range/excitation OFF, quiet released,
zero safety faults and unchanged active calibration. No resistor campaign was
repeated and no battery voltage was read via SWD. No firmware code changed;
relevant checks are physical measurement, image/ABI match and SAFE teardown.
Software tests were not rerun. See physical-evidence.zip for raw context,
Flash-image verification, transcripts and read-only procedures.

Status: REQUIRES_BENCH_VALIDATION for sub-microhenry capability, independent
accuracy, phase and parasitic compensation. The successful 470-uH functional
checks remain valid as previously documented and are not extended to 0.47 uH.
''',encoding='utf-8')
p=Path('plans/22-Reactive-Result-Publication.md')
s=p.read_text(encoding='utf-8')+'''
## Nominal 0.47-uH automatic-mode limit observation

The owner then fitted a nominal 0.47-uH inductor and triggered session 5.
One 1-kHz / 10-ohm / HG attempt produced R=0.235328 ohm, X=-0.0100988 ohm,
RESISTIVE classification and no published L or C. The current policy skips
frequency refinement for resistive results, so 10 kHz was not tested. This
observes a current automatic-search limitation, not a proven hardware lower
limit. Do not relabel the negative reactance as a successful inductance result.
Actual SAFE teardown, zero faults and the same 33-record calibration were
verified; no code/calibration was changed. Sub-microhenry sensitivity, phase
and fixture compensation remain REQUIRES_BENCH_VALIDATION. See
[physical evidence](../Firmware/releases/2026-10-25/inductor-047-limit-check/README.md).
'''
p.write_text(s,encoding='utf-8')
for filename,link in [('README.md','Firmware/releases/2026-10-25/inductor-047-limit-check/README.md'),('docs/README.md','../Firmware/releases/2026-10-25/inductor-047-limit-check/README.md')]:
 p=Path(filename);s=p.read_text(encoding='utf-8');s+='\nThe [nominal 0.47-uH follow-up]('+link+') was resistance-like at 1 kHz\nand did not publish L. Automatic frequency search and sub-microhenry\ncapability remain unvalidated; this is not a proven hardware lower limit.\n';p.write_text(s,encoding='utf-8')
print(json.dumps(checkpoint,indent=2))
