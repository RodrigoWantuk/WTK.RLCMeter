"""Validate and archive completed physical endpoint captures, without device I/O."""
import json
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl

root = Path(__file__).resolve().parent
reports = {s: d.load(root / folder / 'report.json') for s,folder in (('OPEN','open-008'),('SHORT','short-002'))}
documents = {s: d.load(root / folder / 'captures.json') for s,folder in (('OPEN','open-008'),('SHORT','short-002'))}
identity = reports['OPEN']['identity']
if identity != reports['SHORT']['identity'] or identity['git'] != '7017e5e0':
    raise ValueError('Exact matching deployed identity required')
rows = {}
for standard, document in documents.items():
    report = reports[standard]
    if report['outcome'] != f'ALL_33_{standard}_CAPTURES_ACCEPTED':
        raise ValueError('Complete accepted endpoint sweep required')
    c.verify_campaign(document, identity)
    by_key = {pc_osl.Key.from_json(r['condition']):r for r in document['captures']}
    if len(document['captures']) != 33 or set(by_key) != set(pc_osl.KEYS):
        raise ValueError('Exactly 33 distinct keys required per standard')
    if any(r['standard'] != standard or r['physically_qualified'] for r in by_key.values()):
        raise ValueError('Unqualified endpoint-only evidence required')
    if report['last_safe_status']['protocol_errors'] != report['protocol_errors_baseline']:
        raise ValueError('Protocol error count changed')
    rows[standard] = by_key
audit = []
for key in pc_osl.KEYS:
    oq,sq = (rows[s][key]['quality'] for s in ('OPEN','SHORT'))
    common = [name for name,flag in (('1X','ret_1x_valid'),('HG','ret_hg_valid')) if oq[flag] and sq[flag]]
    audit.append(dict(condition=key.as_json(), open_quality=oq, short_quality=sq,
        common_paths=common, hg_overlap_observed=oq['hg_observed'] or sq['hg_observed']))
missing = [r['condition'] for r in audit if not r['common_paths']]
path_audit = dict(recorded_utc=d.utc(), identity=identity, captures=66,
    installed=False, physically_qualified=False, empty_path_intersections=missing,
    rows=audit, warning='HG-only triplets still require real same-key HG overlap from OPEN, SHORT or LOAD; LOAD remains pending')
d.save(root / 'same-image-open-short-path-audit.json',path_audit)
combined = root / 'same-image-endpoints.json'
if combined.exists():
    raise ValueError('Refusing to overwrite merged endpoint evidence')
for standard in ('OPEN','SHORT'):
    for key in pc_osl.KEYS:
        c.save_capture(combined, rows[standard][key])
c.verify_campaign(d.load(combined),identity)
release = Path('Firmware/releases/2026-10-25/same-image-osl-endpoints')
release.mkdir(exist_ok=False)
archive_path = release / 'physical-evidence.zip'
with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ('open-008','short-002'):
        for p in sorted((root/folder).rglob('*')):
            if p.is_file():
                z.write(p,str(p.relative_to(root)).replace('\\','/'))
    for name in ('capture_open_zero.py','capture_short_zero.py','archive_same_image_endpoints.py',
                 'same-image-open-short-path-audit.json','same-image-endpoints.json'):
        z.write(root/name,name)
with zipfile.ZipFile(archive_path) as z:
    if z.testzip() is not None or len(z.namelist()) != len(set(z.namelist())):
        raise ValueError('Archive CRC/uniqueness validation failed')
checkpoint = dict(recorded_utc=d.utc(), SIMULATED=False,
    status='OPEN_SHORT_COMPLETE_LOAD_PENDING' if not missing else 'ENDPOINT_PATH_CONFLICTS_LOAD_PENDING',
    identity=identity, open_conditions=33, short_conditions=33,
    conditions_with_common_path=33-len(missing), path_audit=path_audit,
    candidate_generated=False, calibration_installed=False, physically_qualified=False,
    scope_checks='NOT_TESTED; owner-directed engineering campaign',
    final_status=reports['OPEN']['last_safe_status'],
    installation_status=reports['OPEN']['final_installation_status'],
    capture_sha256=d.sha(combined.read_bytes()),
    artifact=dict(bytes=archive_path.stat().st_size,sha256=d.sha(archive_path.read_bytes())))
d.save('docs/review/bringup-2026-10-25/OSL-Same-Image-Endpoints.json',checkpoint)
Path('docs/review/bringup-2026-10-25/OSL-Same-Image-Endpoints.md').write_text(f'''# Same-image OPEN/SHORT checkpoint — October 25, 2026

Status: {checkpoint['status']}; NOT_QUALIFIED.

The owner removed the SHORT jumper and confirmed completely empty DUT terminals
("está open"). The new OPEN sweep accepted all 33 keys with six stable repeats
per condition, SAFE teardown and no new protocol errors. It shares the exact
source-7017e5e0 identity and nominal ADC calibration with the corrected 33-key
SHORT sweep. All 66 original CCO1 frames, canonical metadata and wire logs are
preserved. The old source-063c7378 captures are historical only.

The strict per-key audit found {33-len(missing)}/33 common OPEN/SHORT return paths;
{len(missing)} conditions have an empty intersection. This checks acquisition
compatibility, not OSL solvability or accuracy. HG-only triplets additionally need
actual same-key HG overlap from an accepted standard. No nominal gain is relabelled
as observed. LOAD captures, serialized solver validation and independent holdouts
remain pending. No candidate was generated or installed; scope-dependent checks
remain NOT_TESTED. Final leads will require calibration in their final geometry.

See [structured checkpoint and path audit](OSL-Same-Image-Endpoints.json),
[physical evidence](../../../Firmware/releases/2026-10-25/same-image-osl-endpoints/README.md)
and [the matching nine-firmware/deployment bundle](../../../Firmware/releases/2026-10-25/zero-short-bringup/README.md).
''',encoding='utf-8')
(release/'README.md').write_text('''# Same-image OSL endpoint evidence

`physical-evidence.zip` preserves the 33 OPEN and 33 SHORT artifacts, raw wire
logs, canonical combined document, exact-identity checks and per-key path audit.
The source-7017e5e0 firmware bundle remains in `../zero-short-bringup/`.

This is an engineering checkpoint. LOAD, solver validation, installation and
physical qualification remain pending. No accuracy certificate is implied.

See [bench report](../../../../docs/review/bringup-2026-10-25/OSL-Same-Image-Endpoints.md).
''',encoding='utf-8')
print(json.dumps(dict(status=checkpoint['status'], common_paths=33-len(missing), artifact=checkpoint['artifact']),indent=2))
