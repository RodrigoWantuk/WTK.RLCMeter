"""Archive verified 100-ohm LOAD evidence; never opens a device."""
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl

root=Path(__file__).resolve().parent
report=d.load(root/'load-100-001/report.json')
if report['outcome'] != 'ALL_6_LOAD_CAPTURES_ACCEPTED':
    raise ValueError('Complete six-key LOAD group required')
identity=report['identity']
previous=d.load(root/'same-image-through-load-10.json')
current=d.load(root/'load-100-001/captures.json')
for document in (previous,current): c.verify_campaign(document,identity)
keys={k for k in pc_osl.KEYS if k.rref_ohms==100}
if len(current['captures']) != 6 or {pc_osl.Key.from_json(r['condition']) for r in current['captures']} != keys:
    raise ValueError('Exactly six distinct 100-ohm keys required')
if any(r['standard'] != 'LOAD' or r.get('reference') != report['reference'] for r in current['captures']):
    raise ValueError('Wrong standard/reference binding')
merged=root/'same-image-through-load-100.json'
if merged.exists(): raise ValueError('Refusing to overwrite checkpoint')
for row in previous['captures']+current['captures']: document=c.save_capture(merged,row)
if len(document['captures']) != 75: raise ValueError('75 original observations required')
fits=[]
for key in pc_osl.KEYS:
    group=[pc_osl.standard_from_capture(r) for r in document['captures'] if r['condition']==key.as_json()]
    if len(group)==3:
        s=pc_osl.solve(group)
        fits.append(dict(condition=key.as_json(),fit_channel=s.fit_channel,hg_observed=s.hg_observed,
                         min_separation=s.min_separation,serialized_float32_values=s.values()))
if len(fits)!=9: raise ValueError('Exactly nine complete fit checks required')
next_battery=d.load(root/'battery-before-load-1000-001/report.json')
release=Path('Firmware/releases/2026-10-25/osl-load-100-checkpoint')
release.mkdir(exist_ok=False)
archive=release/'physical-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ('load-100-001','battery-before-load-100-003','battery-before-load-1000-001'):
        for p in sorted((root/folder).rglob('*')):
            if p.is_file(): z.write(p,str(p.relative_to(root)).replace('\\','/'))
    for name in ('capture_load_100.py','read_battery_before_load_100_fresh.py',
                 'read_battery_before_load_1000.py','archive_load_100_checkpoint.py',
                 'same-image-through-load-100.json'):
        z.write(root/name,name)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or len(z.namelist())!=len(set(z.namelist())):
        raise ValueError('Archive verification failed')
checkpoint=dict(recorded_utc=d.utc(),SIMULATED=False,status='LOAD_100_COMPLETE_FOUR_REFERENCE_GROUPS_PENDING',
    identity=identity,observations=75,required_observations=99,complete_conditions=9,
    reference=report['reference'],fresh_owner_dmm_ohms=100.0,
    owner_confirmation='100R exatos, está conectado',reference_policy=report['reference_policy'],
    reference_identification=report['reference_identification'],
    accepted_conditions=report['accepted'],fits=fits,
    battery_before_100=report['battery_check'],battery_before_1000=next_battery,
    battery_policy='Fresh SAFE/idle check before each new resistor; ask charging at LOW (<=3.50V nominal); no capture during charging',
    protocol_errors_baseline=report['protocol_errors_baseline'],final_status=report['last_safe_status'],
    installation_status=report['final_installation_status'],candidate_generated=False,
    calibration_installed=False,physically_qualified=False,
    capture_sha256=d.sha(merged.read_bytes()),artifact=dict(bytes=archive.stat().st_size,sha256=d.sha(archive.read_bytes())))
d.save('docs/review/bringup-2026-10-25/OSL-Load-100.json',checkpoint)
before=report['battery_check']['values']['battery_v']
after=next_battery['values']['battery_v']
Path('docs/review/bringup-2026-10-25/OSL-Load-100.md').write_text(f'''# 100-ohm LOAD checkpoint — October 25, 2026

Status: LOAD_100_COMPLETE; FOUR_REFERENCE_GROUPS_PENDING; NOT_QUALIFIED.

The owner reported "100R exatos, está conectado" after the requested Minipa
ET-1100A 200-ohm-range reading and direct attachment alone. Displayed 100 ohm is
consistency evidence; nominal 100 ohm +/-1% remains the uncertain fit anchor.
Earlier band-color identification remains provisional; no traceable actual value
or precision beyond the reference evidence is asserted.

Six LOAD keys (10 Hz / 1 kHz / 10 kHz, 100 / 500 mVrms) passed six stable repeats,
SAFE teardown and same-image OPEN/SHORT/LOAD fit checks. Saturated HG channels
were retained as rejected paths; usable 1X evidence supports those fits. The
100-ohm / 10-kHz / 100-mVrms key used HG with actual observed overlap from its
same-key standards. All nine
complete triplets, including the earlier 10-ohm group, passed strict float32
solver checks. Progress is 75/99 observations and 9/33 complete conditions.
This establishes fit consistency, not independent accuracy validation.

Fresh battery before this group: {before:.5f} V; before the next 1-kohm group:
{after:.5f} V. Both are nominal-ADC readings, state OK, from SAFE/idle snapshots
without reset. The owner's per-resistor battery-check policy remains active.
Protocol-error baseline was {report['protocol_errors_baseline']} and did not
increase during this group. Fault mask remains zero and calibration storage blank.
No complete candidate was generated or installed. Four LOAD groups, independent
holdouts and scope-dependent qualification remain pending.

See [structured checkpoint](OSL-Load-100.json),
[physical evidence](../../../Firmware/releases/2026-10-25/osl-load-100-checkpoint/README.md)
and [the previous LOAD checkpoint](OSL-Load-10.md).
''',encoding='utf-8')
(release/'README.md').write_text('''# 100-ohm LOAD evidence

The ZIP preserves six original LOAD artifacts, per-key fit checks, wire logs,
fresh battery snapshots and the cumulative 75-observation canonical document.
Identity, artifact CRC/SHA and archive CRC/uniqueness checks passed. Four LOAD
groups, independent qualification and installation remain pending.

See [bench report](../../../../docs/review/bringup-2026-10-25/OSL-Load-100.md).
''',encoding='utf-8')
print(json.dumps(dict(status=checkpoint['status'],observations=75,complete_conditions=9,artifact=checkpoint['artifact']),indent=2))
