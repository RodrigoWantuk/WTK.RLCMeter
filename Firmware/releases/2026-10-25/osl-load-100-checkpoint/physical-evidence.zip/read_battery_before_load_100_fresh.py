"""Read fresh battery RAM in idle verified 7017 firmware; no reset or writes."""
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import time
sys.path.insert(0, str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_cal_capture as c
import pc_firmware_deploy as d

root = Path(__file__).resolve().parent
build = root / 'verified-builds-zero-short/bringup-cal'
out = root / 'battery-before-load-100-003'
out.mkdir(exist_ok=False)
expected = d.load(root / 'boot-identify-zero-short-001/report.json')['identity']
class Paced:
    def __init__(self,link): self.link=link
    def write(self,data):
        for byte in data:
            if self.link.write(bytes([byte])) != 1: raise OSError('Partial read-only serial request')
            time.sleep(0.001)
        return len(data)
    def read(self,count=1): return self.link.read(count)

def status():
    link = b.open_serial('COM4')
    try:
        client = c.Client(Paced(link))
        if client.identify() != expected:
            raise ValueError('Firmware identity changed')
        state = client.status()
        if state['busy'] or not state['transfer_safe'] or state['safety_faults']:
            raise ValueError('SAFE idle required for SWD snapshot')
        return state
    finally:
        link.close()
before = status()
arm = Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin')
fields = {
    'battery_v': ('offsetof(hw_aux_sensors_t,snapshot)+offsetof(hw_aux_sensors_snapshot_t,battery_v)', 'f'),
    'battery_raw': ('offsetof(hw_aux_sensors_t,snapshot)+offsetof(hw_aux_sensors_snapshot_t,battery_raw)', 'H'),
    'battery_state': ('offsetof(hw_aux_sensors_t,snapshot)+offsetof(hw_aux_sensors_snapshot_t,battery_state)', 'B'),
    'battery_timestamp_ms': ('offsetof(hw_aux_sensors_t,battery_timestamp_ms)', 'I'),
    'battery_published': ('offsetof(hw_aux_sensors_t,battery_published)', 'B'),
    'aux_paused': ('offsetof(hw_aux_sensors_t,paused)', 'B'),
    'vmid_v': ('offsetof(hw_aux_sensors_t,snapshot)+offsetof(hw_aux_sensors_snapshot_t,vmid_v)', 'f'),
    'fault_mask': ('offsetof(hw_aux_sensors_t,fault_mask)', 'I'),
}
(out / 'layout.c').write_text('#include <stddef.h>\n#include "hardware/hw_aux_sensors.h"\nconst unsigned int offsets[]={' + ','.join(v[0] for v in fields.values()) + '};\n', encoding='ascii')
subprocess.run([str(arm / 'arm-none-eabi-gcc.exe'), '-std=c17', '-mcpu=cortex-m3', '-mthumb', '-S', str(out / 'layout.c'), '-I', 'Firmware/src', '-I', str(build / 'generated'), '-o', str(out / 'layout.s')], check=True)
offsets = [int(n) for n in re.findall(r'^\s*\.word\s+(\d+)', (out / 'layout.s').read_text(), re.M)]
if len(offsets) != len(fields):
    raise ValueError('Compiler layout incomplete')
nm = subprocess.check_output([str(arm / 'arm-none-eabi-nm.exe'), '-n', str(build / 'WTK.RLCMeter.elf')], text=True)
symbols = {name:int(addr,16) for addr,name in re.findall(r'^([0-9a-f]+) [A-Za-z] (\S+)$',nm,re.M)}
backend = d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
plan = backend.plan('probe', out, None, expected['uid'])
plan['environment']['WTK_RAM_FILE'] = str(out / 'ram.bin')
plan['argv'][-1] = ('if {[catch {init; halt; wtk_preflight; dump_image $::env(WTK_RAM_FILE) 0x20000000 20480; resume; echo "WTK_NO_RESET_RAM_RESUMED"} reason]} {catch {resume}; echo "WTK_B011_FAILURE"; echo $reason; shutdown error} else {shutdown}')
run = subprocess.run(plan['argv'], env=dict(os.environ, **plan['environment']), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=15, creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
(out / 'openocd.txt').write_bytes(run.stdout)
if run.returncode or run.stdout.count(b'WTK_NO_RESET_RAM_RESUMED') != 1:
    raise ValueError('RAM snapshot/resume not confirmed')
raw = (out / 'ram.bin').read_bytes()
values = {name:struct.unpack_from('<'+fmt,raw,symbols['sensors']-0x20000000+offset)[0] for (name,(_,fmt)),offset in zip(fields.items(),offsets)}
tick = struct.unpack_from('<I',raw,symbols['g_time_ms']-0x20000000)[0]
values['age_ms'] = (tick-values['battery_timestamp_ms']) & 0xffffffff
if values['age_ms'] > 2000 or not values['battery_published'] or values['aux_paused'] or values['fault_mask']:
    raise ValueError('Fresh unpaused battery reading required: '+str(values))
after = status()
report = dict(recorded_utc=d.utc(), operation='NO_RESET_BATTERY_RAM_HALT_RESUME', firmware_identity=expected, scale='Nominal ADC 3.3V; not independently calibrated', values=values, before_status=before, after_status=after, ram_sha256=d.sha(raw))
d.save(out/'report.json',report)
print(json.dumps(report,indent=2))
