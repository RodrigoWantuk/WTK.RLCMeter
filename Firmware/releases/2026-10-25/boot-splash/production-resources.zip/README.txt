Seven-entry schema2/API4 pack including personalized splash0x00030006.
Physical exact readback accepted; mutable32KiB tail preserved.
Use tracked paced resource_pack_tool.py upload and independent readback.
Owner will inspect visible splash later; no calibration/release qualification inferred.
