Source adfce3c59aac085a95b7fa487fed5f836dca21ec
Calibration hardware0x00010002.
Software builds passed; physical qualification/calibration remains required.
PRODUCT preserves battery/charger/residual/calibration gates.
No automatic deployment. BRINGUP variants are engineering diagnostics.
