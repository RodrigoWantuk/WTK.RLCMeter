set pagination off
set confirm off
set language c
set remotetimeout 5
set unwind-on-signal on
set unwind-on-timeout on
file C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/final-image/firmware.elf
target extended-remote 127.0.0.1:3333
monitor halt
monitor wtk_operation
monitor verify_image $::env(WTK_IMAGE) 0x8000000 bin
if (*(unsigned int*)0x40010c0c & 0x300) != 0
echo WTK_READ_REFUSED K1/range not off\n
quit 1
end
if (*(unsigned int*)0x4001080c & 0x100) != 0
echo WTK_READ_REFUSED Excitation not off\n
quit 1
end
if *(unsigned char*)0x2000004e != 0 || *(unsigned char*)0x20000058 != 0
echo WTK_READ_REFUSED SPI/quiet owner busy\n
quit 1
end
if *(unsigned int*)0x20001b18 != 0
echo WTK_READ_REFUSED Workspace not free\n
quit 1
end
if *(unsigned char*)0x20000ef4 != 1 || *(unsigned int*)0x20000efc != 4194304
echo WTK_READ_REFUSED Flash not detected4MiB\n
quit 1
end
if *(unsigned char*)0x20000f04 != 0
echo WTK_READ_REFUSED NOR operation active\n
quit 1
end
if *(unsigned char*)0x2000004e != 0
echo WTK_READ_REFUSED Peripheral owner busy\n
quit 1
end
if *(unsigned char*)0x20000059 != 0
echo WTK_READ_REFUSED Peripheral owner busy\n
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/scratch-before.bin 0x20000f18 0x20001b1c
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 0, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-000000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 3072, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-000c00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 6144, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-001800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 9216, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-002400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 12288, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-003000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 15360, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-003c00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 18432, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-004800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 21504, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-005400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 24576, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-006000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 27648, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-006c00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 30720, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-007800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 33792, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-008400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 36864, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-009000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 39936, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-009c00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 43008, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-00a800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 46080, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-00b400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 49152, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-00c000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 52224, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-00cc00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 55296, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-00d800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 58368, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-00e400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 61440, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-00f000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 64512, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-00fc00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 67584, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-010800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 70656, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-011400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 73728, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-012000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 76800, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-012c00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 79872, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-013800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 82944, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-014400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 86016, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-015000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 89088, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-015c00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 92160, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-016800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 95232, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-017400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 98304, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-018000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 101376, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-018c00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 104448, (void*)0x20000f18, 2048)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-019800-2048.bin 0x20000f18 0x20001718
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4161536, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3f8000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4164608, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3f8c00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4167680, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3f9800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4170752, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3fa400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4173824, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3fb000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4176896, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3fbc00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4179968, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3fc800-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4183040, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3fd400-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4186112, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3fe000-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4189184, (void*)0x20000f18, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3fec00-3072.bin 0x20000f18 0x20001b18
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x8001289)((void*)0x20000ef4, 4192256, (void*)0x20000f18, 2048)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/read-3ff800-2048.bin 0x20000f18 0x20001718
restore C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-after/scratch-before.bin binary 0x20000f18
monitor reset run
detach
echo WTK_EXTERNAL_READ_COMPLETE\n
quit 0
