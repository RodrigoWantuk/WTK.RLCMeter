set pagination off
set confirm off
set language c
set remotetimeout 5
set unwind-on-signal on
set unwind-on-timeout on
file C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/battery-start-20261024/image/firmware.elf
target extended-remote 127.0.0.1:3333
monitor halt
monitor wtk_operation
monitor verify_image $::env(WTK_IMAGE) 0x08000000 bin
if (*(unsigned int*)0x40010c0c & 0x300) != 0
echo WTK_READ_REFUSED K1/range not off\n
quit 1
end
if (*(unsigned int*)0x4001080c & 0x100) != 0
echo WTK_READ_REFUSED Excitation not off\n
quit 1
end
if *(unsigned char*)0x2000004e != 0 || *(unsigned char*)0x20000050 != 0
echo WTK_READ_REFUSED SPI/quiet owner busy\n
quit 1
end
if *(unsigned int*)0x20001b20 != 0
echo WTK_READ_REFUSED Workspace not free\n
quit 1
end
if *(unsigned char*)0x20000e7c != 1 || *(unsigned int*)0x20000e84 != 4194304
echo WTK_READ_REFUSED Flash not detected4MiB\n
quit 1
end
if *(unsigned char*)0x20000e8c != 0
echo WTK_READ_REFUSED NOR operation active\n
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/scratch-before.bin 0x20000f20 0x20001b24
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 0, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-000000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 3072, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-000c00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 6144, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-001800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 9216, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-002400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 12288, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-003000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 15360, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-003c00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 18432, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-004800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 21504, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-005400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 24576, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-006000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 27648, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-006c00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 30720, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-007800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 33792, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-008400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 36864, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-009000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 39936, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-009c00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 43008, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-00a800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 46080, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-00b400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 49152, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-00c000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 52224, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-00cc00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 55296, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-00d800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 58368, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-00e400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 61440, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-00f000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 64512, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-00fc00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 67584, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-010800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 70656, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-011400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 73728, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-012000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 76800, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-012c00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 79872, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-013800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 82944, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-014400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 86016, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-015000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 89088, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-015c00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 92160, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-016800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 95232, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-017400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 98304, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-018000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 101376, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-018c00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 104448, (void*)0x20000f20, 2048)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-019800-2048.bin 0x20000f20 0x20001720
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4161536, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3f8000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4164608, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3f8c00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4167680, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3f9800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4170752, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3fa400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4173824, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3fb000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4176896, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3fbc00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4179968, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3fc800-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4183040, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3fd400-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4186112, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3fe000-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4189184, (void*)0x20000f20, 3072)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3fec00-3072.bin 0x20000f20 0x20001b20
set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, 4192256, (void*)0x20000f20, 2048)
if $read_status != 0
echo WTK_DRIVER_READ_FAILED\n
print $read_status
quit 1
end
dump binary memory C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/read-3ff800-2048.bin 0x20000f20 0x20001720
restore C:/Users/rodri/source/repos/WTK.RLCMeter/Firmware/build/splash-20261024/external-before/scratch-before.bin binary 0x20000f20
monitor reset run
detach
echo WTK_EXTERNAL_READ_COMPLETE\n
quit 0
