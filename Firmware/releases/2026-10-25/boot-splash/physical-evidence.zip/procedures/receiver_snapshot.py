"""Read live receiver RAM/GPIO, using compiler-derived offsets, without reset."""
import json,os,re,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
root=Path(__file__).resolve().parent
stage=sys.argv[1]
if stage not in ('before','before-002','after','restart','failure'): raise ValueError('Invalid stage')
out=root/('receiver-state-'+stage);out.mkdir(exist_ok=False)
layout=d.load(root/'factory-release-layout.json');offset=layout['offsets'];syms=layout['symbols']
def symbol(name):
    values=[v for k,v in syms.items() if k==name or k.startswith(name+'.lto_priv.')]
    if len(values)!=1: raise ValueError('Ambiguous symbol '+name)
    return values[0]
p=symbol('g_product');u=symbol('g_resource_update');s=symbol('g_boot_splash')
fields={
 'resource_status':(symbol('g_resource_status'),8),
 'product_state':(p+offset['view']+offset['view_state'],8),
 'calibration_active_valid':(p+offset['view']+offset['cal_valid'],8),
 'runtime_kind':(p+offset['runtime_kind'],8),
 'update_state':(u+offset['update_state'],8),
 'update_error':(u+offset['update_error'],8),
 'safety_fault_mask':(symbol('g_safety_faults'),32),
 'flash_operation':(symbol('g_flash')+offset['flash_operation'],8),
 'measurement_session_state':(p+offset['measurement_state'],8),
 'attempt_started':(p+offset['attempt_started'],8),
 'rx_received':(symbol('g_pc_link_received'),16),
 'rx_expected':(symbol('g_pc_link_expected'),16),
 'ack_deferred':(symbol('g_pc_link_ack_deferred'),8),
 'splash_state':(s+offset['splash_state'],8),
 'time_ms':(symbol('g_time_ms'),32),
 'gpioa_idr':(0x40010808,32),'gpioa_odr':(0x4001080c,32),'gpiob_odr':(0x40010c0c,32)}
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
 'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
plan=backend.plan('probe',out,None,'54ff70068370525760380567')
values=' '.join('[lindex [read_memory 0x%x %u 1] 0]'%(a,w) for a,w in fields.values())
plan['environment']['WTK_UPDATE_DUMP']=str(out/'resource-update.bin')
plan['environment']['WTK_FRAME_DUMP']=str(out/'frame.bin')
body='init; halt; echo [format "WTK_RESOURCE_STATE|'+'|'.join(['%u']*len(fields))+'" '+values+']; dump_image $::env(WTK_UPDATE_DUMP) 0x%x %u; dump_image $::env(WTK_FRAME_DUMP) 0x%x 144; resume; echo "WTK_RESOURCE_STATE_RESUMED"'%(u,offset['update_bytes'],symbol('g_pc_link_frame'))
plan['argv'][-1]='if {[catch {'+body+'} reason]} {catch {resume}; echo $reason; shutdown error} else {shutdown}'
run=subprocess.run(plan['argv'],env=dict(os.environ,**plan['environment']),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
(out/'openocd.txt').write_bytes(run.stdout)
raw=run.stdout.decode(errors='replace')
if run.returncode or raw.count('WTK_RESOURCE_STATE_RESUMED')!=1: raise ValueError('Snapshot uncertain')
record=dict(zip(fields,map(int,re.search(r'WTK_RESOURCE_STATE\|([0-9|]+)',raw)[1].split('|'))))
record.update(recorded_utc=d.utc(),simulated=False,core_resumed=True,
    image_sha256=d.load(root/'receiver-image/manifest.json')['files']['firmware.bin']['sha256'],
    k1_cmd=bool(record['gpiob_odr']&512),range_en=bool(record['gpiob_odr']&256),
    excitation_cmd=bool(record['gpioa_odr']&256),charger_pa15_high=bool(record['gpioa_idr']&32768))
record['outcome']='EXPECTED_SAFE_RESOURCE_STATE'
if record['runtime_kind']!=1 or record['resource_status']!=0 or record['product_state']!=3 or any(record[k] for k in
 ('calibration_active_valid','measurement_session_state','attempt_started','safety_fault_mask','flash_operation','k1_cmd','range_en','excitation_cmd','charger_pa15_high','splash_state')):
    record['outcome']='UNEXPECTED_STATE'
if stage=='failure': record['outcome']='DIAGNOSTIC_ONLY'
d.save(out/'report.json',record);print(json.dumps(record,indent=2),flush=True)
if record['outcome']=='UNEXPECTED_STATE': raise SystemExit(1)
