"""Interpret the completed physical trace; no new target access or simulation."""
import json,re,sys
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import pc_bringup as b
root=Path(__file__).resolve().parent;out=root/'boot-timing-final'
raw=(out/'openocd.txt').read_text(errors='replace');banner=(out/'uart.bin').read_bytes()
if raw.count('WTK_SPLASH_TIMING_COMPLETE')!=1: raise ValueError('Incomplete real capture')
keys=('splash_state','visible_ms','pixels_remaining','gpioa_odr','gpiob_odr','faults','time_ms')
samples=[dict(zip(keys,map(int,line.split('|')))) for line in re.findall(r'WTK_SPLASH\|([0-9|]+)',raw)]
if len(samples)!=600: raise ValueError('Incomplete physical samples')
lines=banner.decode('ascii').splitlines()
end=next(i for i,line in enumerate(lines) if line.startswith('watchdog_policy:'))
identity=b.identity_from_lines(lines[:end+1])
holds=[x for x in samples if x['splash_state']==5];clears=[x for x in samples if x['splash_state']==6]
if not holds or not clears: raise ValueError('No hold/clear transition')
visible=holds[0]['visible_ms'];clear=clears[0]['time_ms']
image=d.load(root/'final-image/manifest.json')
checks=dict(full_image_before_hold=holds[0]['pixels_remaining']==0,
 hold_at_least_3000ms=clear-visible>=3000,
 completed=any(x['splash_state']==0 and x['time_ms']>clear for x in samples),
 safe_output_commands=all(not(x['gpiob_odr']&0x300 or x['gpioa_odr']&0x100 or x['faults']) for x in samples),
 monotonic_no_reset=all(right['time_ms']>=left['time_ms'] for left,right in zip(samples,samples[1:])),
 matching_identity=identity['git']==image['source']['git_sha'][:12] and lines.count('WTK.RLCMeter')==1)
report=dict(simulated=False,recorded_utc=d.utc(),observation_origin='Existing complete physical running-core OpenOCD trace',
 parser_note='Identity limited to watchdog_policy; later repeated safety logs are not duplicate boot banners',
 sample_period_ms=25,samples=samples,checks=checks,identity=identity,
 visible_timestamp_ms=visible,first_observed_clear_ms=clear,hold_observed_ms=clear-visible,
 limitation='Software/SPI completion and commanded GPIO states only; actual visible TFT pixels/timing remain unobserved',
 image_sha256=image['files']['firmware.bin']['sha256'],
 outcome='BOOT_CONTROLLER_TIMING_OBSERVED' if all(checks.values()) else 'INCOMPLETE')
d.save(out/'report.json',report)
print(json.dumps({k:v for k,v in report.items() if k!='samples'},indent=2),flush=True)
if not all(checks.values()): raise SystemExit(1)
