"""Use the public paced uploader, recording progress without replaying frames."""
import ctypes,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import pc_link_resource_pack as p
import resource_pack_tool as tool
root=Path(__file__).resolve().parent
if d.load(root/'receiver-state-before-002/report.json')['outcome']!='EXPECTED_SAFE_RESOURCE_STATE': raise ValueError('No safe receiver')
failure=d.load(root/'receiver-state-failure/report.json')
if failure['update_state']!=0 or failure['flash_operation']!=0: raise ValueError('Prior mutation state unresolved')
pack=(root/'production.wrp2').read_bytes()
if d.sha(pack)!='d5e6f558173a67f3a30212f4951be11db7893121e12fc210d3b06df30c2cd78f': raise ValueError('Pack differs')
events=[];started=time.monotonic();read_status=p.read_status_frame
def observed(link):
    value=read_status(link)
    events.append(dict(sequence=value[0],pc_status=value[1],update_status=value[2],update_state=value[3],elapsed_s=time.monotonic()-started))
    if len(events)==1 or len(events)%25==0 or len(events)==873:
        print('ACK %u/873 elapsed %.1fs'%(len(events),time.monotonic()-started),flush=True)
        d.save(root/'upload-progress.json',events)
    return value
p.read_status_frame=observed
# Keep millisecond pacing precise on this Python/Windows host; restore on exit.
timer=ctypes.windll.winmm.timeBeginPeriod(1)==0
try:
    tool.main(['upload',str(root/'production.wrp2'),'--port','COM4','--report',str(root/'upload-002.json')])
finally:
    if timer: ctypes.windll.winmm.timeEndPeriod(1)
    d.save(root/'upload-progress.json',events)
