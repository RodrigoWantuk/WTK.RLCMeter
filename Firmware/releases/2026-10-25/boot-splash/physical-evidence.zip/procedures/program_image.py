"""Owner-authorized splash provisioning, then updated standard BRINGUP."""
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
root=Path(__file__).resolve().parent
stage=sys.argv[1]
if stage not in ('receiver','final'): raise ValueError('receiver/final only')
builds=d.load(root/'firmware-builds.json')
if len(builds['cases'])!=9 or any(x['status']!='PASS' for x in builds['cases']):
    raise ValueError('Requires full nine-profile passing matrix')
name,profile,preset=('factory-release','FACTORY_PRODUCT','stm32-factory-release') if stage=='receiver' else ('bringup','BRINGUP','stm32-bringup')
for filename,meta in next(x for x in builds['cases'] if x['name']==name)['files'].items():
    raw=(root/name/filename).read_bytes()
    if len(raw)!=meta['bytes'] or d.sha(raw)!=meta['sha256']: raise ValueError('Build artifact differs')
image=d.manifest(root/name,root/(stage+'-image'),profile,builds['source'],preset)
if stage=='receiver':
    if d.load(root/'external-before/report.json')['outcome']!='READ_BACKUP_COMPLETE': raise ValueError('No backup')
    if d.load(root/'boot-bringup-before-product/report.json')['outcome']!='PASSIVE_STATUS_COLLECTED': raise ValueError('No fresh SAFE boot')
else:
    if d.load(root/'upload-002.json')['outcome']!='ALL_FRAMES_ACKNOWLEDGED': raise ValueError('Upload not complete')
    if d.load(root/'receiver-state-restart/report.json')['outcome']!='EXPECTED_SAFE_RESOURCE_STATE': raise ValueError('No product admission')
auth=dict(operator='Rodrigo; explicit splash upload and firmware programming request',utc=d.utc(),
    board='Rev1 RGS-to-GND',expected_uid='54ff70068370525760380567',SIMULATED=False,
    previous_profile='BRINGUP' if stage=='receiver' else 'FACTORY_PRODUCT',next_profile=profile,
    image_sha256=image['files']['firmware.bin']['sha256'],manifest_seal=image['seal_sha256'],
    approval_origin='Explicit owner request: update every firmware and upload supplied personalized image',
    scope='Temporary factory PRODUCT resource maintenance' if stage=='receiver' else 'Updated standard BRINGUP after asset admission',
    resource_scope='Backed up [0,0x1A000); preserve mutable [0x3F8000,0x400000)',
    supply='Battery/boost, charger absent, battery about3.81V, no DUT operations',
    calibration='Invalid OSL remains invalid; no calibration mutation or final product qualification',
    final_factory_product_acceptance='NOT_REQUESTED_NOT_VALIDATED',
    acknowledgements=dict(safe_outputs=True,debug_halt_watchdog=True,no_app_bootloader=True,internal_flash=True))
auth['seal_sha256']=d.seal(auth)
d.save(root/(stage+'-authorization.json'),auth)
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
    'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
record=d.deployment('program',root/(stage+'-image/manifest.json'),backend,root/(stage+'-deployment'),authorization=auth,uid=auth['expected_uid'])
print(json.dumps({key:record.get(key) for key in ('outcome','readback','error')},indent=2),flush=True)
if record['outcome']!='INTERNAL_FLASH_VERIFIED': raise SystemExit(1)
