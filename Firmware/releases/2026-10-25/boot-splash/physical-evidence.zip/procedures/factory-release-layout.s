	.cpu cortex-m3
	.arch armv7-m
	.fpu softvfp
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 6
	.eabi_attribute 34, 1
	.eabi_attribute 18, 4
	.file	"layout.c"
	.text
	.global	offsets
	.section	.rodata
	.align	2
	.type	offsets, %object
	.size	offsets, 68
offsets:
	.word	1464
	.word	0
	.word	84
	.word	1582
	.word	60
	.word	61
	.word	84
	.word	1417
	.word	1431
	.word	16
	.word	8
	.word	3072
	.word	3076
	.word	324
	.word	304
	.word	300
	.word	220
	.ident	"GCC: (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119"
