"""Controlled temporary PRODUCT boot, capture minimal banner without sending frames."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_bringup as b
import pc_firmware_deploy as d

root=Path(__file__).resolve().parent
if len(sys.argv)>2 or (len(sys.argv)==2 and sys.argv[1] not in ('retry','verify')):
    raise ValueError('Optional retry boot only')
deployment=d.checked(d.load(root/'receiver-deployment/deployment.json'))
if deployment['outcome']!='INTERNAL_FLASH_VERIFIED': raise ValueError('Receiver image unverified')
out=root/('receiver-boot-'+sys.argv[1] if len(sys.argv)==2 else 'receiver-boot-001')
out.mkdir(exist_ok=False)
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
    'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
plan=backend.plan('probe',out,None,deployment['target']['uid'])
plan['argv'][-1]='if {[catch {init; reset init; wtk_operation; reset run; echo "WTK_RESOURCE_RECEIVER_BOOT"} reason]} {echo "WTK_B011_FAILURE"; echo $reason; shutdown error} else {shutdown}'
link=b.open_serial('COM4')
received=bytearray()
try:
    run=subprocess.run(plan['argv'],env=dict(os.environ,**plan['environment']),
        stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    (out/'openocd.txt').write_bytes(run.stdout)
    if run.returncode or run.stdout.count(b'WTK_RESOURCE_RECEIVER_BOOT')!=1:
        raise ValueError('Controlled receiver boot unconfirmed')
    d.validate_target(d.parse_target(run.stdout.decode(errors='replace')),deployment['target']['uid'])
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        received.extend(link.read(256))
        if len(received)>4096: raise ValueError('Unexpected boot output volume')
    if bytes(received).splitlines().count(b'WTK.RLCMeter SAFE_BOOT')!=1:
        raise ValueError('Expected single minimal safe boot banner')
    report=dict(recorded_utc=d.utc(),simulated=False,
        outcome='PRODUCT_SAFE_BOOT_BANNER_CAPTURED',image_sha256=deployment['readback']['actual_sha256'],
        banner=received.decode('ascii'),limitation='Minimal banner only; inspect product RAM for recovery/safety state before upload')
    d.save(out/'report.json',report)
    print(json.dumps(report,indent=2))
finally:
    (out/'uart-rx.bin').write_bytes(received)
    link.close()
