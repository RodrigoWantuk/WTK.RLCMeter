"""Observe boot controller timing with running-core RAM reads; no visual claim."""
import json,os,re,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import pc_bringup as b
root=Path(__file__).resolve().parent
out=root/'boot-timing';out.mkdir(exist_ok=False)
layout=d.load(root/'factory-release-layout.json');o=layout['offsets'];s=layout['symbols']
base=s['g_boot_splash']
fields=[(base+o['splash_state'],8),(base+o['splash_visible'],32),
        (base+o['splash_pixels_remaining'],32),(0x4001080c,32),(0x40010c0c,32),
        (next(v for k,v in s.items() if k.startswith('g_safety_faults.')),32),(s['g_time_ms'],32)]
values=' '.join('[lindex [read_memory 0x%x %u 1] 0]'%(a,w) for a,w in fields)
sample='echo [format "WTK_SPLASH|'+'|'.join(['%u']*len(fields))+'" '+values+']'
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
 'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
plan=backend.plan('probe',out,None,'54ff70068370525760380567')
body='init; reset init; wtk_operation; reset run; for {set i 0} {$i < 600} {incr i} {sleep 25; '+sample+'}; echo "WTK_SPLASH_TIMING_COMPLETE"'
plan['argv'][-1]='if {[catch {'+body+'} reason]} {echo $reason; shutdown error} else {shutdown}'
link=b.open_serial('COM4')
try:
 run=subprocess.run(plan['argv'],env=dict(os.environ,**plan['environment']),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 (out/'openocd.txt').write_bytes(run.stdout)
 banner=link.read(1024);(out/'uart.bin').write_bytes(banner)
finally: link.close()
raw=run.stdout.decode(errors='replace')
if run.returncode or raw.count('WTK_SPLASH_TIMING_COMPLETE')!=1: raise ValueError('Timing run incomplete')
keys=('splash_state','visible_ms','pixels_remaining','gpioa_odr','gpiob_odr','faults','time_ms')
samples=[dict(zip(keys,map(int,line.split('|')))) for line in re.findall(r'WTK_SPLASH\|([0-9|]+)',raw)]
if len(samples)!=600: raise ValueError('Incomplete samples')
holds=[x for x in samples if x['splash_state']==5]
clears=[x for x in samples if x['splash_state']==6]
if not holds or not clears: raise ValueError('No HOLD/CLEAR transition observed')
visible=holds[0]['visible_ms'];clear=clears[0]['time_ms']
checks=dict(full_image_before_hold=holds[0]['pixels_remaining']==0,
 hold_at_least_3000ms=clear-visible>=3000,
 completed=any(x['splash_state']==0 and x['time_ms']>clear for x in samples),
 safe_outputs=all(not(x['gpiob_odr']&0x300 or x['gpioa_odr']&0x100 or x['faults']) for x in samples),
 single_minimal_banner=banner.splitlines().count(b'WTK.RLCMeter SAFE_BOOT')==1)
report=dict(simulated=False,recorded_utc=d.utc(),sample_period_ms=25,samples=samples,checks=checks,
 visible_timestamp_ms=visible,first_observed_clear_ms=clear,hold_observed_ms=clear-visible,
 limitation='Running-core software/SPI completion state only; no physical TFT pixels or visible timing observed',
 image_sha256=d.load(root/'receiver-image/manifest.json')['files']['firmware.bin']['sha256'],
 outcome='BOOT_CONTROLLER_TIMING_OBSERVED' if all(checks.values()) else 'INCOMPLETE')
d.save(out/'report.json',report)
print(json.dumps({k:v for k,v in report.items() if k!='samples'},indent=2),flush=True)
if not all(checks.values()): raise SystemExit(1)
