"""Read-only target W25Q API calls on the verified idle standard BRINGUP."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d

root=Path(__file__).resolve().parent
if len(sys.argv)!=2 or sys.argv[1] not in ('probe','probe-002','probe-003','before','after'):
    raise ValueError('Requires probe/before/after')
stage=sys.argv[1]
out=root/('external-'+stage)
out.mkdir(exist_ok=False)
bringup=root.parent/'battery-start-20261024'
manifest=bringup/'image/manifest.json'
image=d.inspect(manifest,'BRINGUP')
if image['files']['firmware.bin']['sha256']!='e4af20eff8f4e06de291fd2c06e5de1437517ad0f0364da253a736f6f244876a':
    raise ValueError('RAM/function bindings require exact published BRINGUP')
pre=d.load(bringup/'assets-preflight-001/report.json')
if pre['outcome']!='EXPECTED_PASSIVE_STATE_OBSERVED':
    raise ValueError('Missing passive SAFE evidence')
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe',
    'Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
provenance=backend.provenance()
plan=backend.plan('verify',out,dict(image,manifest_path=str(manifest)),'54ff70068370525760380567')
plan['argv'][-5]='bindto 127.0.0.1; gdb_port 3333; tcl_port disabled; telnet_port disabled'
plan['argv'][-1]='init'
def gpath(p):
    value=str(Path(p).resolve()).replace('\\','/')
    if any(ch.isspace() for ch in value): raise ValueError('GDB dump paths must not contain whitespace')
    return value
workspace=0x20000f20
commands=['set pagination off','set confirm off','set language c','set remotetimeout 5',
    'set unwind-on-signal on','set unwind-on-timeout on',
    'file '+gpath(manifest.parent/'firmware.elf'),
    'target extended-remote 127.0.0.1:3333','monitor halt','monitor wtk_operation',
    'monitor verify_image $::env(WTK_IMAGE) 0x08000000 bin']
conditions=[('(*(unsigned int*)0x40010c0c & 0x300) != 0','K1/range not off'),
    ('(*(unsigned int*)0x4001080c & 0x100) != 0','Excitation not off'),
    ('*(unsigned char*)0x2000004e != 0 || *(unsigned char*)0x20000050 != 0','SPI/quiet owner busy'),
    ('*(unsigned int*)0x20001b20 != 0','Workspace not free'),
    ('*(unsigned char*)0x20000e7c != 1 || *(unsigned int*)0x20000e84 != 4194304','Flash not detected4MiB'),
    ('*(unsigned char*)0x20000e8c != 0','NOR operation active')]
for condition,message in conditions:
    commands += ['if '+condition,'echo WTK_READ_REFUSED '+message+'\\n','quit 1','end']
commands += ['dump binary memory '+gpath(out/'scratch-before.bin')+' 0x20000f20 0x20001b24']
regions=[(0,256)] if stage.startswith('probe') else [(0,106496),(0x3f8000,32768)]
chunks=[]
for address,length in regions:
    for offset in range(0,length,3072):
        absolute=address+offset
        count=min(3072,length-offset)
        filename=f'read-{absolute:06x}-{count:04d}.bin'
        commands += [f'set $read_status = ((unsigned int (*)(void*, unsigned int, void*, unsigned int))0x08001031)((void*)0x20000e7c, {absolute}, (void*)0x20000f20, {count})',
            'if $read_status != 0','echo WTK_DRIVER_READ_FAILED\\n','print $read_status','quit 1','end',
            f'dump binary memory {gpath(out/filename)} 0x{workspace:x} 0x{workspace+count:x}']
        chunks.append(dict(address=absolute,bytes=count,file=filename))
commands += ['restore '+gpath(out/'scratch-before.bin')+' binary 0x20000f20',
    'monitor reset run','detach','echo WTK_EXTERNAL_READ_COMPLETE\\n','quit 0']
script=out/'read.gdb'
script.write_text('\n'.join(commands)+'\n',encoding='ascii')
gdb='C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin/arm-none-eabi-gdb.exe'
report=dict(simulated=False,recorded_utc=d.utc(),stage=stage,
    operation='EXISTING_W25Q_READ_API_DEBUG_CALLS',regions=regions,
    firmware_sha256=image['files']['firmware.bin']['sha256'],programmer=provenance,
    error=None,outcome='IN_PROGRESS')
log=(out/'openocd.txt').open('wb')
server=subprocess.Popen(plan['argv'],env=dict(os.environ,**plan['environment']),
    stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
try:
    deadline=time.monotonic()+8
    while time.monotonic()<deadline:
        if server.poll() is not None: raise ValueError('OpenOCD exited')
        if 'Listening on port 3333' in (out/'openocd.txt').read_text(errors='replace'): break
        time.sleep(0.05)
    else: raise TimeoutError('No GDB listener')
    run=subprocess.run([gdb,'-q','-batch','-x',str(script)],stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,timeout=45,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    (out/'gdb.txt').write_bytes(run.stdout)
    text=run.stdout.decode(errors='replace')
    if run.returncode or text.count('WTK_EXTERNAL_READ_COMPLETE')!=1:
        print(text)
        raise ValueError('Driver-call read incomplete; inspect target before further operations')
    flash=(out/'full-readback.bin').read_bytes()
    if len(flash)!=65536 or d.sha(flash)!='9c6e1a70bfc7f118104ad70ffcc0043ebf59cc6ccf85eb531241b54406d810f1':
        raise ValueError('Live internal Flash differs from exact bound image')
    for address,length in regions:
        data=b''.join((out/chunk['file']).read_bytes() for chunk in chunks if address<=chunk['address']<address+length)
        if len(data)!=length: raise ValueError('Read region length mismatch')
        path=out/f'region-{address:06x}.bin'
        path.write_bytes(data)
        report.setdefault('readback',[]).append(dict(start=address,bytes=length,sha256=d.sha(data),file=path.name,
            all_erased=all(byte==255 for byte in data)))
    report.update(outcome='READ_BACKUP_COMPLETE',scratch_restored=True,controlled_reset_run_commanded=True,
        limitation='Debugger/Flash algorithms may disturb execution context; controlled reset/run follows reads. UART boot acceptance is separate.')
except Exception as exc:
    report.update(outcome='INCOMPLETE',error=type(exc).__name__+': '+str(exc))
    raise
finally:
    server.terminate()
    try: server.wait(timeout=5)
    except subprocess.TimeoutExpired: server.kill();server.wait(timeout=5)
    log.close()
    d.save(out/'report.json',report)
    print(json.dumps(report.get('readback',report),indent=2),flush=True)
