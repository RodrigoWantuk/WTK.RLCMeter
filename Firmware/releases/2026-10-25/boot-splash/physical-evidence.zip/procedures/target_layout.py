"""Derive RAM layout with the pinned Arm compiler; no target access."""
import json
from pathlib import Path
import re
import subprocess
root=Path(__file__).resolve().parent
arm=Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin')
keys={
 'view':'offsetof(app_product_t, view)',
 'view_state':'offsetof(ui_product_view_t, state)',
 'cal_valid':'offsetof(ui_product_view_t, calibration_active_valid)',
 'runtime_kind':'offsetof(app_product_t, runtime_kind)',
 'update_state':'offsetof(app_resource_update_t, state)',
 'update_error':'offsetof(app_resource_update_t, last_error)',
 'update_bytes':'sizeof(app_resource_update_t)',
 'measurement_state':'offsetof(app_measurement_session_t, state)',
 'attempt_started':'offsetof(app_measurement_session_t, attempt_started)',
 'flash_operation':'offsetof(w25q_device_t, operation)',
 'flash_capacity':'offsetof(w25q_device_t, part)+offsetof(w25q_part_info_t, capacity_bytes)',
 'workspace_owner':'offsetof(app_io_workspace_t, owner)',
 'workspace_bytes':'sizeof(app_io_workspace_t)',
 'splash_state':'offsetof(ui_boot_splash_t, state)',
 'splash_visible':'offsetof(ui_boot_splash_t, visible_ms)',
 'splash_started':'offsetof(ui_boot_splash_t, started_ms)',
 'splash_pixels_remaining':'offsetof(ui_boot_splash_t,image)+offsetof(ui_image_rle_op_t,pixels_remaining)',
}
source='#include <stddef.h>\n'+''.join('#include "'+h+'"\n' for h in ('app/app_product.h','app/app_resource_update.h','app/app_io_workspace.h','ui/ui_boot_splash.h','drivers/w25q.h'))
source+='const unsigned int offsets[] = {\n'+',\n'.join(keys.values())+'\n};\n'
(root/'layout.c').write_text(source,encoding='ascii')
def derive(case):
    asm=root/(case+'-layout.s')
    subprocess.run([str(arm/'arm-none-eabi-gcc.exe'),'-std=c17','-mcpu=cortex-m3','-mthumb','-S',str(root/'layout.c'),'-I','Firmware/src','-I',str(root/case/'generated'),'-o',str(asm)],check=True)
    values=[int(x) for x in re.findall(r'^\s*\.word\s+(\d+)',asm.read_text(),re.M)]
    if len(values)!=len(keys): raise ValueError('Incomplete compiler layout')
    nm=subprocess.check_output([str(arm/'arm-none-eabi-nm.exe'),'-n',str(root/case/'WTK.RLCMeter.elf')],text=True)
    symbols={name:int(addr,16) for addr,name in re.findall(r'^([0-9a-f]+) [A-Za-z] (\S+)$',nm,re.M)}
    result=dict(offsets=dict(zip(keys,values)),symbols=symbols)
    (root/(case+'-layout.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result
if __name__=='__main__':
    for case in ('factory-release','bringup'): derive(case)
