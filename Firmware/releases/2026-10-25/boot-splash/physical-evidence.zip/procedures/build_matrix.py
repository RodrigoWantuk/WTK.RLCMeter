import concurrent.futures
import json
from pathlib import Path
import subprocess
import hashlib
import sys
import zipfile

root=Path(__file__).resolve().parent
repo=Path.cwd()
sys.path.insert(0,str(repo/'Firmware/tools'))
import pc_firmware_deploy as deploy
before=deploy.source_state()
if before['dirty']: raise ValueError('Final matrix requires clean committed source')
cases=[('product-release','stm32-release',[]),
       ('bringup','stm32-bringup',[]),
       ('product-debug','stm32-debug',[]),
       ('factory-release','stm32-factory-release',[]),
       ('factory-debug','stm32-factory-debug',[]),
       ('bringup-cal','stm32-bringup-cal',[]),
       ('bench-supply','stm32-bringup',['-DWTK_BRINGUP_BENCH_SUPPLY=ON']),
       ('k1-test','stm32-bringup',['-DWTK_BRINGUP_K1_TEST=ON']),
       ('peripheral','stm32-bringup',['-DWTK_BRINGUP_PERIPHERAL_TEST=ON'])]
def run(case):
    name,preset,flags=case
    folder=root/name
    commands=[['cmake','--preset',preset,'-B',str(folder),'-DWTK_WARNINGS_AS_ERRORS_STM32=ON']+flags,
              ['cmake','--build',str(folder),'-j','4']]
    result=dict(name=name,preset=preset,commands=commands,status='PASS')
    with (root/(name+'.log')).open('w',encoding='utf-8') as log:
        for cmd in commands:
            proc=subprocess.run(cmd,cwd=repo/'Firmware',stdout=log,stderr=subprocess.STDOUT)
            if proc.returncode:
                result['status']='FAIL';result['returncode']=proc.returncode;break
    print(name,result['status'],flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(run,cases))
(root/'build-matrix.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
if any(item['status']!='PASS' for item in results): raise SystemExit(1)
if deploy.source_state()!=before: raise ValueError('Source changed during final matrix')
report=dict(source=before,calibration_hardware_revision=0x00010002,
    status='SOFTWARE_BUILDS_PASS_REQUIRES_BENCH_VALIDATION',cases=[])
for name,preset,flags in cases:
    folder=root/name
    config=deploy.parse_config((folder/'generated/wtk_build_config.h').read_bytes())
    if config['WTK_GIT_COMMIT']!=before['git_sha'][:12]: raise ValueError('Stale source identity')
    sizes=json.loads((folder/'WTK.RLCMeter.size.json').read_text())
    files={}
    for suffix in ('bin','elf','hex','map'):
        path=folder/('WTK.RLCMeter.'+suffix)
        files[path.name]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    report['cases'].append(dict(name=name,preset=preset,options=flags,profile=config['WTK_FIRMWARE_PROFILE'],
        factory=config['WTK_PRODUCT_FACTORY_PROVISIONED'],flash_bytes=sizes['flash_bytes'],
        ram_accounted_bytes=sizes['ram_accounted_bytes'],status='PASS',files=files))
(root/'firmware-builds.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
with zipfile.ZipFile(root/'firmware-boot-splash-20261024.zip','w',zipfile.ZIP_DEFLATED) as bundle:
    bundle.write(root/'firmware-builds.json','firmware-builds.json')
    for item in report['cases']:
        for filename in item['files']:
            bundle.write(root/item['name']/filename,item['name']+'/'+filename)
    bundle.writestr('README.txt','Source '+before['git_sha']+'\nCalibration hardware0x00010002.\nSoftware builds passed; physical qualification/calibration remains required.\nPRODUCT preserves battery/charger/residual/calibration gates.\nNo automatic deployment. BRINGUP variants are engineering diagnostics.\n')
print('Final source-bound report and firmware ZIP ready',flush=True)
