"""Rebind the proven read-only W25Q routine to the verified updated BRINGUP."""
from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parent
layout=json.loads((root/'bringup-layout.json').read_text());s=layout['symbols'];o=layout['offsets']
def sym(name):
 values=[v for k,v in s.items() if k==name or k.startswith(name+'.lto_priv.')]
 if len(values)!=1: raise ValueError('Ambiguous binding '+name)
 return values[0]
image=json.loads((root/'final-image/manifest.json').read_text())
deploy=json.loads((root/'final-deployment/deployment.json').read_text())
if deploy['outcome']!='INTERNAL_FLASH_VERIFIED': raise ValueError('No verified final firmware')
source=Path('Firmware/build/assets-install-20261024/read_external.py').read_text(encoding='utf-8')
source=source.replace("bringup=root.parent/'battery-start-20261024'",'bringup=root')
source=source.replace("manifest=bringup/'image/manifest.json'","manifest=bringup/'final-image/manifest.json'")
source=source.replace('e4af20eff8f4e06de291fd2c06e5de1437517ad0f0364da253a736f6f244876a',image['files']['firmware.bin']['sha256'])
source=source.replace('9c6e1a70bfc7f118104ad70ffcc0043ebf59cc6ccf85eb531241b54406d810f1',deploy['readback']['full_flash_sha256'])
source=source.replace("bringup/'assets-preflight-001/report.json'","bringup/'boot-final-first/report.json'")
source=source.replace("pre['outcome']!='EXPECTED_PASSIVE_STATE_OBSERVED'","pre['outcome']!='PASSIVE_STATUS_COLLECTED'")
source=source.replace('[(0,24576),(0x3f8000,32768)]','[(0,106496),(0x3f8000,32768)]')
flash=sym('g_flash');workspace=sym('g_io_workspace')
mapping={0x20000e7c:flash,0x20000e84:flash+o['flash_capacity'],0x20000e8c:flash+o['flash_operation'],
 0x20000f20:workspace,0x20001b20:workspace+o['workspace_owner'],0x20001b24:workspace+o['workspace_bytes'],
 0x08001031:sym('w25q_device_read')|1,0x20000050:sym('g_quiet_requested')}
source=re.sub(r'0x[0-9a-fA-F]+',lambda match:hex(mapping.get(int(match[0],16),int(match[0],16))),source)
needle='for condition,message in conditions:'
extra="conditions += "+repr([(f'*(unsigned char*)0x{value:x} != 0','Peripheral owner busy') for key,value in s.items() if key.startswith('g_acquired.')])+"\n"
source=source.replace(needle,extra+needle)
# Every address change is derived from the exact ELF and compiler layout above.
(root/'readback-rebound.py').write_text(source,encoding='utf-8')
sys.argv=[str(root/'readback-rebound.py'),'after']
exec(compile(source,str(root/'readback-rebound.py'),'exec'))
