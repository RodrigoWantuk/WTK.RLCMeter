"""Wait for actual shared presentation completion before passive UART queries."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
if len(sys.argv)!=2 or sys.argv[1] not in ('first','after-readback'): raise ValueError('Bounded stage required')
original=Path('Firmware/build/battery-start-20261024/boot_passive.py')
source=original.read_text(encoding='utf-8')
source=source.replace("root = Path(__file__).resolve().parent", "root = Path('Firmware/build/splash-20261024').resolve()")
source=source.replace("root/'deployment-001/deployment.json'", "root/'final-deployment/deployment.json'")
source=source.replace("root/'image/manifest.json'", "root/'final-image/manifest.json'")
source=source.replace("out = root/'boot-passive-001'", "out = root/'boot-final-"+sys.argv[1]+"'")
source=source.replace('    time.sleep(0.5)\n    for command', '''    # Console admission follows the shared splash, not merely the early banner.
    deadline = time.monotonic()+35
    for _ in range(70):
        value = get_line(deadline)
        if value == 'display: READY': break
        b.startup_line(reader, value)
    else:
        raise ValueError('No post-splash display-ready admission')
    time.sleep(0.5)
    for command''')
exec(compile(source,str(original),'exec'))
