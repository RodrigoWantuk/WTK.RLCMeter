"""Preserve first LOAD group and battery policy; no device commands."""
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl

root=Path(__file__).resolve().parent
report=d.load(root/'load-10-001/report.json')
if report['outcome'] != 'ALL_3_LOAD_CAPTURES_ACCEPTED':
    raise ValueError('Complete 10-ohm LOAD group required')
identity=report['identity']
endpoints=d.load(root/'same-image-endpoints.json')
loads=d.load(root/'load-10-001/captures.json')
c.verify_campaign(endpoints,identity)
c.verify_campaign(loads,identity)
expected={k for k in pc_osl.KEYS if k.rref_ohms==10}
if len(loads['captures']) != 3 or {pc_osl.Key.from_json(r['condition']) for r in loads['captures']} != expected:
    raise ValueError('Exactly three 10-ohm keys required')
merged=root/'same-image-through-load-10.json'
if merged.exists():
    raise ValueError('Refusing to overwrite checkpoint')
for row in endpoints['captures']+loads['captures']:
    document=c.save_capture(merged,row)
solutions=[]
for key in sorted(expected):
    group=[pc_osl.standard_from_capture(r) for r in document['captures'] if r['condition']==key.as_json()]
    solution=pc_osl.solve(group)
    solutions.append(dict(condition=key.as_json(), fit_channel=solution.fit_channel,
        hg_observed=solution.hg_observed,min_separation=solution.min_separation,
        serialized_float32_values=solution.values()))
if len(document['captures']) != 69:
    raise ValueError('69 original observations required')
policy=dict(check_before_each_new_resistor=True, request_charging_if_low=True,
    nominal_low_threshold_v=3.5, no_measurement_while_charging=True,
    no_charge_percentage_or_runtime_claim=True,
    owner_instruction='Sempre antes de prosseguir cada novo valor de resistor, vamos fazer um check de bateria, e se estiver baixa, voce me pede pra carregar')
release=Path('Firmware/releases/2026-10-25/osl-load-10-checkpoint')
release.mkdir(exist_ok=False)
archive_path=release/'physical-evidence.zip'
with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ('load-10-001','battery-before-load-10-001','battery-before-load-100-001','battery-before-load-100-002'):
        for p in sorted((root/folder).rglob('*')):
            if p.is_file(): z.write(p,str(p.relative_to(root)).replace('\\','/'))
    for name in ('capture_load_10.py','read_battery_before_load_10.py',
                 'read_battery_before_load_100.py','read_battery_before_load_100_paced.py',
                 'archive_load_10_checkpoint.py','same-image-through-load-10.json',
                 'references-owner-evidence.json'):
        z.write(root/name,name)
with zipfile.ZipFile(archive_path) as z:
    if z.testzip() is not None or len(z.namelist())!=len(set(z.namelist())):
        raise ValueError('Archive verification failed')
checkpoint=dict(recorded_utc=d.utc(), SIMULATED=False,status='LOAD_10_COMPLETE_5_REFERENCE_GROUPS_PENDING',
    identity=identity, observations=69, required_observations=99, complete_conditions=3,
    reference=report['reference'], fresh_owner_dmm_ohms=10.5,
    reference_policy=report['reference_policy'],battery_policy=policy,
    battery_before_10=d.load(root/'battery-before-load-10-001/report.json'),
    battery_before_100=d.load(root/'battery-before-load-100-002/report.json'),
    communication_incident='After all three accepted LOADs, an unpaced read-only STATUS timed out. A paced read-only reconnect succeeded with protocol counter 1, unchanged across that battery read. No START was retried or SWD reset issued.',
    fits=solutions, final_capture_status=report['last_safe_status'],
    installation_status=report['final_installation_status'],calibration_installed=False,
    candidate_generated=False,physically_qualified=False,
    artifact=dict(bytes=archive_path.stat().st_size,sha256=d.sha(archive_path.read_bytes())),
    capture_sha256=d.sha(merged.read_bytes()))
d.save('docs/review/bringup-2026-10-25/OSL-Load-10.json',checkpoint)
Path('docs/review/bringup-2026-10-25/OSL-Load-10.md').write_text('''# First LOAD group — October 25, 2026

Status: LOAD_10_COMPLETE; FIVE_REFERENCE_GROUPS_PENDING; NOT_QUALIFIED.

The owner remeasured the nominal 10-ohm +/-1% resistor: Minipa ET-1100A display
10.5 ohm on the 200-ohm range, then explicitly confirmed direct attachment alone
across TEST_HI/TEST_LO. Printed nominal/tolerance remains the uncertain fit anchor;
the DMM display is consistency evidence. No exact 0.5-ohm lead subtraction or
certified actual resistance is invented.

All three supported 10-ohm conditions (10 Hz / 1 kHz / 10 kHz, 100 mVrms) were
accepted, with six stable repeats, both return channels valid, zero clipping,
observed HG overlap, SAFE teardown and no new protocol errors during capture.
The strict solver accepted all three same-source-7017e5e0 OPEN/SHORT/LOAD triplets
and their float32 fit checks. This is fit consistency, not independent accuracy
validation. There are now 69/99 observations and 3/33 complete conditions.
No complete candidate was generated or installed; active calibration remains blank.

At the owner's request, check battery before every new resistor value. LOW starts
at nominal 3.50 V; request charging if LOW/CRITICAL, and investigate UNKNOWN rather
than starting that group. Charger interlock is unchanged. The pre-10 reading was
3.71824 V, OK. The pre-100 reading was 3.71663 V, OK. Both are fresh SAFE/idle
nominal-ADC readings, not charge-percentage or runtime estimates.

After the LOAD sweep, an unpaced read-only STATUS request timed out before SWD.
A paced read-only reconnect succeeded; protocol counter was 1 before and after
that battery snapshot, fault mask zero and SAFE/idle confirmed. Both attempts
are retained. No measurement START was replayed and no reset was issued.

The owner has been asked to remeasure and attach the 100-ohm reference next.
Other LOADs, independent holdouts, oscilloscope-dependent checks and installation
remain pending. Final leads require calibration in their final geometry.

See [structured checkpoint](OSL-Load-10.json),
[physical evidence](../../../Firmware/releases/2026-10-25/osl-load-10-checkpoint/README.md)
and [the prior endpoint checkpoint](OSL-Same-Image-Endpoints.md).
''',encoding='utf-8')
(release/'README.md').write_text('''# 10-ohm LOAD checkpoint

`physical-evidence.zip` preserves the three LOAD artifacts and fits, 69-observation
canonical document, fresh owner reading/connection, battery policy and both
pre-100 battery-query attempts. CRCs, identities and SHA-256 were verified.
No complete candidate or calibration installation is included.

See [bench report](../../../../docs/review/bringup-2026-10-25/OSL-Load-10.md).
''',encoding='utf-8')
print(json.dumps(dict(status=checkpoint['status'],observations=69,complete_conditions=3,artifact=checkpoint['artifact']),indent=2))
