from pathlib import Path
import json,zipfile,hashlib
r=Path('Firmware/build/calibration-20261025');o=Path('Firmware/releases/2026-10-25/low-impedance-search')
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
a=load(r/'low-z-inductor-047-diagnostic-001/report.json');v=a['values'];p=load(r/'low-z-inductor-047-postflight-001/report.json');m=p['metadata']
assert a['firmware_sha256']=='c8196f18daa7934243bfaf8303c03260d267cfdacf14b7c8efb2fd17b75d1fb9'
assert v['session_sequence']==1 and v['runtime.measurement.policy.attempt_count']==4
assert v['attempt3.config.frequency']==2 and v['attempt3.config.range_id']==0 and v['attempt3.config.reason']==5
assert not v['ui.inductance_valid'] and not v['ui.capacitance_valid'] and v['ui.interpretation']==3
assert m['k1_commanded_state']==1 and not any(m[k] for k in ['range_enabled','excitation_mode','quiet_requested','safety_fault_mask'])
assert m['calibration_sequence']==1 and m['calibration_record_count']==33 and m['calibration_active_valid']==1
zpath=o/'low-z-physical-evidence.zip'
assert not zpath.exists()
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for name in ['low-z-inductor-047-diagnostic-001','low-z-inductor-047-postflight-001']:
  for f in (r/name).rglob('*'):
   if f.is_file():z.write(f,str(f.relative_to(r)))
 for name in ['read_low_z_inductor_047.py','check_low_z_inductor_047_postflight.py','package_low_z_physical_check.py']:
  z.write(r/name,'procedures/'+name)
attempts=[]
for i in range(4):
 pre='attempt'+str(i)+'.'
 attempts.append(dict(index=i,frequency_hz=[10,1000,10000][v[pre+'config.frequency']],rref_ohms=[10,100,1000,10000,100000,1000000][v[pre+'config.range_id']],reason=v[pre+'config.reason'],r_ohm=v[pre+'z_ohms.re'],x_ohm=v[pre+'z_ohms.im'],return_peak_v=v[pre+'return_peak_v'],dsp_status=v[pre+'dsp_status'],calibration_sequence=v[pre+'calibration.set_sequence'],safety_abort=v[pre+'safety_abort'],derived_interpretation=v[pre+'derived.interpretation']))
c=load(o/'checkpoint.json');c.update(status='EXTRA_FREQUENCY_SEARCH_PHYSICALLY_OBSERVED_SUB_UH_UNRESOLVED',physical_check=dict(session=1,fixture='Owner-confirmed isolated nominal 0.47uH inductor, short OK after new-image READY preflight',attempts=attempts,primary_attempt_index=2,final_classification='MIXED_OR_UNKNOWN',inductance_published=False,capacitance_published=False,secondary_10khz_candidate_inductance_h=v['attempt3.derived.inductance_h'],candidate_is_qualified=False),post_measurement_metadata=m)
c['archives'][zpath.name]=hashlib.sha256(zpath.read_bytes()).hexdigest();(o/'checkpoint.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
p=o/'README.md';s=p.read_text(encoding='utf-8').replace('Physical extra-frequency capture on the same nominal 0.47-uH part is pending\nan owner-triggered Click.','Physical extra-frequency capture on the same nominal 0.47-uH part is now\nobserved after an owner-triggered Click; the inductance remains unresolved.')
s+='''
## Actual four-attempt check

The owner reports multiple K1 clicks, consistent with the unchanged full
SAFE-to-MEASURE-to-SAFE transaction for each attempt. One user-triggered Click
completed PRODUCT session 1 with four attempts, all at 100 mVrms and HG return:

| Attempt | RREF | Frequency | R (ohm) | X (ohm) | Return peak |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1 | 1 kohm | 1 kHz | -3.383367 | -1.153787 | 0.1245 mV |
| 2 | 100 ohm | 1 kHz | 0.162799 | -0.140749 | 1.0915 mV |
| 3 | 10 ohm | 1 kHz | 0.322007 | -0.007154 | 9.3050 mV |
| 4 | 10 ohm | 10 kHz | 0.245470 | 0.021326 | 5.8751 mV |

The new CHECK_SECOND_FREQUENCY attempt is physically observed at index 3.
The primary remains index 2. The 10-kHz candidate X/(2*pi*f) is 0.339413 uH,
but |X|/|R| is about 0.087, still resistance-dominated under the unchanged
thresholds. No L or C is published; the final session is MIXED/UNKNOWN.
The full classifier currently also includes the early weak-return, reranged
attempts, whose capacitive classification conflicts with the later resistive
ones. Evidence admission for classification is a follow-up issue, not silently
changed or omitted from this record. The candidate must not be reported as a
successful 0.47-uH measurement or an absolute accuracy result.

All four DSP statuses are OK, calibration sequence 1 is used, no clipping or
safety abort is reported. Final read-only metadata/image verification confirms
K1 SAFE, range/excitation OFF, quiet released, zero faults and the same active
33-record calibration. No firmware/calibration was rewritten for this check.
No software tests were rerun because no code changed. Actual attempt history,
raw context, exact Flash-image/ABI verification and SAFE teardown are preserved
in low-z-physical-evidence.zip. Session-wide K1 holding remains unimplemented.
''';p.write_text(s,encoding='utf-8')
p=Path('plans/23-Bounded-Low-Impedance-Search.md');s=p.read_text(encoding='utf-8').replace('capture remains pending; no sub-microhenry success is claimed. See','capture was pending at deployment; the subsequent check below completes this\nsearch observation without claiming sub-microhenry success. See')
s+='''
## Owner-triggered extra-frequency observation

Session 1 on the same nominal 0.47-uH part completed four attempts: RREF
1k/100/10 ohm at 1 kHz, then 10 ohm at 10 kHz. This confirms the added search
branch. At 10 kHz, R=0.245470 ohm and X=+0.021326 ohm give a raw 0.339413-uH
candidate; the ratio |X|/|R| remains resistance-dominated, and L/C are not
published. Full-session classification is MIXED/UNKNOWN, including conflicting
capacitive evidence from early weak-return/reranged attempts. Evidence admission
for classification deserves separate review; no small-L capability is qualified.
The owner's multiple relay clicks correspond to the retained per-attempt safety
transaction. Postflight confirms K1 SAFE, zero faults, all excitation/ranges OFF
and unchanged 33-record calibration. No further code or calibration change.
''';p.write_text(s,encoding='utf-8')
for filename in ['README.md','docs/README.md']:
 p=Path(filename);s=p.read_text(encoding='utf-8').replace('Physical extra-frequency capture is pending.','Four actual attempts now include 10 kHz; the nominal 0.47-uH result remains\ninconclusive, with no published L.').replace('Actual\nextra-frequency capture is pending;','Actual\nfour-attempt search now includes 10 kHz but leaves the nominal 0.47-uH result\ninconclusive, with no published L;');p.write_text(s,encoding='utf-8')
print(json.dumps({'status':c['status'],'attempts':attempts,'candidate_uh':v['attempt3.derived.inductance_h']*1e6,'safe':True},indent=2))
