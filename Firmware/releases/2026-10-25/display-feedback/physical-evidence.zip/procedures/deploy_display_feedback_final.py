"""Package and program the existing tested PC-provisioned PRODUCT image.
No acquisition START, calibration write or external-flash mutation.
"""
import json,sys,hashlib,subprocess,time
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import pc_bringup as b
import pc_cal_capture as c
from pc_osl_install import Installer,validate_candidate
root=Path(__file__).resolve().parent
builds=root/'verified-builds-display-feedback-final'
matrix=d.load(builds/'firmware-builds.json')
ref=matrix['source']['git_sha']
if subprocess.check_output(['git','diff',ref,'HEAD','--','Firmware/src','Firmware/config','Firmware/cmake','Firmware/CMakeLists.txt','Firmware/CMakePresets.json']):raise ValueError('Embedded source changed since verified matrix')
case=next(v for v in matrix['cases'] if v['name']=='factory-release')
if case['status']!='PASS' or case['profile']!='PRODUCT' or case['factory']!='1u':raise ValueError('PC-provisioned production build required')
for n,meta in case['files'].items():
 if hashlib.sha256((builds/'factory-release'/n).read_bytes()).hexdigest()!=meta['sha256']:raise ValueError('Verified build changed')
imagepath=root/'image-display-feedback-002'
if imagepath.exists():raise ValueError('Do not reuse an image output directory')
image=d.manifest(builds/'factory-release',imagepath,'FACTORY_PRODUCT',matrix['source'],'stm32-factory-release')
image=d.inspect(imagepath/'manifest.json','FACTORY_PRODUCT')
subprocess.run([sys.executable,str(root/'preflight_display_feedback_final.py')],check=True)
pre=d.load(root/'pre-display-feedback-002/report.json')
if not pre['exact_running_image_match'] or pre['metadata']['calibration_sequence']!=1 or not pre['metadata']['calibration_active_valid']:
 raise ValueError('Fresh post-power calibration and SAFE metadata required')
identity=dict(uid=pre['target']['uid'])
frame=(root/'condition-composition-003/candidate.bin').read_bytes();validate_candidate(frame)
if hashlib.sha256(frame).hexdigest()!='af76d19b15a510dff0c880a4ab6e86893e0065ac7e845b9930111680752da78c':raise ValueError('Canonical calibration evidence changed')
auth=dict(operator='Rodrigo; owner-directed continuation into calibrated production without another resistor campaign',utc=d.utc(),board='First Rev1 board, six RGS gate-to-GND rework',expected_uid=identity['uid'],SIMULATED=False,previous_profile='FACTORY_PRODUCT',next_profile='FACTORY_PRODUCT',image_sha256=image['files']['firmware.bin']['sha256'],manifest_seal=image['seal_sha256'],approval_origin='Owner requested next step without resistor tests and explicitly resumed after power interruption; programming and initial pilot are preserved; this image restores normal TFT speed, coalesces READY redraw and improves the default brightness',scope='Controlled calibrated PRODUCT handoff; internal Flash only; preserve exact active OSL sequence1, W25Q assets/settings and experimental UID-bound NTC; no DUT measurement commanded',physical_qualification=False,procedural_exception=dict(owner_requested_proceed_without_scope=True,scope_checks='NOT_TESTED; no new physical qualification inferred',b01_gate='Independent scope/hardware qualification remains pending'),preflight_path=str(root/'pre-display-feedback-002/report.json'),supply='Previously owner-confirmed battery/boost; latest battery voltage 3.873 V was read over serial before PRODUCT; fresh pre-program metadata rejects any supply/charger/fault blockers; no battery voltage read over SWD',preservation='No external W25Q erase/program requested',ntc_factory_profile=image['ntc_factory_profile'],osl=dict(sequence=1,sha256=hashlib.sha256(frame).hexdigest(),preserved_physical_readback=str(root/'product-deploy-preflight-readback.bin'),post_power_runtime_sequence=pre['metadata']['calibration_sequence']),acknowledgements=dict(safe_outputs=True,debug_halt_watchdog=True,no_app_bootloader=True,internal_flash=True))
auth['seal_sha256']=d.seal(auth);d.save(root/'deployment-display-feedback-authorization-002.json',auth)
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
record=d.deployment('program',imagepath/'manifest.json',backend,root/'deployment-display-feedback-002',authorization=auth,uid=identity['uid'])
print(json.dumps({k:record.get(k) for k in ('outcome','readback','error')},indent=2),flush=True)
if record['outcome']!='INTERNAL_FLASH_VERIFIED':raise SystemExit(1)
