"""Decode compiler-derived workflow statistics from already saved RAM only."""
import json
import math
from pathlib import Path
import re
import struct
import subprocess
import sys
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
root=Path(__file__).resolve().parent
out=root/'post-campaign-ram-001'
build=root/'verified-builds-zero-short/bringup-cal'
snapshot=d.load(out/'report.json')
capture=d.load(root/'load-1000000-001/report.json')
if snapshot['before_status']['capture_id']!=capture['last_safe_status']['capture_id']:
    raise ValueError('RAM no longer describes the final recorded LOAD')
arm=Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin')
base='offsetof(app_calibration_service_t,workflow)+offsetof(app_calibration_workflow_t,evidence)'
fields={name:(base+f'+offsetof(app_cal_evidence_t,{name})','B') for name in
    ('accepted','rejected','attempts','ret_1x_evidence_valid','ret_hg_evidence_valid','hg_overlap_valid')}
for path in ('ret_1x_path','ret_hg_path'):
    for member in ('sample_count','usable_count','rejected_count','stable','insufficient','evidence_valid'):
        fields[path+'.'+member]=(base+f'+offsetof(app_cal_evidence_t,{path})+offsetof(app_cal_path_evidence_t,{member})','B')
stats=('source_1','source_2','z_1x','z_hg','hg_observed_transfer')
for name in stats:
    prefix=base+f'+offsetof(app_cal_evidence_t,{name})'
    for member,fmt in (('count','B'),('m2_re','f'),('m2_im','f')):
        fields[name+'.'+member]=(prefix+f'+offsetof(app_cal_complex_stats_t,{member})',fmt)
    for member in ('re','im'):
        fields[name+'.mean_'+member]=(prefix+f'+offsetof(app_cal_complex_stats_t,mean)+offsetof(measurement_complex_t,{member})','f')
(out/'stats-layout.c').write_text('#include <stddef.h>\n#include "app/app_cal_capture_service.h"\nconst unsigned int offsets[]={'+','.join(v[0] for v in fields.values())+'};\n',encoding='ascii')
subprocess.run([str(arm/'arm-none-eabi-gcc.exe'),'-std=c17','-mcpu=cortex-m3','-mthumb','-S',str(out/'stats-layout.c'),'-I','Firmware/src','-I',str(build/'generated'),'-o',str(out/'stats-layout.s')],check=True)
offsets=[int(n) for n in re.findall(r'^\s*\.word\s+(\d+)',(out/'stats-layout.s').read_text(),re.M)]
if len(offsets)!=len(fields): raise ValueError('Compiler layout incomplete')
nm=subprocess.check_output([str(arm/'arm-none-eabi-nm.exe'),'-n',str(build/'WTK.RLCMeter.elf')],text=True)
symbols={name:int(addr,16) for addr,name in re.findall(r'^([0-9a-f]+) [A-Za-z] (\S+)$',nm,re.M)}
raw=(out/'ram.bin').read_bytes()
values={name:struct.unpack_from('<'+fmt,raw,symbols['calibration']-0x20000000+offset)[0]
        for (name,(_,fmt)),offset in zip(fields.items(),offsets)}
summary={}
for name in stats:
    count=values[name+'.count']
    mean=complex(values[name+'.mean_re'],values[name+'.mean_im'])
    variance=(values[name+'.m2_re']+values[name+'.m2_im'])/(count-1) if count>1 else 0
    summary[name]=dict(count=count,mean=[mean.real,mean.imag],complex_std=math.sqrt(max(0,variance)),
        relative_std_pct=100*math.sqrt(max(0,variance))/abs(mean) if abs(mean)>0 else None)
report=dict(recorded_utc=d.utc(),operation='OFFLINE_SAVED_RAM_STATISTICS',condition=dict(rref_ohms=1000000,frequency_hz=10000,amplitude_mvrms=500),
    capture_id=capture['last_safe_status']['capture_id'],ram_sha256=d.sha(raw),values=values,
    statistics=summary,stability_limit_pct=2.0,physically_qualified=False)
d.save(out/'statistics.json',report)
print(json.dumps(dict(counts={k:v for k,v in values.items() if '.' not in k},statistics=summary),indent=2))
