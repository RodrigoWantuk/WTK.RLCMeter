	.cpu cortex-m3
	.arch armv7-m
	.fpu softvfp
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 6
	.eabi_attribute 34, 1
	.eabi_attribute 18, 4
	.file	"stats-layout.c"
	.text
	.global	offsets
	.section	.rodata
	.align	2
	.type	offsets, %object
	.size	offsets, 172
offsets:
	.word	5444
	.word	5445
	.word	5446
	.word	5464
	.word	5465
	.word	5466
	.word	5467
	.word	5468
	.word	5469
	.word	5470
	.word	5471
	.word	5472
	.word	5473
	.word	5474
	.word	5475
	.word	5476
	.word	5477
	.word	5478
	.word	5520
	.word	5532
	.word	5536
	.word	5524
	.word	5528
	.word	5540
	.word	5552
	.word	5556
	.word	5544
	.word	5548
	.word	5700
	.word	5712
	.word	5716
	.word	5704
	.word	5708
	.word	5720
	.word	5732
	.word	5736
	.word	5724
	.word	5728
	.word	5680
	.word	5692
	.word	5696
	.word	5684
	.word	5688
	.ident	"GCC: (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119"
