#include <stddef.h>
#include "hardware/hw_aux_sensors.h"
const unsigned int offsets[]={offsetof(hw_aux_sensors_t,snapshot)+offsetof(hw_aux_sensors_snapshot_t,battery_v),offsetof(hw_aux_sensors_t,snapshot)+offsetof(hw_aux_sensors_snapshot_t,battery_raw),offsetof(hw_aux_sensors_t,snapshot)+offsetof(hw_aux_sensors_snapshot_t,battery_state),offsetof(hw_aux_sensors_t,battery_timestamp_ms),offsetof(hw_aux_sensors_t,battery_published),offsetof(hw_aux_sensors_t,paused),offsetof(hw_aux_sensors_t,snapshot)+offsetof(hw_aux_sensors_snapshot_t,vmid_v),offsetof(hw_aux_sensors_t,fault_mask)};
