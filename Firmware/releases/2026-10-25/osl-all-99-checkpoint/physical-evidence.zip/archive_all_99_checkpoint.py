"""Archive all captures and reproduced gain-observability failures; offline only."""
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_cal_capture as c
import pc_firmware_deploy as d
import pc_osl as o

root=Path(__file__).resolve().parent
audit=d.load(root/'all-99-fit-audit.json')
document=d.load(root/'same-image-all-99.json')
report=d.load(root/'load-1000000-001/report.json')
diagnostic=d.load(root/'open-009/captures.json')
diag_report=d.load(root/'open-009/report.json')
identity=audit['identity']
for doc in (document,diagnostic): c.verify_campaign(doc,identity)
if len(document['captures'])!=99 or report['outcome']!='ALL_6_LOAD_CAPTURES_SAVED' or diag_report['outcome']!='ALL_3_DIAGNOSTIC_OPEN_CAPTURES_ACCEPTED':
    raise ValueError('Complete preserved campaign and diagnostic required')
reproduced=[]
for opened in diagnostic['captures']:
    triplet=[o.standard_from_capture(r) for r in document['captures'] if r['condition']==opened['condition'] and r['standard']!='OPEN']+[o.standard_from_capture(opened)]
    try: o.solve(triplet)
    except ValueError as exc:
        reproduced.append(dict(condition=opened['condition'],error=str(exc),open_quality=opened['quality'],replacement_applied=False))
    else: raise ValueError('Diagnostic unexpectedly resolved fit; review before claiming continued blockage')
if len(reproduced)!=3 or audit['solvable']!=30: raise ValueError('Unexpected coverage')
stats=d.load(root/'post-campaign-ram-001/statistics.json')
release=Path('Firmware/releases/2026-10-25/osl-all-99-checkpoint')
release.mkdir(exist_ok=False)
archive=release/'physical-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ('load-1000000-001','battery-before-load-1000000-002','post-campaign-ram-001','open-009'):
        for p in sorted((root/folder).rglob('*')):
            if p.is_file(): z.write(p,str(p.relative_to(root)).replace('\\','/'))
    for name in ('capture_load_1000000.py','read_battery_before_load_1000000_fresh.py',
                 'read_post_campaign_ram.py','analyze_post_campaign_stats.py',
                 'capture_open_gain_diagnostic.py','archive_all_99_checkpoint.py',
                 'same-image-all-99.json','all-99-fit-audit.json'):
        z.write(root/name,name)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or len(z.namelist())!=len(set(z.namelist())): raise ValueError('Archive verification failed')
checkpoint=dict(recorded_utc=d.utc(),SIMULATED=False,status='ALL_99_CAPTURED_30_FITS_VALID_3_GAIN_OBSERVABILITY_BLOCKED',
    identity=identity,observations=99,diagnostic_open_repeats=3,solvable_conditions=30,
    complete_triplets=33,blocked=audit['blocked'],diagnostic_results=reproduced,
    reference=report['reference'],fresh_owner_dmm_ohms=996000.0,
    owner_confirmation='996k na leitura de hoje, conectado',reference_policy=report['reference_policy'],
    statistics=stats,battery_before_1M=report['battery_check'],
    final_status=diag_report['last_safe_status'],installation_status=diag_report['final_installation_status'],
    candidate_generation='BLOCKED_BY_STRICT_SOLVER',candidate_generated=False,calibration_installed=False,
    physically_qualified=False,scope_checks='NOT_TESTED; owner-directed engineering campaign',
    next_work='Investigate high-Z 10-kHz path/gain observability; owner-authorized one-point NTC comparison pending stable external temperature. No thermometer model requested or stored.',
    capture_sha256=d.sha((root/'same-image-all-99.json').read_bytes()),
    artifact=dict(bytes=archive.stat().st_size,sha256=d.sha(archive.read_bytes())))
d.save('docs/review/bringup-2026-10-25/OSL-All-99.json',checkpoint)
Path('docs/review/bringup-2026-10-25/OSL-All-99.md').write_text('''# Complete capture campaign, incomplete calibration — October 25, 2026

Status: ALL_99_CAPTURED; 30_FITS_VALID; THREE_GAIN_OBSERVABILITY_FAILURES; NOT_QUALIFIED.

The owner freshly measured the final reference as 996 kohm and confirmed direct
attachment alone. Nominal 1 Mohm +/-1% remains an uncertain fit anchor, with
inferred band identification and no certified actual value. All six 1-Mohm raw
captures passed stable acquisition and SAFE teardown; four fits passed and the
two 10-kHz fits remain blocked. No acquisition or safety gate was relaxed.

The preserved same-image source-7017e5e0 cohort contains 33 OPEN, 33 SHORT and
33 LOAD observations. CRC, SHA, nominal ADC provenance and exact device identity
were verified. Thirty triplets pass strict float32 OSL checks. Three do not:

| RREF | Frequency | Amplitude | Missing evidence |
| --- | --- | --- | --- |
| 100 kohm | 10 kHz | 100 mVrms | Actual same-key HG overlap; OPEN/LOAD are HG-only |
| 1 Mohm | 10 kHz | 100 mVrms | Actual same-key HG overlap; OPEN/LOAD are HG-only |
| 1 Mohm | 10 kHz | 500 mVrms | Actual same-key HG overlap; OPEN/LOAD are HG-only |

After the owner removed the final resistor and confirmed OPEN, exactly these
three OPEN conditions were reacquired once. Each again has only HG usable and
no observed HG overlap; the strict fits remain blocked. The original 99 frames
are unchanged. Diagnostic frames are separate, not silent replacements.

A SAFE/idle no-reset RAM snapshot of the last 1-Mohm/10-kHz/500-mVrms LOAD
confirms six accepted blocks, zero rejected blocks and the actual repeatability
gate: 1X impedance relative standard deviation 8.3275%, HG 0.9996%, observed
gain 7.5451%, against the existing 2% stability limit. Source-amplitude dispersions
are 0.1929% and 0.1544%. These are raw repeatability metrics, not accuracy or SNR
qualification. They explain this rejection without assigning a component fault.

The full candidate builder was attempted offline and rejected the missing valid
path. The existing Python and C contracts require actual HG overlap for an HG
fit and a full 33-key Rev.1 set for installation. No candidate was generated or
installed, no flags or coefficients were fabricated, and no gain was borrowed
from another key. The board remains SAFE/idle, zero safety faults, calibration
blank. Protocol counter stayed at 1 throughout both final sweeps. W25Q resources
and mutable calibration slots were not written.

Battery before 1-Mohm capture: 3.70535 V, OK; post-campaign snapshot: 3.70374 V,
OK, nominal ADC scale. The owner requires a check before every new resistor.
The contact thermometer will support a separate one-point NTC comparison next;
no thermometer model is requested or stored. A single point does not determine
Beta or qualify the full temperature curve. Its stable reference reading and
any persistent adjustment are still pending.

High-Z 10-kHz observability/coverage, independent holdouts, scope-dependent checks
and calibration installation remain unfinished. Do not mark the device fully
calibrated or release-qualified based on the 99-frame count.

See [structured audit](OSL-All-99.json),
[physical evidence](../../../Firmware/releases/2026-10-25/osl-all-99-checkpoint/README.md)
and [the first blocked-key checkpoint](OSL-Load-100000.md).
''',encoding='utf-8')
(release/'README.md').write_text('''# Full OSL capture evidence — calibration blocked

The ZIP preserves all 99 original CCO1 observations in the canonical document,
the six final LOAD captures, three separate diagnostic OPEN repeats, wire logs,
strict fit audit and compiler-derived RAM statistics. Thirty fits pass; three
high-Z 10-kHz keys lack observed HG overlap. No complete candidate or installation
is supplied. CRC/SHA and archive checks passed.

See [bench report](../../../../docs/review/bringup-2026-10-25/OSL-All-99.md).
''',encoding='utf-8')
print(json.dumps(dict(status=checkpoint['status'],artifact=checkpoint['artifact']),indent=2))
