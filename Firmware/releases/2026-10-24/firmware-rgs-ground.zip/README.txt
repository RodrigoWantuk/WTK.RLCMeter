Source 0dd1f3fe40ce7e9c68d563bcb80d405042396ead
Calibration hardware0x00010002.
Software builds passed; physical qualification/calibration remains required.
PRODUCT preserves battery/charger/residual/calibration gates.
No automatic deployment. BRINGUP variants are engineering diagnostics.
