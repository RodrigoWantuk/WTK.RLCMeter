WTK.RLCMeter production resources
Schema2/API4; complete EN/PT-BR catalogs, three bitmap fonts and optional READY art.
Pack bytes:22891
SHA256:1048f3baa7942354e1c3d84b9b5cb361e7e3bd7347f221fdc2d3b2660b6ee9b4
Built from tracked resource_manifest.json and linked source JSON. Use the existing PRODUCT PLC1 resource receiver.
This board required paced serial bytes, byte flush, and settling after BEGIN; an unpaced burst was not validated.
Keep calibration/settings partitions intact; this is external W25Q data, not an internal MCU firmware image.
