# Firmware deployment — REAL_BACKEND / NOT PHYSICALLY QUALIFIED

SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.

Outcome: INTERNAL_FLASH_VERIFIED

Programming: CONFIRMED; internal readback: PASS; boot: NOT_TESTED; UART: NOT_TESTED; application: NOT_TESTED.

External W25Q was not accessed. OSL/Resource Pack remain independently accepted prerequisites.

```json
{
  "schema": "WTK_DEPLOYMENT_1",
  "transaction": "e89688f3-7323-4f4c-a69e-4ba2d6f0154e",
  "operation": "program",
  "started_utc": "2026-10-27T03:45:08.445642+00:00",
  "SIMULATED": false,
  "image": {
    "schema": "WTK_FIRMWARE_2",
    "source": {
      "git_sha": "40a0b420ef60003d302b5a8a79c3d53d8c097fc7",
      "dirty": false,
      "git_status": "",
      "input_sha256": "fac57cb2661a1ee643752d9abffc228fd6c65965ab0ffb5bad0988036f65a36b"
    },
    "profile": "FACTORY_PRODUCT",
    "factory_provisioned": true,
    "supplementary_curves": false,
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "bringup_k1_test": false,
    "bringup_bench_supply": false,
    "bringup_peripheral_test": false,
    "preset": "stm32-factory-release",
    "build_configuration": "Release",
    "hardware": "Rev1-STM32F103C8T6-BluePill",
    "firmware_version": "0.1.0",
    "expected_boot": {
      "interface": "LIMITED_UART_UI_REQUIRED",
      "firmware_version": "0.1.0",
      "hardware": "Rev1-STM32F103C8T6-BluePill",
      "git_prefix": null,
      "limitation": "PRODUCT banner is only WTK.RLCMeter SAFE_BOOT; UI/bench acceptance separate"
    },
    "toolchain": {
      "compiler_path": "C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin/arm-none-eabi-gcc.exe",
      "compiler_version": "arm-none-eabi-gcc.exe (Arm GNU Toolchain 14.2.Rel1 (Build arm-14.52)) 14.2.1 20241119",
      "cmake": "cmake version 4.4.4",
      "cache_sha256": "0332a3ebb08c067969d94d26654ab88a8fb0a3a7c895db9152774e0906b3a12b"
    },
    "memory": {
      "flash_base": 134217728,
      "flash_bytes": 65536,
      "ram_base": 536870912,
      "ram_bytes": 20480,
      "internal_page_bytes": 1024
    },
    "linked": {
      "flash_bytes": 61136,
      "bss": 15004,
      "ram_static_bytes": 15052,
      "noinit_bytes": 0,
      "reserved_stack_bytes": 2052,
      "ram_accounted_bytes": 17104
    },
    "binary_size": 61136,
    "files": {
      "firmware.bin": {
        "bytes": 61136,
        "sha256": "b51558edced7660528ae6dc9b898e0242e422ef57af8f013e44f9aa4575343a6"
      },
      "firmware.elf": {
        "bytes": 95600,
        "sha256": "f0272fc89e69031f6551c432c837e5cc28fc43a66713ddf748b79333432e8235"
      },
      "build_config.h": {
        "bytes": 1454,
        "sha256": "81491bd940e5735747e87bc7f51e076336861d12f6d53e4044e6ec1f0e96a9e7"
      },
      "linker.ld": {
        "bytes": 2244,
        "sha256": "1450e7143121ccf933b06af5d728b2ba60d5d41c4592748ff2a7ab77337c53c0"
      }
    },
    "built_utc": "2026-10-27T03:45:06.071186+00:00",
    "seal_sha256": "822e2c551e049c3aa17db84f146abe38de647a85a8d28141dd30c583e57c4c0d",
    "manifest_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\image-continuous-001\\manifest.json",
    "staged_binary": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-continuous-001\\staged-image.bin"
  },
  "authorization": {
    "operator": "Rodrigo",
    "utc": "2026-10-27T03:45:08.356275+00:00",
    "board": "First Rev1 board; six RGS gate-to-GND rework",
    "expected_uid": "54ff70068370525760380567",
    "SIMULATED": false,
    "previous_profile": "FACTORY_PRODUCT",
    "next_profile": "FACTORY_PRODUCT",
    "image_sha256": "b51558edced7660528ae6dc9b898e0242e422ef57af8f013e44f9aa4575343a6",
    "manifest_seal": "822e2c551e049c3aa17db84f146abe38de647a85a8d28141dd30c583e57c4c0d",
    "approval_origin": "Owner explicitly requests one K1 engagement and final release across frequency changes and asks whether seven samples remain; prior standing authorization covers firmware fixes, programming, preservation, Git and PR. Live SAFE preflight precedes controlled internal programming. No remote measurement is initiated.",
    "scope": "Factory PRODUCT continuous three-frequency and seven-point survey, bounded 30s and supervised by actual VMID/BAT sampling outside DMA; preserve exact OSL sequence1/all33, assets/settings and UID NTC. No W25Q mutation or automatic DUT capture.",
    "physical_qualification": false,
    "procedural_exception": {
      "owner_requested_proceed_without_scope": true,
      "scope_checks": "NOT_TESTED; no new accuracy or physical safety qualification inferred"
    },
    "preflight_path": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\pre-continuous-002\\report.json",
    "supply": "Live preflight rejects hard supply/charger/fault blockers; no numeric VBAT read via SWD; no old numeric battery voltage claimed as current",
    "preservation": "Internal Flash only; no external W25Q program/erase",
    "ntc_factory_profile": {
      "schema": "WTK_NTC_COMPILED_V1",
      "profile": {
        "format": "WTK_NTC_FACTORY_PROFILE_V1",
        "uid": "54ff70068370525760380567",
        "qualified": false,
        "owner_authorized": true,
        "thermal_contact_uncertain": true,
        "reference_uncertainty_c": null,
        "reference_method": "Owner-provided contact thermometer; direct isolated-bead contact, cold and sustained hand-warmed reference",
        "points": [
          {
            "temperature_c": 23.5,
            "adc_raw": 1952,
            "evidence": "ntc-reference-002, 2026-10-25T15:03:35Z"
          },
          {
            "temperature_c": 30.1,
            "adc_raw": 1856,
            "evidence": "ntc-reference-004, 2026-10-25T15:24:26Z; owner explicitly requested use despite possible contact interference"
          }
        ],
        "scope": "Experimental effective model for this UID; intrinsic Beta and wider temperature accuracy are not qualified"
      },
      "uid": "54ff70068370525760380567",
      "profile_sha256": "9b3826a20b3c621a9e92be0035431b140c45d7a23acaba8ec237a63e4e8cad44",
      "effective_beta_k": 1284.690748293537,
      "effective_r25_over_rtop": 0.8912414562904697,
      "qualified": false,
      "lut_le_hex": "0000a0c128373b48000070c16ab02948000020c10c611a480000a0c050f20c4800000000c01c01480000a040584aed470000204193b4da4700007041b725ca470000a0416758bb470000bc41a1e7b147cdccf04113e7a14700000c42fa5a974700002042b59b8d47000034422cc48447000048423873794700005c42c9c96a4700007042ed635d4700008242bb1e514700008c42b9db4547000096423d803b470000a042dcf43147"
    },
    "osl": {
      "sequence": 1,
      "sha256": "af76d19b15a510dff0c880a4ab6e86893e0065ac7e845b9930111680752da78c",
      "preserved_physical_readback": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\product-deploy-preflight-readback.bin",
      "preprogram_runtime_sequence": 1
    },
    "acknowledgements": {
      "safe_outputs": true,
      "debug_halt_watchdog": true,
      "no_app_bootloader": true,
      "internal_flash": true
    },
    "seal_sha256": "09ed6065d7dd14e6565fb950f47be49cffb2b6bead42f479a8a2d808d44f1290"
  },
  "programming": "CONFIRMED",
  "internal_readback": "PASS",
  "boot": "NOT_TESTED",
  "uart_identity": "NOT_TESTED",
  "application": "NOT_TESTED",
  "external_w25q_access": false,
  "physically_validated": false,
  "outcome": "INTERNAL_FLASH_VERIFIED",
  "error": null,
  "transcripts": [
    {
      "path": "preflight/openocd.txt",
      "sha256": "833529329bc161e78ce628840aa17581a3d2de0304703cb81b41d0a663f9ff0b"
    },
    {
      "path": "openocd.txt",
      "sha256": "d84e6968df12c2e1beb3987a5b39084df8326aff811b4fe3f8b35d4fbd8cf751"
    }
  ],
  "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume.",
  "seal_sha256": "908c683bd9abc896b0c441f4ecb71c382e6b2b764ae5e0be2f768e817fca86f6",
  "preflight": {
    "target": {
      "device_id": 537093136,
      "cpuid": 1092600369,
      "flash_kib": 64,
      "obr": 67108860,
      "wrpr": 4294967295,
      "uid": "54ff70068370525760380567",
      "flash_base": 134217728,
      "flash_bytes": 65536,
      "driver": "stm32f1x",
      "state": "halted",
      "target_voltage_v": 3.297196
    },
    "programmer": {
      "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
      "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
      "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "config_hashes": {
        "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
        "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
      },
      "toolkit_script_sha256": "43bcdb67c2ce390bfd6adb0db481e7f046cc004aa0555976a0830e778cd6a968",
      "deployment_tool_sha256": "36e6df40f36b1bc2588561cc9b3cc16543c235425c65acaf7dade80b5abb1e05",
      "adapter_serial_selection": "530049000C0000513751594E"
    },
    "plan": {
      "argv": [
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
        "-s",
        "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
        "-c",
        "source $::env(WTK_INTERFACE)",
        "-c",
        "transport select dapdirect_swd",
        "-c",
        "adapter serial $::env(WTK_SERIAL)",
        "-c",
        "source $::env(WTK_TARGET)",
        "-c",
        "gdb_port disabled; tcl_port disabled; telnet_port disabled",
        "-c",
        "source $::env(WTK_LIBRARY)",
        "-c",
        "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
      ],
      "environment": {
        "WTK_SERIAL": "530049000C0000513751594E",
        "WTK_ACTION": "probe",
        "WTK_UID": "54ff70068370525760380567",
        "WTK_LENGTH": "0",
        "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
        "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
        "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
        "WTK_IMAGE": "",
        "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-continuous-001\\preflight\\before.bin",
        "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-continuous-001\\preflight\\full-readback.bin"
      },
      "internal_flash_range": [
        134217728,
        134283264
      ],
      "program_range": null,
      "erase_range": null,
      "external_w25q_access": false,
      "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
    }
  },
  "target": {
    "device_id": 537093136,
    "cpuid": 1092600369,
    "flash_kib": 64,
    "obr": 67108860,
    "wrpr": 4294967295,
    "uid": "54ff70068370525760380567",
    "flash_base": 134217728,
    "flash_bytes": 65536,
    "driver": "stm32f1x",
    "state": "halted",
    "target_voltage_v": 3.297196
  },
  "programmer": {
    "version": "xPack Open On-Chip Debugger 0.12.0+dev-01850-geb6f2745b-dirty (2025-02-07-10:08)",
    "executable": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
    "executable_sha256": "0aa3936470f75969138b0ad72ea1496dd5324c59a771b7a7ddf132ff1f10f09e",
    "scripts": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
    "config_hashes": {
      "interface/stlink.cfg": "3ba77e7fd28e90d4fd04833e234a3b36fd961d56bf7c8c0fcbdc8c8e49ddc0d1",
      "target/stm32f1x.cfg": "fe44c3ade7395db34a751c57401ebc2a176ed1ca793c47081cc9f06a8618125e"
    },
    "toolkit_script_sha256": "43bcdb67c2ce390bfd6adb0db481e7f046cc004aa0555976a0830e778cd6a968",
    "deployment_tool_sha256": "36e6df40f36b1bc2588561cc9b3cc16543c235425c65acaf7dade80b5abb1e05",
    "adapter_serial_selection": "530049000C0000513751594E"
  },
  "plan": {
    "argv": [
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\bin\\openocd.exe",
      "-s",
      "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts",
      "-c",
      "source $::env(WTK_INTERFACE)",
      "-c",
      "transport select dapdirect_swd",
      "-c",
      "adapter serial $::env(WTK_SERIAL)",
      "-c",
      "source $::env(WTK_TARGET)",
      "-c",
      "gdb_port disabled; tcl_port disabled; telnet_port disabled",
      "-c",
      "source $::env(WTK_LIBRARY)",
      "-c",
      "if {[catch {init; reset init; wtk_operation} reason]} {echo \"WTK_B011_FAILURE\"; echo $reason; shutdown error} else {shutdown}"
    ],
    "environment": {
      "WTK_SERIAL": "530049000C0000513751594E",
      "WTK_ACTION": "program",
      "WTK_UID": "54ff70068370525760380567",
      "WTK_LENGTH": "61136",
      "WTK_INTERFACE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\interface\\stlink.cfg",
      "WTK_TARGET": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\b011-openocd\\xpack-openocd-0.12.0-6\\openocd\\scripts\\target\\stm32f1x.cfg",
      "WTK_LIBRARY": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\tools\\swd_deploy.tcl",
      "WTK_IMAGE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-continuous-001\\staged-image.bin",
      "WTK_BEFORE": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-continuous-001\\before.bin",
      "WTK_READBACK": "C:\\Users\\rodri\\source\\repos\\WTK.RLCMeter\\Firmware\\build\\calibration-20261025\\deployment-continuous-001\\full-readback.bin"
    },
    "internal_flash_range": [
      134217728,
      134283264
    ],
    "program_range": [
      134217728,
      134278864
    ],
    "erase_range": [
      134217728,
      134279168
    ],
    "external_w25q_access": false,
    "warning": "SWD init/reset-init resets/halts the core; upstream config freezes watchdogs while halted and uses SRAM. Confirm physical K1 SAFE, range/excitation OFF. Never debugger-power the target. No automatic boot/resume."
  },
  "readback": {
    "start": 134217728,
    "end_exclusive": 134278864,
    "bytes": 61136,
    "expected_sha256": "b51558edced7660528ae6dc9b898e0242e422ef57af8f013e44f9aa4575343a6",
    "actual_sha256": "b51558edced7660528ae6dc9b898e0242e422ef57af8f013e44f9aa4575343a6",
    "full_flash_sha256": "60774661913039dcd7506a169da58d4d7e62646a6d25b02fb43df18ef180d7ae",
    "full_flash_bytes": 65536
  },
  "unaffected_internal_pages_preserved": true,
  "next_step": "Separately boot PRODUCT; limited SAFE_BOOT UART banner cannot prove SHA/calibration/resources/readiness. Inspect UI and physical checklist.",
  "completed_utc": "2026-10-27T03:45:16.259966+00:00"
}
```
