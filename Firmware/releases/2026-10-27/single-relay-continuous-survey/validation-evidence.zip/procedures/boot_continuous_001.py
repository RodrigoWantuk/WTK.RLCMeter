from pathlib import Path
import os,subprocess,time,json,sys
import survey_live_support as s
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_bringup
r=s.R;o=r/'boot-continuous-001';o.mkdir(exist_ok=False)
deployment=s.d.load(r/'deployment-continuous-001/deployment.json')
if deployment['outcome']!='INTERNAL_FLASH_VERIFIED':raise ValueError('Verified image required')
link=pc_bringup.open_serial('COM4')
p=s.backend().plan('probe',o,None,s.UID)
p['argv'][-1]='if {[catch {init; reset init; wtk_operation; reset run; echo "WTK_CONTINUOUS_BOOT_RUN"} reason]} {echo $reason; shutdown error} else {shutdown}'
a=subprocess.run(p['argv'],env=dict(os.environ,**p['environment']),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'reset-openocd.txt').write_bytes(a.stdout)
if a.returncode or a.stdout.count(b'WTK_CONTINUOUS_BOOT_RUN')!=1:link.close();raise ValueError('Controlled reset-run failed')
data=bytearray();until=time.monotonic()+10
while time.monotonic()<until:data.extend(link.read(144))
link.close();(o/'startup-uart.bin').write_bytes(data)
if data.count(b'WTK.RLCMeter SAFE_BOOT')!=1:raise ValueError('One UART SAFE_BOOT required')
layout=s.compile_layout(r/'verified-builds-continuous-001/factory-release',o)
report=s.snapshot(o,r/'image-continuous-001/manifest.json',layout,zero=True)
config=s.d.parse_config((r/'verified-builds-continuous-001/factory-release/generated/wtk_build_config.h').read_bytes())
report.update(uart_captured=True,uart_text=data.decode(errors='replace'),profile_flags={k:config[k] for k in ['WTK_ENABLE_MEASURE_SESSION_HOLD','WTK_ENABLE_UI_ROW_CACHE','WTK_ENABLE_MEASUREMENT_TRIMMED','WTK_ENABLE_FREQUENCY_SURVEY','WTK_ENABLE_CONTINUOUS_SURVEY']},controlled_reset=True,postboot_halted=False,outcome='CONTINUOUS_SURVEY_UART_READY_SAFE_ZERO_SESSIONS',physical_qualification=False)
if any(v!='1u' for v in report['profile_flags'].values()):raise ValueError('Factory features absent')
s.d.save(o/'report.json',report);print(json.dumps(report,indent=2),flush=True)
