"""Package and program the existing tested PC-provisioned PRODUCT image.
No acquisition START, calibration write or external-flash mutation.
"""
import json,sys,hashlib,subprocess,time
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
import pc_bringup as b
import pc_cal_capture as c
from pc_osl_install import Installer,validate_candidate
root=Path(__file__).resolve().parent
builds=root/'verified-builds-continuous-001'
matrix=d.load(builds/'firmware-builds.json')
ref=matrix['source']['git_sha']
if subprocess.check_output(['git','diff',ref,'HEAD','--','Firmware/src','Firmware/config','Firmware/cmake','Firmware/CMakeLists.txt','Firmware/CMakePresets.json']):raise ValueError('Embedded source changed since verified matrix')
case=next(v for v in matrix['cases'] if v['name']=='factory-release')
if case['status']!='PASS' or case['profile']!='PRODUCT' or case['factory']!='1u':raise ValueError('PC-provisioned production build required')
for n,meta in case['files'].items():
 if hashlib.sha256((builds/'factory-release'/n).read_bytes()).hexdigest()!=meta['sha256']:raise ValueError('Verified build changed')
imagepath=root/'image-continuous-001'
if imagepath.exists():raise ValueError('Do not reuse an image output directory')
image=d.manifest(builds/'factory-release',imagepath,'FACTORY_PRODUCT',matrix['source'],'stm32-factory-release')
image=d.inspect(imagepath/'manifest.json','FACTORY_PRODUCT')
subprocess.run([sys.executable,str(root/'preflight_continuous_002.py')],check=True)
pre=d.load(root/'pre-continuous-002/report.json')
if not pre['exact_running_image_match'] or pre['metadata']['calibration_sequence']!=1 or not pre['metadata']['calibration_active_valid']:
 raise ValueError('Fresh post-power calibration and SAFE metadata required')
identity=dict(uid=pre['target']['uid'])
frame=(root/'condition-composition-003/candidate.bin').read_bytes();validate_candidate(frame)
if hashlib.sha256(frame).hexdigest()!='af76d19b15a510dff0c880a4ab6e86893e0065ac7e845b9930111680752da78c':raise ValueError('Canonical calibration evidence changed')
auth=dict(operator='Rodrigo',utc=d.utc(),board='First Rev1 board; six RGS gate-to-GND rework',expected_uid=identity['uid'],SIMULATED=False,previous_profile='FACTORY_PRODUCT',next_profile='FACTORY_PRODUCT',image_sha256=image['files']['firmware.bin']['sha256'],manifest_seal=image['seal_sha256'],approval_origin='Owner explicitly requests one K1 engagement and final release across frequency changes and asks whether seven samples remain; prior standing authorization covers firmware fixes, programming, preservation, Git and PR. Live SAFE preflight precedes controlled internal programming. No remote measurement is initiated.',scope='Factory PRODUCT continuous three-frequency and seven-point survey, bounded 30s and supervised by actual VMID/BAT sampling outside DMA; preserve exact OSL sequence1/all33, assets/settings and UID NTC. No W25Q mutation or automatic DUT capture.',physical_qualification=False,procedural_exception=dict(owner_requested_proceed_without_scope=True,scope_checks='NOT_TESTED; no new accuracy or physical safety qualification inferred'),preflight_path=str(root/'pre-continuous-002/report.json'),supply='Live preflight rejects hard supply/charger/fault blockers; no numeric VBAT read via SWD; no old numeric battery voltage claimed as current',preservation='Internal Flash only; no external W25Q program/erase',ntc_factory_profile=image['ntc_factory_profile'],osl=dict(sequence=1,sha256=hashlib.sha256(frame).hexdigest(),preserved_physical_readback=str(root/'product-deploy-preflight-readback.bin'),preprogram_runtime_sequence=pre['metadata']['calibration_sequence']),acknowledgements=dict(safe_outputs=True,debug_halt_watchdog=True,no_app_bootloader=True,internal_flash=True))
auth['seal_sha256']=d.seal(auth);d.save(root/'deployment-continuous-authorization-001.json',auth)
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
record=d.deployment('program',imagepath/'manifest.json',backend,root/'deployment-continuous-001',authorization=auth,uid=identity['uid'])
print(json.dumps({k:record.get(k) for k in ('outcome','readback','error')},indent=2),flush=True)
if record['outcome']!='INTERNAL_FLASH_VERIFIED':raise SystemExit(1)
