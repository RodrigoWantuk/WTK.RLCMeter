import json
import survey_live_support as s
r=s.R;o=r/'pre-continuous-001';o.mkdir(exist_ok=False)
report=s.snapshot(o,r/'image-survey-003/manifest.json',s.d.load(r/'boot-survey-003/report.json')['layout'])
print(json.dumps(report['metadata'],indent=2),flush=True)
