"""First-unit-only extended-Flash experiment. Never changes production geometry."""
from pathlib import Path
import os, sys, json, hashlib, struct, subprocess, re
import survey_live_support as s

R=s.R
ROOT=R/'extended-flash-001'
LOW=0x08000000
UP=LOW+65536
END=UP+65536
PAGE=1024
SENTINEL_OFFSET=0x1F3F0
EXPECTED='5dd9a53f4117a5239e2ec0769e0560c10ce4114789f7782ef929da4b684aba7d'
def sha(data): return hashlib.sha256(data).hexdigest()
def save(path,value): s.d.save(path,value)
def stage(name,body,initial=False,normal_bank=False):
    if name=='pattern-a':name='pattern-a-002'
    out=ROOT/name;out.mkdir(exist_ok=False)
    backend=s.backend();provenance=backend.provenance()
    p=backend.plan('probe',out,None,s.UID)
    insert=p['argv'].index('source $::env(WTK_TARGET)')-1
    p['argv'][insert:insert]=['-c','set FLASH_SIZE '+str(65536 if normal_bank else 131072)]
    env=dict(os.environ,**p['environment'])
    paths=dict(LOWER=out/'lower.bin',UPPER=out/'upper.bin',UID=out/'uid.bin',
        BACKUP=ROOT/'backup/lower.bin',PAYLOAD=ROOT/'payload.bin')
    for key,path in paths.items():env['WTK_CAP_'+key]=str(path.resolve())
    init='init; poll; '
    if initial:
        meta=s.d.load(ROOT/'live-preflight/report.json')
        addresses={f['name']:f['address'] for f in meta['layout']}
        predicates=[]
        for key,val in [('k1_commanded_state',1),('measurement_hw_state',0),('quiet_requested',0),
            ('workspace_owner',0),('range_enabled',0),('excitation_mode',0),('safety_fault_mask',0)]:
            predicates.append('[lindex [read_memory '+hex(addresses[key])+' '+('32' if key=='safety_fault_mask' else '8')+' 1] 0] != '+str(val))
        init+='if {[stm32f1x.cpu curstate] ne "running"} {error "not running before initial SAFE reset"}; '
        init+='if {'+' || '.join(predicates)+'} {error "SAFE idle prerequisite lost"}; reset init; '
    init+='if {[stm32f1x.cpu curstate] ne "halted"} {error "expected controlled halted state"}; '
    guard='flash probe 0; set bank [lindex [flash list] 0]; '
    guard+='if {[llength [flash list]] != 1 || [dict get $bank base] != 0x08000000 || [dict get $bank size] != '+str(65536 if normal_bank else 131072)+' || [dict get $bank driver] ne "stm32f1x"} {error "unexpected configured geometry"}; '
    guard+='set kb [lindex [read_memory 0x1ffff7e0 16 1] 0]; set obr [lindex [read_memory 0x4002201c 32 1] 0]; set wrpr [lindex [read_memory 0x40022020 32 1] 0]; set did [lindex [read_memory 0xe0042000 32 1] 0]; '
    guard+='if {$kb != 64 || ($did & 4095) != 0x410 || ($obr & 3) != 0 || $wrpr != 0xffffffff} {error "device/factory/protection state changed"}; '
    guard+='set uid ""; foreach word [read_memory 0x1ffff7e8 32 3] {for {set i 0} {$i < 4} {incr i} {append uid [format "%02x" [expr {($word >> ($i*8)) & 255}]]}}; '
    guard+='if {$uid ne "'+s.UID+'"} {error "wrong unit"}; dump_image $::env(WTK_CAP_UID) 0x1ffff7e8 12; '
    guard+='echo "WTK_CAP_REGISTER|$kb|$obr|$wrpr"; '
    dumps='dump_image $::env(WTK_CAP_LOWER) 0x08000000 65536; dump_image $::env(WTK_CAP_UPPER) 0x08010000 65536; '
    script=init+guard+'set failed [catch {'+body+'} reason]; '+dumps+'if {[stm32f1x.cpu curstate] ne "halted"} {error "unexpected run after test"}; if {$failed} {error $reason}; echo "WTK_EXTENDED_STAGE_COMPLETE"'
    p['argv'][-1]='if {[catch {'+script+'} why]} {echo $why; shutdown error} else {shutdown}'
    save(out/'intent.json',dict(utc=s.d.utc(),stage=name,uid=s.UID,configured_geometry_bytes=65536 if normal_bank else 131072,
        factory_geometry_kib=64,body=body,argv=p['argv'],programmer=provenance,
        external_flash_access=False,option_bytes_written=False,battery_voltage_read_via_swd=False))
    with (out/'openocd.txt').open('wb') as log:
        try:
            run=subprocess.run(p['argv'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180,
                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except subprocess.TimeoutExpired:
            save(out/'result.json',dict(utc=s.d.utc(),stage=name,complete=False,status='PROGRAMMER_TIMEOUT_NO_CAPACITY_CLAIM'))
            raise
    transcript=(out/'openocd.txt').read_bytes()
    result=dict(utc=s.d.utc(),stage=name,returncode=run.returncode,complete=transcript.count(b'WTK_EXTENDED_STAGE_COMPLETE')==1)
    if (out/'lower.bin').exists():
        lower=(out/'lower.bin').read_bytes();result['lower_sha256']=sha(lower)
        if not initial:
            original=(ROOT/'backup/lower.bin').read_bytes()
            result['lower_preserved']=lower==original
            result['changed_lower_pages']=[i for i in range(64) if lower[i*PAGE:(i+1)*PAGE]!=original[i*PAGE:(i+1)*PAGE]]
    if (out/'upper.bin').exists():result['upper_sha256']=sha((out/'upper.bin').read_bytes())
    save(out/'result.json',result)
    print(json.dumps(result,indent=2),flush=True)
    if run.returncode or not result['complete']:raise ValueError('Stage failed; retain halted state and inspect readbacks before further writes')
    if not initial and not result['lower_preserved']:raise ValueError('Lower alias detected; stop upper operations and recover changed lower pages')
    return out

def backup():
    out=ROOT/'backup'
    if not out.exists():out=stage('backup','echo [flash info 0 sectors]',initial=True)
    assert s.d.load(out/'result.json')['complete']
    lower=(out/'lower.bin').read_bytes();upper=(out/'upper.bin').read_bytes()
    expected=(R/'image-serial-ui-001/firmware.bin').read_bytes()
    assert len(lower)==len(upper)==65536 and sha(expected)==EXPECTED and lower[:len(expected)]==expected
    assert lower[SENTINEL_OFFSET-65536:SENTINEL_OFFSET-65536+16]==bytes([255])*16
    # Independent copies and hashes must exist before any Flash write.
    (ROOT/'lower-recovery-copy.bin').write_bytes(lower)
    (ROOT/'upper-recovery-copy.bin').write_bytes(upper)
    pages=ROOT/'lower-recovery-pages';pages.mkdir(exist_ok=True)
    for page in range(64):(pages/(str(page)+'.bin')).write_bytes(lower[page*PAGE:(page+1)*PAGE])
    assert (ROOT/'lower-recovery-copy.bin').read_bytes()==lower
    save(ROOT/'backup-manifest.json',dict(utc=s.d.utc(),uid=s.UID,lower_sha256=sha(lower),upper_sha256=sha(upper),
        installed_sha256=EXPECTED,lower_bytes=65536,upper_bytes=65536,upper_all_erased=upper==bytes([255])*65536))

def originals():
    manifest=s.d.load(ROOT/'backup-manifest.json')
    lower=(ROOT/'backup/lower.bin').read_bytes();upper=(ROOT/'backup/upper.bin').read_bytes()
    assert sha(lower)==manifest['lower_sha256'] and sha(upper)==manifest['upper_sha256']
    assert (ROOT/'lower-recovery-copy.bin').read_bytes()==lower and (ROOT/'upper-recovery-copy.bin').read_bytes()==upper
    return lower,upper

def patterns():
    a=b''.join(struct.pack('<H',(i*40503+0x1259)&0xffff) for i in range(32768))
    b=bytes(v^255 for v in a)
    assert len(a)==len(b)==65536 and len(set(struct.unpack('<32768H',a)))==32768
    assert all(x^y==255 for x,y in zip(a,b))
    return a,b

def erase():
    # Single-sector operations, never first=0/last=end (driver mass-erase path).
    return 'for {set page 64} {$page < 128} {incr page} {flash erase_sector 0 $page $page; verify_image $::env(WTK_CAP_BACKUP) 0x08000000 bin; echo "WTK_UPPER_PAGE_ERASED_LOWER_VERIFIED|$page"}; '

def execute(mode):
    if mode=='backup':backup();return
    lower,upper=originals()
    if mode=='sentinel':
        offset=SENTINEL_OFFSET-65536
        assert upper[offset:offset+16]==bytes([255])*16 and lower[offset:offset+16]==bytes([255])*16
        payload=bytes.fromhex('c35a16e9a5073cf06d92b14872cd0ab5')
        (ROOT/'payload.bin').write_bytes(payload)
        out=stage(mode,'flash write_bank 0 $::env(WTK_CAP_PAYLOAD) '+str(SENTINEL_OFFSET))
        expected=upper[:offset]+payload+upper[offset+16:]
    elif mode in ('pattern-a','pattern-b'):
        assert s.d.load(ROOT/'sentinel/verification.json')['passed']
        if mode=='pattern-b':assert s.d.load(ROOT/'reset-a/verification.json')['passed']
        payload=patterns()[mode=='pattern-b'];(ROOT/'payload.bin').write_bytes(payload)
        out=stage(mode,erase()+'flash write_bank 0 $::env(WTK_CAP_PAYLOAD) 65536')
        expected=payload
    elif mode in ('reset-a','reset-b'):
        source='pattern-a-002' if mode=='reset-a' else 'pattern-b'
        assert s.d.load(ROOT/source/'verification.json')['passed']
        out=stage(mode,'reset init')
        expected=patterns()[mode=='reset-b']
    elif mode=='fetch-stub':
        assert s.d.load(ROOT/'reset-b/verification.json')['passed']
        payload=bytes.fromhex('5a20693000be')+bytes([255])*10
        (ROOT/'fetch-stub.bin').write_bytes(payload)
        (ROOT/'payload.bin').write_bytes(payload)
        out=stage(mode,'flash erase_sector 0 127 127; verify_image $::env(WTK_CAP_BACKUP) 0x08000000 bin; flash write_bank 0 $::env(WTK_CAP_PAYLOAD) 131056')
        expected=patterns()[1][:-1024]+bytes([255])*1008+payload
    elif mode=='execute-upper':
        assert s.d.load(ROOT/'fetch-stub/verification.json')['passed']
        out=stage(mode,'reg r0 0; step 0x0801fff0; echo "WTK_FETCH_STEP1|[reg r0]|[reg pc]"; step; echo "WTK_FETCH_STEP2|[reg r0]|[reg pc]"')
        transcript=(out/'openocd.txt').read_text(encoding='utf-8')
        for number,r0,pc in [(1,0x5a,0x0801fff2),(2,0xc3,0x0801fff4)]:
            line=next(line for line in transcript.splitlines() if line.startswith('WTK_FETCH_STEP'+str(number)+'|'))
            values=re.findall(r'0x([0-9a-fA-F]+)',line)
            assert [int(v,16) for v in values]==[r0,pc]
        expected=(ROOT/'fetch-stub/upper.bin').read_bytes()
    elif mode=='restore-upper':
        assert s.d.load(ROOT/'reset-b/verification.json')['passed']
        (ROOT/'payload.bin').write_bytes(upper)
        body=erase()
        if upper!=bytes([255])*65536:body+='flash write_bank 0 $::env(WTK_CAP_PAYLOAD) 65536'
        out=stage(mode,body);expected=upper
    else:raise ValueError('Unknown explicitly selected stage')
    actual=(out/'upper.bin').read_bytes()
    passed=actual==expected
    save(out/'verification.json',dict(passed=passed,expected_sha256=sha(expected),actual_sha256=sha(actual),
        exact_upper_bytes=65536,lower_preserved=(out/'lower.bin').read_bytes()==lower))
    if not passed:raise ValueError('Upper readback mismatch: no capacity success claim')

if __name__=='__main__':execute(sys.argv[1])
