from pathlib import Path
import sys,os,json,re,struct,subprocess
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
R=Path(__file__).resolve().parent
ARM=Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin')
UID='54ff70068370525760380567'
def backend():
 return d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
def compile_layout(build,out):
 fields=d.load(R/'survey-metadata-fields.json')
 (out/'layout.c').write_text('#include <stddef.h>\n#include "app/app_product.h"\n#include "app/app_io_workspace.h"\n#include "hardware/hw_k1.h"\n#include "hardware/hw_range.h"\nconst unsigned offsets[]={'+','.join(v[1] for v in fields.values())+'};\n',encoding='utf-8')
 subprocess.run([str(ARM/'arm-none-eabi-gcc.exe'),'-std=c17','-mcpu=cortex-m3','-mthumb','-S',str(out/'layout.c'),'-I','Firmware/src','-I',str(build/'generated'),'-o',str(out/'layout.s')],check=True)
 offsets=[int(v) for v in re.findall(r'^\s*\.word\s+(\d+)',(out/'layout.s').read_text(),re.M)]
 if len(offsets)!=len(fields):raise ValueError('Complete ARM layout required')
 nm=subprocess.check_output([str(ARM/'arm-none-eabi-nm.exe'),'-n',str(build/'WTK.RLCMeter.elf')],text=True)
 symbols={n:int(a,16) for a,n in re.findall(r'^([0-9a-f]+) [A-Za-z] (\S+)$',nm,re.M)}
 layout=[]
 for (name,(symbol,expr,fmt)),off in zip(fields.items(),offsets):
  matches=[s for s in symbols if s.split('.lto_priv.')[0]==symbol]
  if symbol not in symbols:
   if len(matches)!=1:raise ValueError('Ambiguous symbol '+symbol)
   symbol=matches[0]
  layout.append(dict(name=name,address=symbols[symbol]+off,size=struct.calcsize('<'+fmt)))
 return layout

def snapshot(out,imagepath,layout,zero=False):
 image=d.inspect(imagepath,'FACTORY_PRODUCT')
 b=backend();p=b.plan('probe',out,None,UID);env=dict(os.environ,**p['environment'])
 addresses={row['name']:row['address'] for row in layout}
 guard='if {'+' || '.join('[lindex [read_memory '+hex(addresses[k])+' 8 1] 0] != '+str(v) for k,v in [('k1_commanded_state',1),('excitation_mode',0),('measurement_hw_state',0),('quiet_requested',0),('workspace_owner',0)])+' || [lindex [read_memory '+hex(addresses['product_state'])+' 8 1] 0] == 19} {error "active ownership: live snapshot deferred"}'
 commands=[]
 for i,row in enumerate(layout):
  env['WTK_LIVE_'+str(i)]=str((out/(row['name']+'.bin')).resolve());commands.append('dump_image $::env(WTK_LIVE_'+str(i)+') '+hex(row['address'])+' '+str(row['size']))
 env['WTK_LIVE_UID']=str((out/'uid.bin').resolve())
 seq=hex(addresses['measurement_session_sequence'])
 script='init; poll; if {[stm32f1x.cpu curstate] ne "running"} {error "core is not running; no automatic resume"}; '+guard+'; set wtk_seq [lindex [read_memory '+seq+' 32 1] 0]; dump_image $::env(WTK_LIVE_UID) 0x1ffff7e8 12; dump_image $::env(WTK_READBACK) 0x08000000 65536; '+guard+'; '+'; '.join(commands)+'; '+guard+'; if {[lindex [read_memory '+seq+' 32 1] 0] != $wtk_seq} {error "sequence changed during snapshot"}; if {[stm32f1x.cpu curstate] ne "running"} {error "unexpected core state"}; echo "WTK_STABLE_LIVE_SNAPSHOT"'
 p['argv'][-1]='if {[catch {'+script+'} reason]} {echo $reason; shutdown error} else {shutdown}'
 run=subprocess.run(p['argv'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(out/'openocd.txt').write_bytes(run.stdout)
 if run.returncode or run.stdout.count(b'WTK_STABLE_LIVE_SNAPSHOT')!=1:raise ValueError('Stable live snapshot failed; core never halted/reset/resumed')
 if (out/'uid.bin').read_bytes().hex()!=UID:raise ValueError('Wrong live unit')
 expected=(imagepath.parent/'firmware.bin').read_bytes()
 if (out/'full-readback.bin').read_bytes()[:len(expected)]!=expected:raise ValueError('Image/ABI mismatch')
 meta={row['name']:int.from_bytes((out/(row['name']+'.bin')).read_bytes(),'little') for row in layout}
 report=dict(utc=d.utc(),operation='STABLE_LIVE_DAP_METADATA_NO_HALT_NO_RESET_NO_RESUME',target=dict(uid=UID),firmware_sha256=image['files']['firmware.bin']['sha256'],exact_running_image_match=True,metadata=meta,layout=layout,battery_voltage_read_via_swd=False,measurement_commanded=False,halt_requested=False,external_flash_written=False)
 d.save(out/'report.json',report)
 if meta['safety_fault_mask'] or meta['safety_blocker_flags']&~12 or meta['range_enabled'] or meta['session_connected'] or meta['measurement_hw_error']:raise ValueError('Fault/power/ownership blocker')
 if meta['calibration_sequence']!=1 or meta['calibration_record_count']!=33 or not meta['calibration_active_valid']:raise ValueError('Calibration not preserved')
 if zero and (meta['product_state']!=4 or meta['measurement_session_sequence'] or meta['session_capture_count']):raise ValueError('Clean idle READY boot not observed')
 return report
