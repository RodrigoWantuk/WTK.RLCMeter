"""Read completed PRODUCT result/history without reset, request, or battery read."""
import os,sys,subprocess,re,struct,json,math,hashlib
from pathlib import Path
sys.path.insert(0,str(Path('Firmware/tools').resolve()))
import pc_firmware_deploy as d
r=Path(__file__).resolve().parent;o=r/'serial-ui-live-result-001';o.mkdir(exist_ok=False)
build=r/'verified-builds-serial-ui-001/factory-release';arm=Path('C:/Program Files (x86)/Arm GNU Toolchain arm-none-eabi/14.2 rel1/bin')
fields={}
def field(name,path,kind='int'):fields[name]=(path,kind)
for x in ['runtime_kind','session_sequence','view.state','view.has_measurement_result','runtime.measurement.state','runtime.measurement.policy.status','runtime.measurement.policy.attempt_count','runtime.measurement.policy.primary_attempt_index','runtime.measurement.policy.frequency_refinement_count','runtime.measurement.policy.last_result.classification.interpretation','runtime.measurement.policy.last_result.confidence.reason_flags','runtime.measurement.policy.last_result.confidence.measurement_quality','runtime.measurement.policy.last_result.confidence.publication_confidence']:field(x,x)
for x in ['status','interpretation','frequency','amplitude','range_id','return_channel','attempt_count','derived_valid','capacitance_valid','inductance_valid','esr_valid','q_valid','d_valid','confidence']:field('ui.'+x,'view.measurement_result.'+x)
for x in ['resistance_ohms','reactance_ohms','magnitude_ohms','phase_rad','capacitance_f','inductance_h']:field('ui.'+x,'view.measurement_result.'+x,'float')
for i in range(12):
 base='runtime.measurement.policy.history['+str(i)+'].'
 for x in ['config.range_id','config.frequency','config.amplitude','config.reason','dsp_status','selected_channel','open_like','short_like','clipped','phase05_failed','safety_abort','canceled','calibration.source','calibration.status','calibration.set_sequence','derived.valid','derived.interpretation','derived.capacitance_valid','derived.inductance_valid','ret_1x_quality.usable','ret_1x_quality.clipped','ret_1x_quality.calibration_valid','ret_hg_quality.usable','ret_hg_quality.clipped','ret_hg_quality.calibration_valid']:field('attempt'+str(i)+'.'+x,base+x)
 for x in ['z_ohms.re','z_ohms.im','derived.phase_rad','derived.capacitance_f','derived.inductance_h','source_peak_v','return_peak_v','denominator_peak_v','dut_zref_ratio','ret_1x_quality.signal_peak_v','ret_hg_quality.signal_peak_v']:field('attempt'+str(i)+'.'+x,base+x,'float')

for x in ['samples','extra_captures','r_retained_mask','x_retained_mask','requested','applied']:
 field('trimmed.'+x,'runtime.measurement.policy.last_result.trimmed.'+x)
for i in range(7):
 for x in ['re','im']:field('sample'+str(i)+'.'+x,'runtime.measurement.trimmed.points['+str(i)+'].'+x,'float')
for x in ['re','im']:field('aggregate.'+x,'runtime.measurement.policy.last_result.primary_attempt.z_ohms.'+x,'float')

for x in ['frequency_attempted_mask','frequency_usable_mask']:field('coverage.'+x,'runtime.measurement.policy.last_result.'+x)
for x in ['view.measurement_result_partial','view.measurement_result.trimmed_applied','view.measurement_result.frequency_attempted_mask','runtime.measurement.survey_deadline_ms']:field(x,x)
expr=['sizeof(app_product_t)']
for path,kind in fields.values():expr+=['offsetof(app_product_t,'+path+')','sizeof(((app_product_t*)0)->'+path+')']
(o/'layout.c').write_text('#include <stddef.h>\n#include "app/app_product.h"\nconst unsigned layout[]={'+','.join(expr)+'};\n',encoding='utf-8')
subprocess.run([str(arm/'arm-none-eabi-gcc.exe'),'-std=c17','-mcpu=cortex-m3','-mthumb','-S',str(o/'layout.c'),'-I','Firmware/src','-I',str(build/'generated'),'-o',str(o/'layout.s')],check=True)
layout=[int(v) for v in re.findall(r'^\s*\.word\s+(\d+)',(o/'layout.s').read_text(),re.M)]
if len(layout)!=1+len(fields)*2:raise ValueError('Complete ARM ABI required')
nm=subprocess.check_output([str(arm/'arm-none-eabi-nm.exe'),'-n',str(build/'WTK.RLCMeter.elf')],text=True);symbols={n:int(a,16) for a,n in re.findall(r'^([0-9a-f]+) [A-Za-z] (\S+)$',nm,re.M)}
base=symbols['g_product.lto_priv.0'];state_offset=layout[1+list(fields).index('view.state')*2]
backend=d.OpenOCD('Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/bin/openocd.exe','Firmware/build/b011-openocd/xpack-openocd-0.12.0-6/openocd/scripts','530049000C0000513751594E')
ip=r/'image-serial-ui-001/manifest.json';im=d.inspect(ip,'FACTORY_PRODUCT');im['manifest_path']=str(ip.resolve());p=backend.plan('verify',o,im,'54ff70068370525760380567');env=dict(os.environ,**p['environment']);env['WTK_PRODUCT_RAM']=str((o/'product-ram.bin').resolve())
boot=d.load(r/'boot-serial-ui-001/report.json')
addresses={row['name']:row['address'] for row in boot['layout']}
guard='if {[lindex [read_memory '+hex(addresses['k1_commanded_state'])+' 8 1] 0] != 1 || [lindex [read_memory '+hex(addresses['excitation_mode'])+' 8 1] 0] != 0 || [lindex [read_memory '+hex(base+state_offset)+' 8 1] 0] == 19 || [lindex [read_memory '+hex(addresses['measurement_hw_state'])+' 8 1] 0] != 0} {error "measurement active: no diagnostic halt"}'
env['WTK_LIVE_UID']=str((o/'uid.bin').resolve())
seq_offset=layout[1+list(fields).index('session_sequence')*2]
p['argv'][-1]='if {[catch {init; poll; if {[stm32f1x.cpu curstate] ne "running"} {error "core is not running; no automatic resume"}; '+guard+'; set wtk_seq [lindex [read_memory '+hex(base+seq_offset)+' 32 1] 0]; dump_image $::env(WTK_LIVE_UID) 0x1ffff7e8 12; dump_image $::env(WTK_READBACK) 0x08000000 65536; '+guard+'; dump_image $::env(WTK_PRODUCT_RAM) '+hex(base)+' '+str(layout[0])+'; '+guard+'; if {[lindex [read_memory '+hex(base+seq_offset)+' 32 1] 0] != $wtk_seq} {error "result changed during live snapshot"}; echo "WTK_COMPLETED_RESULT_LIVE"} reason]} {echo $reason; shutdown error} else {shutdown}'
a=subprocess.run(p['argv'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'openocd.txt').write_bytes(a.stdout)
if a.returncode or a.stdout.count(b'WTK_COMPLETED_RESULT_LIVE')!=1:raise ValueError('Stable live result read not confirmed')
if (o/'full-readback.bin').read_bytes()[:im['binary_size']]!=(ip.parent/'firmware.bin').read_bytes():raise ValueError('Actual firmware differs; do not interpret ABI')
if (o/'uid.bin').read_bytes().hex()!='54ff70068370525760380567':raise ValueError('Wrong live unit')
raw=(o/'product-ram.bin').read_bytes();values={}
for i,(name,(path,kind)) in enumerate(fields.items()):
 offset,size=layout[1+2*i:3+2*i];v=struct.unpack_from('<f',raw,offset)[0] if kind=='float' else int.from_bytes(raw[offset:offset+size],'little');values[name]=v if not isinstance(v,float) or math.isfinite(v) else str(v)
report=dict(utc=d.utc(),operation='LIVE_THREE_FREQUENCY_RESULT_NO_HALT_NO_RESET_NO_CAPTURE',firmware_sha256=im['files']['firmware.bin']['sha256'],battery_voltage_read=False,request_sent=False,fixture='OWNER_FIXTURE_MUST_BE_RECORDED_BEFORE_RESULT_INTERPRETATION; no request sent, no reset',values=values)
d.save(o/'report.json',report)
count=values['runtime.measurement.policy.attempt_count'];print(json.dumps({k:v for k,v in values.items() if not k.startswith('attempt') or int(re.match(r'attempt(\d+)',k).group(1))<count},indent=2),flush=True)


