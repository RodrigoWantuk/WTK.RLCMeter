import json
import survey_live_support as s
r=s.R;o=r/'pre-serial-ui-001';o.mkdir(exist_ok=False)
report=s.snapshot(o,r/'image-continuous-001/manifest.json',s.d.load(r/'boot-continuous-001/report.json')['layout'])
print(json.dumps(report['metadata'],indent=2),flush=True)
