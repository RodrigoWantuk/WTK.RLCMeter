from pathlib import Path
import os,subprocess,json,hashlib
import survey_live_support as s
r=s.R;o=r/'serial-ui-recovery-002';o.mkdir(exist_ok=False)
failed=s.d.load(r/'deployment-serial-ui-001/deployment.json')
if failed['programming']!='UNKNOWN_MAY_BE_PARTIAL' or (r/'deployment-serial-ui-001/openocd.txt').exists() or 'Acesso negado' not in failed['error']:raise ValueError('Not a known pre-program persistence failure')
p=s.backend().plan('probe',o,None,s.UID);env=dict(os.environ,**p['environment']);env['WTK_REC_UID']=str((o/'uid.bin').resolve())
p['argv'][-1]='if {[catch {init; poll; if {[stm32f1x.cpu curstate] ne "halted"} {error "unexpected core state; no auto halt"}; dump_image $::env(WTK_REC_UID) 0x1ffff7e8 12; dump_image $::env(WTK_READBACK) 0x08000000 65536; echo "WTK_KNOWN_PREFLIGHT_RECOVERY"} reason]} {echo $reason; shutdown error} else {shutdown}'
a=subprocess.run(p['argv'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(o/'openocd.txt').write_bytes(a.stdout)
if a.returncode or a.stdout.count(b'WTK_KNOWN_PREFLIGHT_RECOVERY')!=1:raise ValueError('Known stopped preflight not confirmed')
if (o/'uid.bin').read_bytes().hex()!=s.UID:raise ValueError('Wrong unit')
old=(r/'image-continuous-001/firmware.bin').read_bytes();actual=(o/'full-readback.bin').read_bytes()
if actual[:len(old)]!=old:raise ValueError('Previous firmware changed unexpectedly')
s.d.save(o/'report.json',dict(utc=s.d.utc(),state='HALTED_AFTER_PREPROGRAM_SAFE_RESET_PROBE',failed_programming=failed['programming'],failure_stage='PERSIST_REQUEST_BEFORE_BACKEND_PROGRAM_EXECUTE',old_image_exact_match=True,old_image_sha256=hashlib.sha256(old).hexdigest(),full_flash_sha256=hashlib.sha256(actual).hexdigest(),battery_voltage_read_via_swd=False,halt_reset_or_resume_requested=False,recovery='Repeat same authorized internal programming after bounded atomic-file-lock fix; no new measurement'))
auth=s.d.load(r/'deployment-serial-ui-authorization-001.json');auth.update(utc=s.d.utc(),retry_reason='Original deployment stopped before program while persisting probe evidence; known halted SAFE-reset preflight and unchanged old image independently confirmed',recovery=str(o/'report.json'));auth['seal_sha256']=s.d.seal(auth);s.d.save(r/'deployment-serial-ui-authorization-002.json',auth)
record=s.d.deployment('program',r/'image-serial-ui-001/manifest.json',s.backend(),r/'deployment-serial-ui-002',authorization=auth,uid=s.UID)
print(json.dumps({k:record.get(k) for k in ('outcome','readback','error')},indent=2),flush=True)
if record['outcome']!='INTERNAL_FLASH_VERIFIED':raise SystemExit(1)
