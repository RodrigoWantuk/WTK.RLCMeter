import json
import survey_live_support as s
r=s.R;o=r/'post-serial-ui-001';o.mkdir(exist_ok=False)
report=s.snapshot(o,r/'image-serial-ui-001/manifest.json',s.d.load(r/'boot-serial-ui-001/report.json')['layout'])
print(json.dumps(report['metadata'],indent=2),flush=True)
